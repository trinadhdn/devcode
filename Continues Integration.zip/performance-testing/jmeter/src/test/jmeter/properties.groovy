/*
 @Author : Maria Angeles Villalba Fernández
 @Description : Sets the properties
*/
import groovy.json.*
import java.lang.String
import org.apache.jmeter.services.FileServer; 

try {
def projectDir = FileServer.getFileServer().getBaseDir();

//read datafile
List lines= new File(projectDir + "/jmeter_confg.properties").readLines()

   for(i in lines){
	def key = i.split("=", 2)[0]
	def value = i.split("=", 2)[1]
	//sets the properties
	vars.put(key, value);
  }
}catch(Exception e){
	log.info("##########--------------in exception--------------##########")
	log.info("in Properties.groovy file :Failed to load dataFile from project directory.")
}
