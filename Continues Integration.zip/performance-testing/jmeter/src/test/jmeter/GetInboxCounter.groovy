import groovy.json.JsonSlurper
/*
 @Modified by : Sowjanya Lankadasu
 @Description : Extracts the inbox counter
*/

String data = prev.getResponseDataAsString();

def inboxcount = new groovy.json.JsonSlurper().parseText(data).countInboxMessages
log.info("coint inbox ====================="+inboxcount)
vars.put('cnt','cnt')
