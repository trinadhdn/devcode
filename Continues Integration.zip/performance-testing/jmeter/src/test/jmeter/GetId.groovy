/*
 @Modified by : Sowjanya Lankadasu
 @Description : Extracts the Asset ID from the response 
*/
String data = prev.getResponseDataAsString();

//log.info("id data ----------------"+data)
//def aux = data.split("cacheKey=%7B", 2)[1]


def aux = data.split("doc_",2)[1]

if(aux != null){
	def id = aux.getAt(0..39)
	//def id = aux.split("%7D",2)[0]
	//vars.put('id', '{'+id+'}');
	vars.put('id', id);
	//log.info("id is ------>"+id)
}