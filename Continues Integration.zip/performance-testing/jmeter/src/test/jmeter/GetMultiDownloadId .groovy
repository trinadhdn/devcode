/*
 @Modified by : Sowjanya Lankadasu
 @Description : Extracts the Asset ID from the response 
*/
log.info("-----------------multidownlaod=--------------")	
	String mdata = prev.getResponseDataAsString();
	def maux = mdata.split("doc_",2)[1]

	List<String> ids = []
	for(int i=0;i<=1;i++){
	
	log.info("in loop=============="+i)
    def mid = maux.getAt(0..39)
    ids.add(mid)
	log.info(ids[i])	
    maux=maux.split("doc_",2)[1]
		}
	log.info("id--------------------pputside looppp")	
	def allid=ids.join(", ")
	vars.put('allid', '['+allid+']');
	log.info("MultiDownload ID`s: "+allid)
