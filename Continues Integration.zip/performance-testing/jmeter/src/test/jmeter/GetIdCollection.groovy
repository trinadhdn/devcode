/*
 @Modified by : Sowjanya Lankadasu
 @Description : Extracts the collection ID from the response 
*/
String response = prev.getResponseDataAsString();
//log.info("in GetId Collection file ----------"+response)
def aux = response.split(":",2)[1]

if(aux != null){
//log.info("-----------------aux>"+aux)

def collectionsId = aux.split(",",2)[0]
//log.info("before----------------->id : "+collectionsId)
vars.put('collectionsId', collectionsId);
log.info("--------------collectionsId------------"+collectionsId)

def temp = '["'+collectionsId+'"]'
log.info("--------------data------------"+temp)
vars.put('temp',temp)

def collData = '{"old_collection":'+temp+',"new_collection":{},"search_criteria":{},"multiple":false,"inputs":"content_ARTESIA.FIELD.CONTENT_TYPE_1%5B%5D=MS+Office","query":"test"}'
log.info("--------------data------------"+collData)
vars.put('collData',collData)
}



