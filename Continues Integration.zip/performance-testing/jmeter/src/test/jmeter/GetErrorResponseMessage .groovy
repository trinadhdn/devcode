/*
 @Modified by : Sowjanya Lankadasu
 @Description : Verifying the response message
*/
def json = new groovy.json.JsonSlurper().parseText(prev.getResponseDataAsString())

def failureMessage = 'JSON RESPONSE:' + json

	
	
if (json.error != null) {
    AssertionResult.setFailure(true)
    AssertionResult.setFailureMessage('Please check the permissions for Asset/Collection for downlaod/export. The error message: '+failureMessage)
    return
}