# Oracle Java 8 installation

###### Debian/Ubuntu
```
# installing oracle java 8
sudo apt-get update
sudo apt-get install -y oracle-java8-installer

# defining java 8 as default (optional)
sudo apt-get install -y oracle-java8-set-default
```
