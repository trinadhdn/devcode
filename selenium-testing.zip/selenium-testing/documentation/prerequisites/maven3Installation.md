# Apache Maven 3 installation

###### Debian/Ubuntu
```
# removing maven2
sudo apt-get remove maven2

# installing maven3
sudo apt-get update
sudo apt-get install -y maven
```
Once maven is installed, check it performing:
```
mvn -version
```

