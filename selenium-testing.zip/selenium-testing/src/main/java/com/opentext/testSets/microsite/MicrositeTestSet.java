/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText Technologies.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.microsite;

import static org.testng.AssertJUnit.assertTrue;

import java.awt.AWTException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.banners.microsite.MicrositeBannersPage;
import com.opentext.pageObjects.administration.general.microsite.CreateAndEditMicrositeGeneralPage;
import com.opentext.pageObjects.administration.general.microsite.MicrositeGeneralPage;
import com.opentext.pageObjects.administration.general.microsite.MicrositeLoginPage;
import com.opentext.pageObjects.administration.general.microsite.MicrositePage;
import com.opentext.pageObjects.administration.links.microsite.MicrositeLinksPage;
import com.opentext.pageObjects.administration.security.contentPermissions.ContentPermissionsPage;
import com.opentext.pageObjects.administration.testusers.microsite.MicrositeTestUsersPage;
import com.opentext.pageObjects.advanceSearch.AdvanceSearchPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.SectionType;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;
import com.opentext.utils.administration.DashboardBuilder;

/**
 * A test class contain the tests of the Microsite area in the web application.
 * 
 * @author MavyaPapishetty <mpapishe@opentext.com>
 */
public class MicrositeTestSet extends BasicTestSet {

    static Logger log = Logger.getLogger(MicrositeTestSet.class);
    String collectionName = null;
    String link = null;
    String URL = null;

    public MicrositeTestSet() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
     * Create a new Microsite :
     * 
     * -# @see loginAux() 
     * -# Go to Profile and get the roles. 
     * -# Get the list of the sections visible. 
     * -# Navigate to Administration area. 
     * -# Navigate to 'Microsite'. 
     * -# Validate General Page. 
     * -# Click on Add Microsite. 
     * -# With every field empty, click on Save button.
     * -# Check the Site hasn't been created.
     * -# @see logoutAux()
     * 
     * @throws AWTException
     */

    @Test(enabled = true, priority = 1, description = "Create a new microsite server with every field Empty.")
    public void requiredFieldValidation(Method method) throws AWTException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start requiredFieldValidation method: "
                + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Microsite General tab'.
        MicrositeGeneralPage generalPage = (MicrositeGeneralPage) dashboard
                .goToSpecificSectionOrSubSectionPage(SectionType.GENERAL_MICROSITES);

        // Asserting that microsite general page is shown
        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Click on 'Add Microsite'.
        CreateAndEditMicrositeGeneralPage createMicrositePage = generalPage.goToAddMicrosite();
        assertTrue("Create Microsite page is not ready.", createMicrositePage.isReady());

        // With every field empty, click on Save button.
        createMicrositePage.clickOnSave();

        // Check the Microsite hasn't been created.
        assertTrue("Create microsite page is not ready.", createMicrositePage.isReady());
        assertTrue("Required field should be shown.", createMicrositePage.isRequiredFieldMessageShown());
        assertTrue("Error Message for Required field is shown.", createMicrositePage
                .isErrorMessageIsShownForRequiredField());

        // Perform the logout action.
        logoutPage = logoutAux(dashboard.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End requiredFieldValidation method: "
                + method.getName());
    }

    /**
     * Create a new Microsite :
     * 
     * -# @see loginAux() 
     * -# Go to Profile and get the roles. 
     * -# Get the list of the sections visible. 
     * -# Navigate to Administration area. 
     * -# Navigate to 'Microsite'. 
     * -# Validate General Page. 
     * -# Click on Add Microsite 
     * -# Verify all the tabs General ,Security, Metadata, Linksand Banners,folders and Filters, Customizations by filling the required fields. 
     * -# Click on Save na dcreate a microsite. 
     * -# Verify Microiste has created 
     * -# Navigate to Newly created site Microsite 
     * -# Assert that it is navigated to new Microsite
     * -# Delete the site 
     * -# Assert that site is deleted
     * -# @see logoutAux()
     * 
     * @throws AWTException
     */

    @Test(enabled = true, priority = 2, description = "Create a new microsite server.")
    public void createMicrosite(Method method) throws AWTException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start createMicrosite method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Microsite General tab'.
        MicrositeGeneralPage generalPage = (MicrositeGeneralPage) dashboard
                .goToSpecificSectionOrSubSectionPage(SectionType.GENERAL_MICROSITES);

        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Click on 'Add Microsite'.
        CreateAndEditMicrositeGeneralPage createMicrositePage = generalPage.goToAddMicrosite();
        assertTrue("Create Microsite page is not ready.", createMicrositePage.isReady());

        // Add a new Microsite.
        String micrositeName = "Microsite - " + new Date().getDate() + new Date().getTime();
        String seoMetadata = "Filling SEO Metadata filed";
        String authenticationType = "Public";
        createMicrositePage.fillDetailsinGenaralPage(micrositeName, seoMetadata, authenticationType);

        // Navigate to security tab
        createMicrositePage.navigateSecuritytab();

        // check if it is navigated to security tab
        assertTrue("It is not navigated to security tab ", createMicrositePage.isSecurityTabReady());

        // selecting the public microsite
        createMicrositePage.selectAutheticationType(authenticationType);

        // Selecting the Admin role
        createMicrositePage.selectingAdminRoleforPublicType("Everyone");
        assertTrue("user is not navigated to security tab", createMicrositePage.isSecurityTabReady());

        // Navigate to Metadata tab
        createMicrositePage.navigateMetadatatab();

        // Check if it is navigated to Metadata tab
        assertTrue("user is not navigated to MetaData tab", createMicrositePage.isMetadataTabReady());

        // Navigate to Links and banners
        createMicrositePage.navigateLinksAndBannersstab();

        // Check if it is navigated to links and banners tab
        assertTrue("user is not navigated to Links and Banners tab", createMicrositePage.isLinksAndBannersTabReady());

        // Navigate to Folders and filters tab
        createMicrositePage.navigateFoldersAndFilterstab();

        // check if it is navigated to Foldera nd filters tab
        assertTrue("user is not navigated to Folders tab", createMicrositePage.isFoldersAndFiltersTabReady());

        // Navigate to customization tab
        createMicrositePage.navigateCustomizationtab();

        // Enabling Advance search
        createMicrositePage.enableAdvancesearchInMicrosite();

        // check if it is navigated custamization tab
        assertTrue("user is not navigated to Folders tab", createMicrositePage.isCustomizationTabReady());

        // Save the microsite
        createMicrositePage.clickOnSave();

        // check if microsite is created
        assertTrue("Create general page is not ready.", generalPage.isReady());
        assertTrue("The new microsite name is not shown", generalPage
                .isNewlyCreatedMicrositeNameShownInList(micrositeName));

        // Accesing microsite
        String friendlyURL = generalPage.getMicrositeURL(micrositeName);
        String defaultWindow = generalPage.handlingNewWindow();

        generalPage.switchingToNewMicrosite(friendlyURL);

        // Verifying advance search
        MicrositePage micrositepage = new MicrositePage(DriverManager.getDriver());
        assertTrue("Microsite Search page is not ready.", micrositepage.isReady());

        AdvanceSearchPage AdvanceSearchPage = new AdvanceSearchPage(DriverManager.getDriver());
        assertTrue("Microsite Advanced Search page is not ready.", AdvanceSearchPage.isAdvanceSearchOpen());

        generalPage.closingMicrosite();

        generalPage.switchingToDefaultwindow(defaultWindow);

        // Delete Microsite
        generalPage.deleteMicrosite(micrositeName);

        // Asserting that Microsite is deleted
        assertTrue("Microsite is not Deleted", generalPage.isMicroSiteDeleted(micrositeName));

        // Perform the logout action.
        logoutPage = logoutAux(dashboard.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End createMicrosite method: " + method.getName());
    }

    /**
     * Uploading Microsite Logos:
     * 
     * -# @see loginAux() 
     * -# Go to Profile and get the roles. 
     * -# Get the list of the sections visible. 
     * -# Navigate to Administration area. 
     * -# Navigate to 'Microsite'. 
     * -# Validate General Page. 
     * -# Click on Add Microsite 
     * -# Upload Logos for Desktop,Mobile and Tablets 
     * -# Click on Save create a microsite. 
     * -# Verify Microiste has created 
     * -# Navigate to Newly created site 
     * -# Assert that it is navigated to new Microsite 
     * -# Verify that the Desktop Logo in microsite which we have uploaded in Portalclient 
     * -# Close the Mocrosite and switch to the PortalClient Window 
     * -# Edit the Microsite and Delete the Created Logos 
     * -# Delete the site 
     * -# @see logoutAux()
     * 
     * @param method
     * @throws IOException
     * @throws AWTException
     */

    @Test(enabled = true, priority = 3, description = "Verify uploading of Logos to Microsite.")
    public void uploadMicrositeLogo(Method method) throws IOException, AWTException {

        log.info("[log-TestSet] " + this.getClass().getName() + " - Start uploadBanners method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Microsite General tab'.
        MicrositeGeneralPage generalPage = (MicrositeGeneralPage) dashboard
                .goToSpecificSectionOrSubSectionPage(SectionType.GENERAL_MICROSITES);

        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Click on 'Add Microsite'.
        CreateAndEditMicrositeGeneralPage createMicrositePage = generalPage.goToAddMicrosite();
        assertTrue("Create Microsite page is not ready.", createMicrositePage.isReady());

        // Add a new Microsite.
        String micrositeName = "Microsite - " + new Date().getDate() + new Date().getTime();
        String seoMetadata = "Filling SEO Metadata filed";
        String authenticationType = "Public";
        createMicrositePage.fillDetailsinGenaralPage(micrositeName, seoMetadata, authenticationType);

        // upload Desktop logo
        createMicrositePage.uploadDesktopLogo("MS_Desktop_Logo.jpg");

        // Upload Mobile Logo
        createMicrositePage.uploadMobileLogo("MS_Mobile_Logo.jpg");

        // upload Tablet Logo
        createMicrositePage.uploadTabletLogo("MS_Tablet_Logo.jpg");

        // Saving the Mcirosite
        createMicrositePage.clickOnSave();

        // Editing the Mcirosite with a new name
        generalPage.editMicrosite(micrositeName);

        // Getting image scr from editing mode and saving Logo
        String mssrc = createMicrositePage.getImageSrc();
        createMicrositePage.clickOnSave();

        // Accesing microsite
        String friendlyURL = generalPage.getMicrositeURL(micrositeName);
        String defaultWindow = generalPage.handlingNewWindow();
        // Switing to new microsite
        generalPage.switchingToNewMicrosite(friendlyURL);

        MicrositePage micrositepage = new MicrositePage(DriverManager.getDriver());
        assertTrue("Microsite Search page is not ready.", micrositepage.isReady());
        // Getting Mcicrosite Logo src
        String micrositeSrc = micrositepage.getDesktopLogo();

        // Asserting both the Microsite and Uploded desktop SRC
        assertTrue("Microsite uploading of Logos failed.", micrositepage.isCompare(mssrc, micrositeSrc));

        // Closing Microsite and Switching DH Page
        generalPage.closingMicrosite();
        generalPage.switchingToDefaultwindow(defaultWindow);

        // Editing Microsite and deleting to Logo
        generalPage.editMicrosite(micrositeName);
        createMicrositePage.deleteLogos();
        createMicrositePage.clickOnSave();

        // Delete Microsite
        generalPage.deleteMicrosite(micrositeName);

        // Asserting that Microsite is deleted
        assertTrue("Microsite should be  Deleted", generalPage.isMicroSiteDeleted(micrositeName));

        // Perform the logout action.
        logoutPage = logoutAux(dashboard.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End uploadBanners method: " + method.getName());

    }

    /**
     * Selcting Microsite Logos from collections:
     * 
     * -# @see loginAux() 
     * -# Go to Profile and get the roles. 
     * -# Get the list of the sections visible.
     * -# Navigate to Administration area. 
     * -# Navigate to 'Microsite'. 
     * -# Validate General Page. 
     * -# Click on Add Microsite 
     * -# Select Logos for Desktop,Mobile and Tablets from the collections 
     * -# Click on Save create a microsite. 
     * -# Verify Microiste has created 
     * -# Navigate to Newly created site 
     * -# Assert that it is navigated to new Microsite 
     * -# Verify that the Desktop Logo in microsite which we have uploaded in Portalclient 
     * -# Close the Mocrosite and switch to the PortalClient Window
     * -# Edit the Microsite and Delete the Created Logos 
     * -# Delete the site
     * -# @see logoutAux()
     * 
     * @param method
     * @throws IOException
     * @throws AWTException
     * @param method
     * @throws IOException
     * @throws AWTException
     */

    @Test(enabled = true, priority = 4, description = "Verify selecting Logos from Collections to  Microsite.")
    public void selectMicrositeLogosFromCollection(Method method) throws AWTException {

        log.info("[log-TestSet] " + this.getClass().getName() + " - Start uploadBanners method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create a collection
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Albums");
        collectionName = collectionPage.getTitle();

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Microsite General tab'.
        MicrositeGeneralPage generalPage = (MicrositeGeneralPage) dashboard
                .goToSpecificSectionOrSubSectionPage(SectionType.GENERAL_MICROSITES);

        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Click on 'Add Microsite'.
        CreateAndEditMicrositeGeneralPage createMicrositePage = generalPage.goToAddMicrosite();
        assertTrue("Create Microsite page is not ready.", createMicrositePage.isReady());

        // Add a new Microsite.
        String micrositeName = "Microsite - " + new Date().getDate() + new Date().getTime();
        String seoMetadata = "Filling SEO Metadata filed";
        String authenticationType = "Public";
        createMicrositePage.fillDetailsinGenaralPage(micrositeName, seoMetadata, authenticationType);

        // Selcting Desktop Logo from Collections
        // click select Image from collection for Destop logo
        createMicrositePage.selectDesktopLogoFromCollection(collectionName);

        // Slecting Tablet Logo from Collections
        createMicrositePage.selectTabletLogoFromCollection(collectionName);

        // Slecting Mobile Logo from Collections
        createMicrositePage.selectMobileLogoFromCollection(collectionName);

        // saving the microsite page
        createMicrositePage.clickOnSave();

        // Editing microsite
        generalPage.editMicrosite(micrositeName);

        // Getting SRC value of Image
        String mssrc = createMicrositePage.getImageSrc();
        createMicrositePage.clickOnSave();

        // Accesing microsite
        String friendlyURL = generalPage.getMicrositeURL(micrositeName);
        String defaultWindow = generalPage.handlingNewWindow();
        generalPage.switchingToNewMicrosite(friendlyURL);

        // Verifying microsite page is ready
        MicrositePage micrositepage = new MicrositePage(DriverManager.getDriver());
        assertTrue("Microsite Search page is not ready.", micrositepage.isReady());

        // Getting the src of desktop Logo
        String micrositeSrc = micrositepage.getDesktopLogo();

        // Comparing if both the logos are matching
        assertTrue("Microsite uploading of Logos failed.", micrositepage.isCompare(mssrc, micrositeSrc));

        // closing the Mcirosite and switching to default window
        generalPage.closingMicrosite();
        generalPage.switchingToDefaultwindow(defaultWindow);

        // Editing the Microsite and deleting the Logos
        generalPage.editMicrosite(micrositeName);
        createMicrositePage.deleteLogos();
        createMicrositePage.clickOnSave();

        // Delete Microsite
        generalPage.deleteMicrosite(micrositeName);

        // Asserting that Microsite is deleted
        assertTrue("Microsite is not Deleted", generalPage.isMicroSiteDeleted(micrositeName));

        // Perform the logout action.
        logoutPage = logoutAux(dashboard.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End uploadBanners method: " + method.getName());
    }

    /**
     * Verifying Microsite expiry dates:
     * 
     * -# @see loginAux() 
     * -# Go to Profile and get the roles. 
     * -# Get the list of the sections visible. 
     * -# Navigate to Administration area. 
     * -# Navigate to 'Microsite'. 
     * -# Validate General Page. 
     * -# Click on Add Microsite .
     * -# Create Microsite with current date. 
     * -# Verify that The site is enabled.
     * -# Create a Microsite with future days. 
     * -# Verify that site status is 
     * -# Create a Scheduled 
     * -# access the scheduled microsite and verify microsite with Previous dates 
     * -# Verify that the site status is expired and it is not accessable 
     * -# Close the Microsite and switch to the PortalClient Window 
     * -# Delete the site 
     * -# @see logoutAux()
     * 
     * @param method
     * @throws IOException
     * @throws AWTException
     * @param method
     * @throws AWTException
     */
    @Test(enabled = true, priority = 5, description = "Verify expiry date for microsite.")
    public void checkMicrositeExpiryDateTest(Method method) throws AWTException {

        log.info("[log-TestSet] " + this.getClass().getName() + " - Start checkMicrositeExpiryDateTest method: "
                + method.getName());

        String homePageURL = DriverManager.getDriver().getCurrentUrl();
        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Microsite General tab'.
        MicrositeGeneralPage generalPage = (MicrositeGeneralPage) dashboard
                .goToSpecificSectionOrSubSectionPage(SectionType.GENERAL_MICROSITES);
        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Click on 'Add Microsite'.
        CreateAndEditMicrositeGeneralPage createMicrositePage = generalPage.goToAddMicrosite();
        assertTrue("Create Microsite page is not ready.", createMicrositePage.isReady());

        // Add a new Microsite.
        String micrositeName = "Microsite - " + new Date().getDate() + new Date().getTime();
        String seoMetadata = "Filling SEO Metadata filed";
        String authenticationType = "Public";
        createMicrositePage.fillDetailsinGenaralPage(micrositeName, seoMetadata, authenticationType);

        // Getting the date values for today, yesterday and tomorrow
        Date date = new Date();
        Date increment = DateUtils.addDays(date, 1);
        Date incrementbyTwoDays = DateUtils.addDays(date, 2);
        Date decrement = DateUtils.addDays(date, -1);
        Date decrementByTwoDays = DateUtils.addDays(date, -2);
        // Date formatter
        Format formatter = new SimpleDateFormat("dd/MM/yyyy ");
        // assigning date values for the field names
        String todaysDate = formatter.format(date);
        String tommorowsDate = formatter.format(increment);
        String yesterdaysDate = formatter.format(decrement);
        String dayAfterTommorowDate = formatter.format(incrementbyTwoDays);
        String dayBeforeYesterdayDate = formatter.format(decrementByTwoDays);

        // Fill the expiry dates when site is enabled
        createMicrositePage.fillMicrositeExpirydate(todaysDate, tommorowsDate);
        createMicrositePage.clickOnSave();
        assertTrue("The Status of the site is != Enabled", generalPage.getMicrositeStatus(micrositeName)
                .equalsIgnoreCase("Enabled"));

        // Accesing microsite
        String friendlyURL = generalPage.getMicrositeURL(micrositeName);
        String defaultWindow = generalPage.handlingNewWindow();
        generalPage.switchingToNewMicrosite(friendlyURL);

        MicrositePage micrositepage = new MicrositePage(DriverManager.getDriver());
        assertTrue("Microsite Search page is not ready.", micrositepage.isReady());
        assertTrue("When site is enabled it is not redirected to Microsite", friendlyURL
                .equalsIgnoreCase(generalPage.getBrowserURL()));

        // Closing Microsite and switching back to default window
        generalPage.closingMicrosite();
        generalPage.switchingToDefaultwindow(defaultWindow);

        // creating microsite with future dates and verify the status of site is changed to scheduled
        generalPage.editMicrosite(micrositeName);
        createMicrositePage.fillMicrositeExpirydate(tommorowsDate, dayAfterTommorowDate);
        createMicrositePage.clickOnSave();
        assertTrue("The Status of the site is != Scheduled", generalPage.getMicrositeStatus(micrositeName)
                .equalsIgnoreCase("Scheduled"));
        friendlyURL = generalPage.getMicrositeURL(micrositeName);
        defaultWindow = generalPage.handlingNewWindow();
        generalPage.switchingToNewMicrosite(friendlyURL);
        assertTrue("When site is enabled it is not redirected to Microsite", homePageURL
                .contains(generalPage.getBrowserURL()));

        // Closing Microsite and switching back to default window
        generalPage.closingMicrosite();
        generalPage.switchingToDefaultwindow(defaultWindow);

        generalPage.editMicrosite(micrositeName);

        // Creating Microsite with previous dates and verifying if the status of the site is expired
        generalPage.editMicrosite(micrositeName);
        createMicrositePage.fillMicrositeExpirydate(dayBeforeYesterdayDate, yesterdaysDate);
        assertTrue("Exipry Date validation should be shown", createMicrositePage.isExpiryDateValidationShown());
        createMicrositePage.clickOnSave();
        assertTrue("The Status of the site is != Expired", generalPage.getMicrositeStatus(micrositeName)
                .equalsIgnoreCase("Expired"));
        friendlyURL = generalPage.getMicrositeURL(micrositeName);
        defaultWindow = generalPage.handlingNewWindow();
        generalPage.switchingToNewMicrosite(friendlyURL);
        assertTrue("When site is expired it is not redirected to Microsite", homePageURL
                .contains(generalPage.getBrowserURL()));

        // Closing Microsite and switching back to default window
        generalPage.closingMicrosite();
        generalPage.switchingToDefaultwindow(defaultWindow);

        // Delete Microsite
        generalPage.deleteMicrosite(micrositeName);
        // Asserting that Microsite is deleted
        assertTrue("Microsite is not Deleted", generalPage.isMicroSiteDeleted(micrositeName));

        // Perform the logout action.
        logoutPage = logoutAux(dashboard.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End checkMicrositeExpiryDateTest method: "
                + method.getName());

    }

    /**
     * GoBack to General Page
     * 
     * -# @see loginAux() 
     * -# Go to Profile and get the roles. 
     * -# Get the list of the sections visible. 
     * -# Navigate to Administration area. 
     * -# Navigate to 'Microsite'. 
     * -# Validate General Page. 
     * -# Click on Add Microsite 
     * -# From the General tab click on back button 
     * -# It should be redirected to 
     * -# Click on back button Microsite genral page 
     * -# Navigate to Security tab 
     * -# Navigate to Metadata so that user should be navigated to general page tab
     * -# Click on back button so that user should be navigated to general page
     * -# Navigate to Links and Banners tab 
     * -# Click on back button so that 
     * -# Navigate to Folders and user should be navigated to general page Filters tab 
     * -# Click on back button so that user should be navigated to general pages
     * -# Navigate to Customization tab 
     * -# Click on back button so that user should be navigated to general page 
     * -# @see logoutAux()
     * 
     * @param method
     * @throws IOException
     * @throws AWTException
     * @param method
     * @throws AWTException
     */
    @Test(enabled = true, priority = 6, description = "GoBack from add microsite to Microsite General page")
    public void goBackToMicrositeGeneralPage(Method method) throws AWTException {

        log.info("[log-TestSet] " + this.getClass().getName() + " - Start goBackToMicrositeGeneralPage method: "
                + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Microsite General tab'.
        MicrositeGeneralPage generalPage = (MicrositeGeneralPage) dashboard
                .goToSpecificSectionOrSubSectionPage(SectionType.GENERAL_MICROSITES);
        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Click on 'Add Microsite'.
        CreateAndEditMicrositeGeneralPage createMicrositePage = generalPage.goToAddMicrosite();
        createMicrositePage.waitForReady();
        assertTrue("Create Microsite page is not ready.", createMicrositePage.isReady());

        // Click on microsite and check if microsite is ready
        createMicrositePage.clickBackButton();
        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Navigate to security tab
        generalPage.goToAddMicrosite();
        assertTrue("Create Microsite page is not ready.", createMicrositePage.isReady());
        createMicrositePage.navigateSecuritytab();
        assertTrue("Required field should be shown.", createMicrositePage.isRequiredFieldMessageShown());
        assertTrue("Error Message for Required field is shown.", createMicrositePage
                .isErrorMessageIsShownForRequiredField());
        createMicrositePage.navigateSecuritytab();
        createMicrositePage.waitForSecurityTabReady();

        // check if it is navigated to security tab
        assertTrue("It is not  navigated to  security tab ", createMicrositePage.isSecurityTabReady());
        createMicrositePage.clickBackButton();
        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Navigate to Metadata tab
        generalPage.goToAddMicrosite();
        assertTrue("Create Microsite page is not ready.", createMicrositePage.isReady());
        createMicrositePage.navigateMetadatatab();
        assertTrue("Required field should be shown.", createMicrositePage.isRequiredFieldMessageShown());
        assertTrue("Error Message for Required field is shown.", createMicrositePage
                .isErrorMessageIsShownForRequiredField());
        createMicrositePage.navigateMetadatatab();
        createMicrositePage.waitForMetadataTabReady();

        // Check if it is navigated to Metadata tab
        assertTrue("Metadata tab should be ready", createMicrositePage.isMetadataTabReady());
        createMicrositePage.clickBackButton();
        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Navigate to Links and banners
        generalPage.goToAddMicrosite();
        assertTrue("Create Microsite page is not ready.", createMicrositePage.isReady());
        createMicrositePage.navigateLinksAndBannersstab();
        assertTrue("Required field should be shown.", createMicrositePage.isRequiredFieldMessageShown());
        assertTrue("Error Message for Required field is shown.", createMicrositePage
                .isErrorMessageIsShownForRequiredField());
        createMicrositePage.navigateLinksAndBannersstab();
        createMicrositePage.waitForLinksAndBannersTabReady();

        // Check if it is navigated to links and banners tab
        assertTrue("USer should be navigated to Links and Banners tab and the page should be ready", createMicrositePage
                .isLinksAndBannersTabReady());
        createMicrositePage.clickBackButton();
        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Navigate to Folders and filters tab
        generalPage.goToAddMicrosite();
        assertTrue("Create Microsite page is not ready.", createMicrositePage.isReady());
        createMicrositePage.navigateFoldersAndFilterstab();
        assertTrue("Required field should be shown.", createMicrositePage.isRequiredFieldMessageShown());
        assertTrue("Error Message for Required field is shown.", createMicrositePage
                .isErrorMessageIsShownForRequiredField());
        createMicrositePage.navigateFoldersAndFilterstab();
        createMicrositePage.waitForFoldersAndFiltersTabReady();

        // check if it is navigated to Folder and filters tab
        assertTrue("User should be navigate to Folders and filters tab", createMicrositePage
                .isFoldersAndFiltersTabReady());
        createMicrositePage.clickBackButton();
        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Navigate to customization tab
        generalPage.goToAddMicrosite();
        assertTrue("Create Microsite page is not ready.", createMicrositePage.isReady());
        createMicrositePage.navigateCustomizationtab();
        assertTrue("Required field should be shown.", createMicrositePage.isRequiredFieldMessageShown());
        assertTrue("Error Message for Required field is shown.", createMicrositePage
                .isErrorMessageIsShownForRequiredField());
        createMicrositePage.navigateCustomizationtab();
        createMicrositePage.waitForCustomizationTabTabReady();
        // check if it is navigated custamization tab
        assertTrue("User should be navigated to Customization tab", createMicrositePage.isCustomizationTabReady());
        createMicrositePage.clickBackButton();
        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Perform the logout action.
        logoutPage = logoutAux(dashboard.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End goBackToMicrositeGeneralPage method: "
                + method.getName());

    }

    /**
     * Create Public Microsite and access it:
     * 
     * -# @see loginAux() 
     * -# Go to Profile and get the roles. 
     * -# Get the list ofthe sections visible. 
     * -# Navigate to Administration area. 
     * -# Navigate to Security tab -> Content Permission Mapping. 
     * -# Create a Filter which is Microsite enabled 
     * -# Save it 
     * -# Navigate to 'Microsite'. 
     * -# Validate General Page. 
     * -# Click on Add Microsite. 
     * -# Go to Genral tab of Add Microsite button. 
     * -# Fill Details in General Page with name, seo details and Dont select the enebled button as it is a private site. 
     * -# Navigate to Security tab .
     * -# Select a type to "Authentic". 
     * -# In the user Acess table select the "SEC-MBLabAdmins". 
     * -# Create test user from "AddUser" button and select the user. 
     * -# Navigate to Metdata tab .
     * -# Select the Parameters for Metadata tab .
     * -# Navigate Links and Banners Tab .
     * -# Creat New Links and Banners and Select them .
     * -# Navigate to Foldera dn filters tab. 
     * -# Select a filter .
     * -# Move to customization tab.
     * -# enable Advance search and Select diff colors for diff sections. 
     * -# Click on save Button .
     * -# Navigate to New Microsite .
     * -# Assert that all the above created details are present in the Microsite.
     * -# CLose the Microsite .
     * -# Clone the Microsite from Genereal Tab Delete the Microsite and CLoned Microsite.
     * -# @see logoutAux()
     * 
     * @param method
     * @throws Exception 
     */
    @Test(enabled = true, priority = 7, description = "Create and access a new Private Microsite and Clone a site")
    public void createAndAccessPrivateMicroSite(Method method) throws Exception {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start createAndAccessPrivateMicroSite method: "
                + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Creating collection

        if (collectionName == null) {
            collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Albums");
            collectionName = collectionPage.getTitle();
        }
        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'CONTENT_PERMISSION'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CONTENT_PERMISSION);

        // Validate LDAP page
        ContentPermissionsPage filters = new ContentPermissionsPage(DriverManager.getDriver(), sections);
        assertTrue("Filter page is not ready.", filters.isReady());

        // Create new filters
        filters.clickOnAddFilterButton();
        assertTrue("Filter Add page is not ready.", filters.isAddFilterReady());

        // Fill the details
        String filterName = "Permission" + new Date().getDate() + new Date().getTime();
        String description = "Description" + new Date().getDate() + new Date().getTime();
        filters.fillFilterDetails(filterName, description, "Content Type", "Image", "Microsite");

        // Click On save
        filters.clickOnSave();
        assertTrue("Filter page is not ready.", filters.isConditionExistsInList(filterName));
        // Go back to dashboard
        filters.goBack();

        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.GENERAL_MICROSITES);
        // Navigate to 'Microsite General tab'.
        MicrositeGeneralPage generalPage = new MicrositeGeneralPage(DriverManager.getDriver(), sections);
        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // Click on 'Add Microsite'.
        CreateAndEditMicrositeGeneralPage createMicrositePage = generalPage.goToAddMicrosite();
        assertTrue("Create Microsite page is not ready.", createMicrositePage.isReady());

        // Add a new Microsite.
        String micrositeName = "Microsite - " + new Date().getDate() + new Date().getTime();
        String seoMetadata = "Filling SEO Metadata filed";
        String authenticationType = "Authentication";
        createMicrositePage.fillDetailsinGenaralPage(micrositeName, seoMetadata, authenticationType);

        // Navigate to security tab
        createMicrositePage.navigateSecuritytab();
        createMicrositePage.waitForSecurityTabReady();

        // check if it is navigated to security tab
        assertTrue("It is not  navigated to  security tab ", createMicrositePage.isSecurityTabReady());

        // selecting the private microsite

        createMicrositePage.selectAutheticationType(authenticationType);
        assertTrue("Private authentication type is not selected", createMicrositePage
                .isPrivateAuthenticationtypeeSelected());
        createMicrositePage.selectAuthorizedgroups();

        // creating Testusers and adding it to the microsite
        String TestuserName = "Testuser" + new Date().getDate() + new Date().getTime();
        createMicrositePage.createTestUser(TestuserName, "password123");
        createMicrositePage.selectTestusers(TestuserName);

        // Creating Metadata from Metadata tab
        createMicrositePage.navigateMetadatatab();
        createMicrositePage.waitForMetadataTabReady();

        // Verify if it is navigated to Metadatatab
        assertTrue("User should be navigated to Metadata tab", createMicrositePage.isMetadataTabReady());

        createMicrositePage.expandAllSections();

        // Select the options for Paramentric filters
        createMicrositePage.selectOptionsForParametricFiltersDisplayedOnTable();
        assertTrue("Both the values should match for parametric filters", createMicrositePage
                .getSelectedListParametricFiltersDisplayed()
                .containsAll(createMicrositePage.getListToBeselectedInParametricFilters()));

        // Select the options for asset thumbnails - Information displayed on
        // hover
        createMicrositePage.selectOptionsForAssetThumbnailsInformationDisplayedOnHover();
        createMicrositePage.moveControlsOfSelectedListForAssetThumbnailsInformationDisplayedOnHover();
        assertTrue("The values should match for asset thumbnails - Information displayed on hover", createMicrositePage
                .getSelectedListForAssetThumbnailsInformationDisplayedOnHover()
                .containsAll(createMicrositePage.getListToBeselectedInAssetThumbnailsInformationDisplayedOnHover()));

        // Select the options for asset thumbnails - Information displayed In
        // Table Columns
        createMicrositePage.selectOptionsForAssetListInformationDisplayedInTable();
        createMicrositePage.moveControlsOfSelectedListForAssetListInformationDisplayedInTable();

        assertTrue("The values should match for asset thumbnails - Information displayed on hover", createMicrositePage
                .getSelectedListForAssetListInformationDisplayedInTable()
                .containsAll(createMicrositePage.getListToBeselectedInAssetListInformationDisplayedInTable()));

        // Select the options for Asset table
        createMicrositePage.selectOptionsForAssetInformation();
        createMicrositePage.moveControlsOfSelectedListForAssetInformation();

        assertTrue("The values should match for AssetInformation", createMicrositePage
                .getSelectedListForAssetInformation()
                .containsAll(createMicrositePage.getListToBeselectedInAssetInformation()));

        // Select the options for Sort tab
        createMicrositePage.selectOptionsForSortTab();
        createMicrositePage.moveControlsOfSelectedListForSortTab();

        assertTrue("The values should match for Metadata", createMicrositePage.getSelectedListForSortTab()
                .containsAll(createMicrositePage.getListToBeselectedInSortTab()));

        // Creating Links and Banners
        createMicrositePage.navigateLinksAndBannersstab();
        createMicrositePage.waitForLinksAndBannersTabReady();

        // Check if it is navigated to links and banners tab
        assertTrue("User should be navigated to Links and Banner tab ", createMicrositePage
                .isLinksAndBannersTabReady());

        // Create the New link and select the Link
        String Link = "Link" + new Date().getDate() + new Date().getTime();
        String URL = "https://www.google.co.in";
        createMicrositePage.createLink(Link, URL);
        createMicrositePage.selectLink(Link);

        // Create the New Banners and select them
        String BannerfromCollection = "Banner" + new Date().getDate() + new Date().getTime();

        createMicrositePage.addBannerFromCollection(BannerfromCollection, collectionName);
        createMicrositePage.selectBanner(BannerfromCollection);

        String bannerFromExternalImage = "Banner-External-" + new Date().getDate() + new Date().getTime();
        String bannerURL = "http://www.hdwallpapers.in/walls/cute_haircut_baby_girl-wide.jpg";
        createMicrositePage.addBannerFromExternalImage(bannerFromExternalImage, bannerURL);
        createMicrositePage.selectBanner(bannerFromExternalImage);

        String bannerFromUploadImage = "Banner-upload-" + new Date().getDate() + new Date().getTime();

        createMicrositePage.addBannerFromUploadImage(bannerFromUploadImage, "MS_Desktop_Logo.jpg");
        createMicrositePage.selectBanner(bannerFromUploadImage);

        // Folders and filters tab
        createMicrositePage.navigateFoldersAndFilterstab();
        createMicrositePage.waitForFoldersAndFiltersTabReady();

        // check if it is navigated to Folder and filters tab
        assertTrue("User should be able to navigated to Folders and Filters tab", createMicrositePage
                .isFoldersAndFiltersTabReady());
        createMicrositePage.selectFilterForMicrosite(filterName);

        // customization tab
        createMicrositePage.navigateCustomizationtab();
        createMicrositePage.waitForCustomizationTabTabReady();

        // verifiy if navigated to customizationtab
        assertTrue("User should be able to navigated to Customization tab", createMicrositePage
                .isCustomizationTabReady());
        createMicrositePage.enableAdvancesearchInMicrosite();

        /*   String redColor = "ff0000";
        String bluecolor = "0000ff";
        String greenColor = "008000";
        String purpleColor = "800080";
        
        // Select colors for Diff tabs
        List<String> HeaderBasiccolorList = createMicrositePage.selectHeaderGradient(redColor);
        assertTrue("The list of color in HeaderGradient should match", createMicrositePage.basicColors()
                .containsAll(HeaderBasiccolorList));
        
        List<String> LinkColorBasiccolorList = createMicrositePage.selectLinkColor(bluecolor);
        assertTrue("The list of color in LinkColor should match", createMicrositePage.basicColors()
                .containsAll(LinkColorBasiccolorList));
        
        List<String> SearchBasiccolorList = createMicrositePage.selectSearchGradientr(greenColor);
        System.out.println(SearchBasiccolorList);
        assertTrue("The list of color in searchGradient should match", createMicrositePage.basicColors()
                .containsAll(SearchBasiccolorList));
        
        List<String> TextColorBasiccolorList = createMicrositePage.selectTextColor(purpleColor);
        assertTrue("The list of color in selectText should match", createMicrositePage.basicColors()
                .containsAll(TextColorBasiccolorList));*/

        // Save microsite
        createMicrositePage.clickOnSave();

        // Accesing microsite
        String friendlyURL = generalPage.getMicrositeURL(micrositeName);
        String defaultWindow = generalPage.handlingNewWindow();

        generalPage.switchingToNewMicrosite(friendlyURL);

        // Logging in to Microsite
        MicrositeLoginPage loginpage = new MicrositeLoginPage(DriverManager.getDriver());
        loginpage.micrositeLogin(TestuserName, "password123");

        MicrositePage microsite = new MicrositePage(DriverManager.getDriver());

        assertTrue("Microsite page is not ready", microsite.isPrivateMicrositePageReady());

        // assertTrue("TestUser is not logged in", microsite.isTestUser(TestuserName));

        // holding as links design is yet to confirm Asserting Link is present and its name is same as we created
        assertTrue("Created Link is not shown", microsite.isLinkshown());
        assertTrue("Link name is correct", microsite.getLinkName().equalsIgnoreCase(Link));

        // accessing New Link
        String currentwindow = microsite.accessingLink(Link);

        assertTrue("we are not accessing the correct link", DriverManager.getDriver().getCurrentUrl().contains(URL));
        DriverManager.getDriver().close();
        generalPage.switchingToDefaultwindow(currentwindow);

        assertTrue("Banner is not present", microsite.isBannerShown());

        List<String> overlayList = microsite.accessAssetOverlay();
        assertTrue("Both the Values should mach for Asset Thumbanil Information display on hover", overlayList
                .containsAll(createMicrositePage.getSelectedListForAssetThumbnailsInformationDisplayedOnHover()));

        List<String> metadataOfAsset = microsite.getMetadataForAsset();

        // Close the asset details modal.
        assertTrue("Both the Values should mach for Metadata tab of AssetInformation", metadataOfAsset
                .containsAll(createMicrositePage.getSelectedListForAssetInformation()));

        List<String> thumbnailInfo = microsite.switchtoListView();
        assertTrue("Both the Values should mach for Asset Thumbanil Information display on hover", thumbnailInfo
                .containsAll(createMicrositePage.getSelectedListForAssetListInformationDisplayedInTable()));

        List<String> searchsortOptions = microsite.searchSortOptions();
        assertTrue("Both the Values should mach for Asset Thumbanil Information display on hover", searchsortOptions
                .containsAll(createMicrositePage.getSelectedListForSortTab()));

        List<String> facetselectorOptions = microsite.facetSelectorOptionsInAdvanceSearch();
        assertTrue("Both the Values should mach for facet Selector options for Advance search", facetselectorOptions
                .containsAll(createMicrositePage.getSelectedListParametricFiltersDisplayed()));

        assertTrue("Mime type field si shown", microsite.isMimeTypeFieldPresent());
        assertTrue("Images types should be present in the Image Mime Type", microsite.getMimeTypevalues().toString()
                .contains("image/jpeg "));

        generalPage.closingMicrosite();

        generalPage.switchingToDefaultwindow(defaultWindow);

        generalPage.cloneMicrosite(micrositeName);

        createMicrositePage.clickOnSave();

        String clonesiteName = micrositeName + " " + "(clone)";
        assertTrue("Create general page is not ready.", generalPage.isReady());
        assertTrue("The new microsite name is not shown", generalPage
                .isNewlyCreatedMicrositeNameShownInList(clonesiteName));

        // Delete Microsite
        generalPage.deleteMicrosite(micrositeName);
        generalPage.deleteMicrosite(clonesiteName);

        // Asserting that Microsite is deleted
        assertTrue("Microsite is not Deleted", generalPage.isMicroSiteDeleted(micrositeName));
        assertTrue("Microsite is not Deleted", generalPage.isMicroSiteDeleted(clonesiteName));
        assertTrue("Microsite page is not ready.", generalPage.isReady());

        // generalPage.deleteAllMicrosite();
        logoutPage = logoutAux(dashboard.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End createAndAccessPrivateMicroSite method: "
                + method.getName());
    }

    /**
     * -# @see loginAux() - 
     * -# Go to Profile and get the roles. 
     * -# Get the list of the sections visible. 
     * -# Navigate to Administration area. 
     * -# Navigate to 'Microsite'. 
     * -# Navigate to links tab 
     * -# Validate Links tab 
     * -# Validate required message for required message for empty Linkfield empty URL field 
     * -# Canceling a link without saving it 
     * -# Creating a new link 
     * -# Search for the created Link 
     * -# Clear the search 
     * -# Click on Delete button and cancel the Delete 
     * -# Delete the Link 
     * -# Go back to dash board 
     * -# @see logoutAux()
     * 
     * @param method
     * @author mpapishe
     */

    @Test(enabled = true, priority = 8, description = "Create a Link for Microsite")
    public void accessLinksTab(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start accessLinksTab method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();

        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Microsite Links tab'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.LINKS);
        MicrositeLinksPage linksPage = new MicrositeLinksPage(DriverManager.getDriver(), sections);

        // validaing Links tab
        assertTrue("Microsite page is not ready.", linksPage.isReady());

        // verify if required message is shown if empty link field is given
        linksPage.addLink("", "https://www.google.co.in");
        linksPage.saveLink();
        assertTrue("Required message is not shown", linksPage.isRequiredMessageshown());

        // Canceling the link
        linksPage.cancelLink();
        // Required message is shown if URL is not given
        linksPage.addLink("testLink", "");

        linksPage.saveLink();
        // assertTrue("Required message is not shown", linksPage.isRequiredMessageshown());

        // Canceling the link
        // linksPage.cancelLink();

        // Cancel a link without saving it
        link = "Link" + new Date().getDate() + new Date().getTime();
        URL = "https://www.google.co.in";

        // Addling Link and URL text fields
        linksPage.addLink(link, URL);

        linksPage.cancelLink();
        // asserting that link is not created
        assertTrue("Link shouldn't be created ", !(linksPage.isNewlyCreatedLinkNameShownInList(link)));

        // Create and save a new link
        linksPage.addLink(link, URL);
        linksPage.saveLink();

        // asserting that link is created
        assertTrue("Newly created link is not shown ", linksPage.isNewlyCreatedLinkNameShownInList(link));

        // Goback to Dashboard
        /*  linksPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());
        
        // Navigate to 'Microsite Links tab'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.LINKS);
        */
        // Searching for Created Link
        linksPage.searchforLink(link);
        linksPage.emptySearchTab();

        String editedLink = linksPage.editLink(link);
        assertTrue("Edited Link name is not changed", linksPage.isNewlyCreatedLinkNameShownInList(editedLink));

        // Cancel Deleting the created Link
        linksPage.cancelDeleteLink(editedLink);
        assertTrue("Link should not be deleted", linksPage.isNewlyCreatedLinkNameShownInList(editedLink));

        // Delete the created Link
        linksPage.deleteLink(editedLink);
        assertTrue("Link should be deleted", !(linksPage.isNewlyCreatedLinkNameShownInList(editedLink)));

        // Goback to Dashboard
        linksPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        logoutPage = logoutAux(dashboard.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End accessLinksTab method: " + method.getName());

    }

    /**
     * -# @see loginAux() 
     * -# Go to Profile and get the roles. 
     * -# Get the list of the sections visible.
     * -# Navigate to Administration area. 
     * -# Navigate to 'Microsite'. 
     * -# Navigate to Banners tab 
     * -# Validate Banners tab 
     * -# Click on Add Banners tab 
     * -# Validate required message for empty Titlefield 
     * -# Validate required message for empty Type field 
     * -# Canceling a Banner without saving it 
     * -# Creating a new Banner from all the type like from collection,from External Image, from Upload image 
     * -# Search for the created Banner 
     * -# Clear the search 
     * -# Click on Delete button and cancel the Delete 
     * -# Delete the Banner 
     * -# Go back to dash board 
     * -#   @see logoutAux()
     *
     * 
     * @param method
     * @author mpapishe
     */
    @Test(enabled = true, priority = 9, description = "Create a Banner for Microsite")
    public void accessBannersTab(Method method) throws IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start accessBannersTab method: "
                + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        if (collectionName == null) {

            collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Albums");
            collectionName = collectionPage.getTitle();
        }

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();

        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Microsite Banners tab'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.BANNERS);

        MicrositeBannersPage bannersPage = new MicrositeBannersPage(DriverManager.getDriver(), sections);

        // Validating required field for banner title
        bannersPage.addBanner("", "External image");
        assertTrue("Required message should be shown", bannersPage.isRequiredMessageshown());

        bannersPage.goBackToBannersTab();
        bannersPage.selectOKButton();

        // Validating required message for collection type
        bannersPage.addBanner("Banner_title", "");
        assertTrue("Required message should be shown", bannersPage.isRequiredMessageshown());
        bannersPage.goBackToBannersTab();
        bannersPage.selectOKButton();

        String BannerFromCollection = "Banner-FromCollection-" + new Date().getDate() + new Date().getTime();

        // Create a new banner by selecting type as From collection
        bannersPage.addBannerFromCollection(BannerFromCollection, collectionName);
        assertTrue("Newly created banner from collection should be shown", bannersPage
                .isNewlyCreatedBannerNameShownInList(BannerFromCollection));

        // Editing the created banner
        String editedBanner = bannersPage.editBanner(BannerFromCollection);
        assertTrue("Newly created banner from collection should be shown", bannersPage
                .isNewlyCreatedBannerNameShownInList(editedBanner));
        assertTrue("Preview image is not shown correctly", bannersPage.isImagePreviewWrapperShown(editedBanner));

        bannersPage.goBackToBannersTab();

        // Fetching the Image preview src from banner
        String editBannersrc = bannersPage.getEditBannersrc(editedBanner);
        bannersPage.goBackToBannersTab();

        // validating banner in Preview and fetching the image src
        String previewBannerSRC = bannersPage.getPreviewBanner(editedBanner, "From collection");
        bannersPage.goBackToBannersTab();

        // Validating the banner is same from preview and edit banner locations
        assertTrue("Both the banner src should match", editBannersrc.equalsIgnoreCase(previewBannerSRC));

        // Try to delete a banner and cancel it from delete alert
        bannersPage.cancelDeleteBanner(editedBanner);
        assertTrue("Banner from collection should not be deleted", bannersPage
                .isNewlyCreatedBannerNameShownInList(editedBanner));

        // Delete Banner and verify that banner is deleted
        bannersPage.deleteBanner(editedBanner);
        assertTrue("Banner from collection should  be deleted", !(bannersPage
                .isNewlyCreatedBannerNameShownInList(editedBanner)));

        bannersPage.waitForReady();
        assertTrue("User should be navigated to banners page", bannersPage.isReady());

        String bannerFromExternalImage = "Banner-External-" + new Date().getDate() + new Date().getTime();
        String bannerURL = "http://www.hdwallpapers.in/walls/cute_haircut_baby_girl-wide.jpg";

        // Add a banner from External Image
        bannersPage.addBannerFromExternalImage(bannerFromExternalImage, bannerURL);
        assertTrue("Newly created banner from external image should be shown", bannersPage
                .isNewlyCreatedBannerNameShownInList(bannerFromExternalImage));

        // Editing the created banner
        editedBanner = bannersPage.editBanner(bannerFromExternalImage);
        assertTrue("Edited banner from collection should be shown", bannersPage
                .isNewlyCreatedBannerNameShownInList(editedBanner));
        assertTrue("Preview image shoule be shown", bannersPage.isImagePreviewWrapperShown(editedBanner));
        bannersPage.goBackToBannersTab();

        // Fetching the Image preview src from banner
        editBannersrc = bannersPage.getEditBannersrc(editedBanner);
        bannersPage.goBackToBannersTab();

        // validating banner in Preview and fetching the image src
        previewBannerSRC = bannersPage.getPreviewBanner(editedBanner, "External image");
        bannersPage.goBackToBannersTab();

        // Validating the banner is same from preview and edit banner locations
        assertTrue("Both the banner src should match", editBannersrc.equalsIgnoreCase(previewBannerSRC));

        // Try to delete a banner and cancel it from delete alert
        bannersPage.cancelDeleteBanner(editedBanner);
        assertTrue("Banner from collection should not be deleted", bannersPage
                .isNewlyCreatedBannerNameShownInList(editedBanner));

        // Delete Banner and verify that banner is deleted
        bannersPage.deleteBanner(editedBanner);
        assertTrue("Banner from collection should  be deleted", !(bannersPage
                .isNewlyCreatedBannerNameShownInList(editedBanner)));

        String bannerFromUploadImage = "Banner-upload-" + new Date().getDate() + new Date().getTime();

        bannersPage.addBannerFromUploadImage(bannerFromUploadImage, "MS_Desktop_Logo.jpg");
        assertTrue("Banner from collection should not be deleted", bannersPage
                .isNewlyCreatedBannerNameShownInList(bannerFromUploadImage));

        // Editing the created banner
        editedBanner = bannersPage.editBanner(bannerFromUploadImage);
        assertTrue("Edited banner from collection should be shown", bannersPage
                .isNewlyCreatedBannerNameShownInList(editedBanner));
        assertTrue("Preview image shoule be shown", bannersPage.isImagePreviewWrapperShown(editedBanner));

        bannersPage.goBackToBannersTab();

        // Fetching the Image preview src from banner
        editBannersrc = bannersPage.getEditBannersrc(editedBanner);
        bannersPage.goBackToBannersTab();

        // validating banner in Preview and fetching the image src
        previewBannerSRC = bannersPage.getPreviewBanner(editedBanner, "Uploaded image");
        bannersPage.goBackToBannersTab();

        // Validating the banner is same from preview and edit banner locations
        assertTrue("Both the banner src should match", editBannersrc.equalsIgnoreCase(previewBannerSRC));

        // Searching for Created Link
        bannersPage.searchforBanner(editedBanner);
        bannersPage.emptySearchTab();

        // Try to delete a banner and cancel it from delete alert
        bannersPage.cancelDeleteBanner(editedBanner);
        assertTrue("Banner from collection should not be deleted", bannersPage
                .isNewlyCreatedBannerNameShownInList(editedBanner));

        // Delete Banner and verify that banner is deleted
        bannersPage.deleteBanner(editedBanner);
        assertTrue("Banner from collection should  be deleted", !(bannersPage
                .isNewlyCreatedBannerNameShownInList(editedBanner)));

        // Goback to Dashboard
        bannersPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Logout from the application
        logoutPage = logoutAux(dashboard.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End accessBannersTab method: " + method.getName());

    }

    /**
     * -# @see loginAux() 
     * -# Go to Profile and get the roles. 
     * -# Get the list of the sections visible. 
     * -# Navigate to Administration area. 
     * -# Navigate to 'Microsite'. 
     * -# Navigate to Testusers tab 
     * -# Validate Testusers tab 
     * -# Go to "AddTestuser" by clicking on testuser button 
     * -# Validate required message for empty User Field 
     * -# Validate required message for empty Password field 
     * -# Validate required message for empty Confirm Password field 
     * -# Creating a new testuser 
     * -# verify that new testuser is shown in the testusers list 
     * -# Edit the created Tesatusre and verify that it is edited 
     * -# Search for the created testuser 
     * -# Clear the search 
     * -# Click on Delete button and cancel the Delete 
     * -# Delete the Testuser 
     * -# Go back to dash board 
     * -# @see logoutAux()
     * 
     * @param method
     * @author mpapishe
     */
    @Test(enabled = true, priority = 10, description = "Create a testuser for Microsite")
    public void accessTestusersTab(Method method) throws IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start accessTestusersTab method: "
                + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();

        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Microsite TestUsers tab'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.TEST_USERS);

        MicrositeTestUsersPage testusersPage = new MicrositeTestUsersPage(DriverManager.getDriver(), sections);

        // verifying that user is navigated to testuusers page
        testusersPage.waitForReady();
        assertTrue("User should be navigated to testusers tab", testusersPage.isReady());

        String Testuser = "Testuser" + new Date().getDate() + new Date().getTime();
        String password = "password123";
        String confirmPassword = "password123";

        // verify required message for Testusername textfield
        testusersPage.fillTestUserDetails("", password, confirmPassword);
        testusersPage.saveTestuser();
        assertTrue("Testuser name must be defined", testusersPage.isRequiredMessageshown());

        // Going back to testuser tab
        testusersPage.goBackToTestUSersTab();
        testusersPage.clickOnOkOfModal();

        // Verify required Invalid Passward message
        testusersPage.fillTestUserDetails(Testuser, "", confirmPassword);
        testusersPage.saveTestuser();
        assertTrue("Password must be given", testusersPage.isInvalidPasswordMessageshown());

        testusersPage.goBackToTestUSersTab();
        testusersPage.clickOnOkOfModal();
        // verify password do not match and required password message
        testusersPage.fillTestUserDetails(Testuser, "", "");
        testusersPage.saveTestuser();
        assertTrue("Testuser name must be defined", testusersPage.isRequiredMessageshown());

        testusersPage.goBackToTestUSersTab();
        testusersPage.clickOnOkOfModal();

        // create a testuser
        testusersPage.fillTestUserDetails(Testuser, password, confirmPassword);

        // Save the test user
        testusersPage.saveTestuser();

        // Assert that testuser is created
        assertTrue("Testuser name must be shown in the List", testusersPage
                .isNewlyCreatedTestUsereShownInList(Testuser));

        // editing the Testusers and verify the edit
        String editedTestuser = testusersPage.editTestUser(Testuser, password, confirmPassword);
        assertTrue("No rows should be selected", testusersPage.isSelectedTabisEmpty());

        testusersPage.saveTestuser();
        assertTrue("Testuser name must be shown in the List", testusersPage
                .isNewlyCreatedTestUsereShownInList(editedTestuser));
        // Searching of the testuser , assert it and cclear it
        testusersPage.searchforTestuser(editedTestuser);
        assertTrue("Testuser must be visisble in search list", testusersPage
                .isNewlyCreatedTestUsereShownInList(editedTestuser));
        testusersPage.emptySearchTab();

        // Delete the testuser and cancel the delete operation
        testusersPage.cancelDeleteTestuserr(editedTestuser);
        assertTrue("Testuser must not be deleted", testusersPage.isNewlyCreatedTestUsereShownInList(editedTestuser));

        // Delete the testuser and verify thatit is deleted
        testusersPage.deleteTestUser(editedTestuser);
        assertTrue("Testuser must be deleted", !(testusersPage.isNewlyCreatedTestUsereShownInList(editedTestuser)));

        // Go back to Dashboard
        testusersPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Logout from the application.
        logoutPage = logoutAux(dashboard.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End accessBannersTab method: " + method.getName());

    }

}