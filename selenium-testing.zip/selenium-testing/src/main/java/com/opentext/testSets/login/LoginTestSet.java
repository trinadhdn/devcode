/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.login;

import static org.testng.AssertJUnit.assertTrue;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.pageObjects.login.LoginPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contain the tests of the Login page in the web application.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class LoginTestSet extends BasicTestSet {

    static Logger log = Logger.getLogger(LoginTestSet.class);

    public LoginTestSet() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
     * Check the Login page elements:
     * 
     * -# Go to PC web. -# Check Login page.
     */
    @Test(description = "Check the Login page elements.")
    public void checkLayout(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Go to PC web.
        loginPage = new LoginPage(DriverManager.getDriver());
        loginPage.waitForReady();
        // Check Landing page.
        assertTrue("Login page is not ready.", loginPage.isReady());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check a unsuccessful Login action:
     * 
     * -# Go to PC web. -# Perform login action with wrong credentials. -# Check
     * the Login page.
     */
    @Test(description = "Check the Login action.")
    public void loginUnsucessfullTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Go to PC web.
        loginPage = new LoginPage(DriverManager.getDriver());
        loginPage.waitForReady();
        assertTrue("Login page is not ready.", loginPage.isReady());

        // Perform login action.
        loginPage.login(UserDomain.WRONGCREDENTIALS, UserType.QA1);
        // Check Login page.
        assertTrue("Login page is not ready.", loginPage.isReady());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the Login action:
     * 
     * -# Go to PC web. -# Perform login action. -# Check Search page.
     */
    @Test(description = "Check the Login action.")
    public void loginTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Go to PC web.
        loginPage = new LoginPage(DriverManager.getDriver());
        loginPage.waitForReady();
        assertTrue("Login page is not ready.", loginPage.isReady());

        // Perform login action.
        searchPage = loginPage.login(UserDomain.SUPERADMIN, UserType.QA1);
        // Check Search page.
        assertTrue("Search page is not ready.", searchPage.isReady());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the Logout action:
     * 
     * -# @see logoutAux() -# Perform the logout action. -# Check the logout
     * page.
     */
    @Test(description = "Check the Logout action.")
    public void logoutTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Perform the logout action.
        logoutPage = searchPage.logout();

        // Check the logout page.
        assertTrue("Logout page is not ready.", logoutPage.isReady());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

}
