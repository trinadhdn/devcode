/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.search;

import static org.testng.AssertJUnit.assertTrue;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.views.landingPage.LandingAndAssetDetailsPage;
import com.opentext.pageObjects.advanceSearch.AdvanceSearchPage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.containerCollections.ContainerCollectionsPage;
import com.opentext.pageObjects.saveInCollection.SaveInCollectionPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.SectionType;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;
import com.opentext.utils.administration.DashboardBuilder;

/**
 * A test class contain the tests of the Search page in the web application.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public class SearchTestSet extends BasicTestSet {

    static Logger log = Logger.getLogger(SearchTestSet.class);

    public SearchTestSet() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
     * Check the Search page elements:
     * 
     * -# @see loginAux() -# @see logoutAux()
     */
    @Test(description = "Check the Search page elements.")
    public void checkLayout(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Perform the logout action.
        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the Thumbs view:
     *
     * -# @see loginAux() -# Change to Thumbs view. -# Check the view. -# @see
     * logoutAux()
     */
    @Test(description = "Check the Thumbs view.")
    public void thumbsViewTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Change to Thumbs view.
        searchPage.changeToThumbsView();
        // Check the view.
        assertTrue("Thumbs view is not active.", searchPage.isThumbsViewActive());

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the List view:
     *
     * -# @see loginAux() -# Change to List view. -# Check the view. -# @see
     * logoutAux()
     */
    @Test(description = "Check the List view.")
    public void listViewTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Change to List view.
        searchPage.changeToListView();
        // Check the view.
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the charge of more assets:
     *
     * -# @see loginAux() -# Scroll bottom to charge more assets. -# Check
     * quantity of assets shown. -# Change to List view. -# Scroll bottom to
     * charge more assets. -# Check quantity of assets shown. -# @see
     * logoutAux()
     */
    @Test(description = "Check the charge of more assets.")
    public void chargeMoreAssetsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        int numberOfAssetsShownBefore = searchPage.getNumberOfAssetsShown();
        // Scroll bottom to charge more assets.
        searchPage.scrollToChargeMoreAssets();
        // Check quantity of assets shown.
        assertTrue("The number of assets shown has not increased.", numberOfAssetsShownBefore < searchPage
                .getNumberOfAssetsShown());

        // Change to List view.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        numberOfAssetsShownBefore = searchPage.getNumberOfAssetsShown();
        // Scroll bottom to charge more assets.
        searchPage.scrollToChargeMoreAssets();
        // Check quantity of assets shown.
        assertTrue("The number of assets shown has not increased.", numberOfAssetsShownBefore < searchPage
                .getNumberOfAssetsShown());

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the scroll top using the proper button:
     *
     * -# @see loginAux() -# Scroll bottom to charge more assets. -# Use the
     * GoToTop button. -# Change to List view. -# Scroll bottom to charge more
     * assets. -# Use the GoToTop button. -# @see logoutAux()
     */
    @Test(description = "Check the scroll top using the proper button.")
    public void scrollTopByButtonTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        int numberOfAssetsShownBefore = searchPage.getNumberOfAssetsShown();
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();

        // Scroll bottom to charge more assets.
        containerAssets.scrollToChargeMoreAssets();
        containerAssets.scrollToChargeMoreAssets();
        containerAssets.scrollToChargeMoreAssets();
        // Check quantity of assets shown.
        assertTrue("The number of assets shown has not increased.", numberOfAssetsShownBefore < searchPage
                .getNumberOfAssetsShown());

        assertTrue("The BackToTop button is not shown.", containerAssets.isBackToTopButtonShown());
        // Use the GoToTop button
        containerAssets.scrollTopByGoToTopButton();

        // Change to List view.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        numberOfAssetsShownBefore = searchPage.getNumberOfAssetsShown();
        // Scroll bottom to charge more assets.
        containerAssets.scrollToChargeMoreAssets();
        containerAssets.scrollToChargeMoreAssets();
        containerAssets.scrollToChargeMoreAssets();
        // Check quantity of assets shown.
        assertTrue("The number of assets shown has not increased.", numberOfAssetsShownBefore < searchPage
                .getNumberOfAssetsShown());

        assertTrue("The BackToTop button is not shown.", containerAssets.isBackToTopButtonShown());
        // Use the GoToTop button
        containerAssets.scrollTopByGoToTopButton();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the Sort by:
     *
     * -# @see loginAux() -# Change the SortBy option. -# Check the changes. -#
     * Change to List view. -# Change the SortBy option. -# Check the changes.
     * -# @see logoutAux()
     */
    @Test(description = "Check the Sort by.")
    public void sortByTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // In the Thumbs view:
        // For every option:
        for (int index = 1; index < searchPage.getNumberOfOptionsInSortBy(); index++) {
            // Change the SortBy option.
            searchPage.changeSortByOptionSelected(index);
            // Check the changes.
            assertTrue("Search page is not ready.", searchPage.isReady());
        }

        // Change to List view:
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());
        // For every option:
        for (int index = 1; index < searchPage.getNumberOfOptionsInSortBy(); index++) {
            // Change the SortBy option.
            searchPage.changeSortByOptionSelected(index);
            // Check the changes.
            assertTrue("Search page is not ready.", searchPage.isReady());
        }

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the Search action with a non existing result:
     *
     * -# @see loginAux() -# Search for a word with expected no result. -#
     * Change to List view and check. -# @see logoutAux()
     */
    @Test(description = "Check the Search action with a non existing result.")
    public void searchForNonExistingResultTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Search for a word with expected no result.
        searchPage.search(SEARCH_WORD_DONT_EXPECTED_RESULT);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Change to List view and check.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the Search action with an existing result:
     *
     * -# @see loginAux() -# Search for a word with expected result. -# Change
     * to List view and check. -# @see logoutAux()
     */
    @Test(description = "Check the Search action with an existing result.")
    public void searchForExistingResultTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Search for a word with expected result.
        searchPage.search(SEARCH_WORD_1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Change to List view and check.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());
        assertTrue("Search page is not ready.", searchPage.isReady());

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the Search action with a multibyte character existing result:
     * 
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     *
     *         -# @see loginAux() -# Search for a word with expected result. -#
     *         Change to List view and check. -# @see logoutAux()
     */
    @Test(description = "Check the Search action with a multibyte character existing result.")
    public void searchForExistingMultiByteCharacterResultTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Search for a word with expected result.
        searchPage.search(SEARCH_WORD_WITH_MULTIBYTECHARACTERS);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Change to List view and check.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());
        assertTrue("Search page is not ready.", searchPage.isReady());

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the History of the search bar:
     *
     * -# @see loginAux() -# Perform some searches. -# Show the history. -#
     * Check the history. -# Select an option of the history. -# @see
     * logoutAux()
     */
    @Test(description = "Check the History of the search bar.")
    public void checkHistoryResultTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        for (int index = 1; index < 11; index++) {
            // Perform a search.
            searchPage.search(SEARCH_WORD_1 + " " + index);
            assertTrue("Search page is not ready.", searchPage.isReady());
        }

        // Show the history.
        searchPage.typeCleanSearchText(SEARCH_WORD_1);
        // Check the history.
        assertTrue("The history is not shown.", searchPage.isHistoryShown());

        // Select an option of the history.
        searchPage.selectAnHistoryOptionAndSearch(2);
        assertTrue("Search page is not ready.", searchPage.isReady());

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Saving result in a new collection:
     *
     * -# @see loginAux() -# Search for a word with expected result. -# Open the
     * SaveInCollection component. -# Add a new collection. -# Navigate to the
     * Collection List Area. -# Navigate to the created collection. -# Check if
     * the assets are saved in the collection. -# @see logoutAux()
     */
    @Test(description = "Saving result in a new collection.")
    public void saveResultInANewCollectionTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        int oldCounterCollection = searchPage.getHeader().getCollectionCounter();
        // Search for a word with expected result.
        searchPage.search(SEARCH_WORD_4);
        assertTrue("Search page is not ready.", searchPage.isReady());
        // Getting assets IDs to compare later.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        List<String> assetsIDs = containerAssets.getAssetIDsOfAssetsShown();

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add a new collection.
        String name = "Collection - " + new Date().getTime();
        saveInCollection.addToNewCollection(name, "Albums");
        /*
         * assertTrue("The counter of collections hasn't been increased.",
         * oldCounterCollection + 1 == searchPage
         * .getHeader().getCollectionCounter());
         */
        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));

        // Delete the collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Saving result in a new collection:
     *
     * -# @see loginAux() -# {@see createSimpleCollectionAux()}. -# Search for a
     * word with expected result. -# Open the SaveInCollection component. -# Add
     * to created collection. -# Navigate to the Collection List Area. -#
     * Navigate to the created collection. -# Check if the assets are saved in
     * the collection. -# @see deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Saving result in a new collection.")
    public void saveResultInACreatedCollectionTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection and navigate back to search page.
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Albums");
        String name = collectionPage.getTitle();
        searchPage = collectionPage.getHeader().clickOnLogo();
        assertTrue("Search page is not ready.", searchPage.isReady());

        // int oldCounterCollection =
        // searchPage.getHeader().getCollectionCounter();
        // Search for a word with expected result.
        searchPage.search(SEARCH_WORD_4);
        assertTrue("Search page is not ready.", searchPage.isReady());
        // Getting assets IDs to compare later.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        List<String> assetsIDs = containerAssets.getAssetIDsOfAssetsShown();

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add to created collection.
        saveInCollection.addToExistingCollection(name);
        /*
         * assertTrue("The counter of collections hasn't been increased.",
         * oldCounterCollection == searchPage.getHeader()
         * .getCollectionCounter());
         */
        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));

        // Delete the collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the advance search panel:
     *
     * -# @see loginAux() -# Open the AdvanceSearch component. -# Use the date
     * filters. -# Check changes of Date filter. -# Use Reset button. -# Use the
     * Asset Type filter. -# Check changes of AssetType filter. -# @see
     * logoutAux()
     */
    @Test(description = "Check the advance search panel.")
    public void advanceSearchTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Open the AdvanceSearch component.
        AdvanceSearchPage advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());

        // Use the date filters.
        int prevCounterAssets = searchPage.getCounterAssets();
        for (int index = 0; index < advanceSearch.getDateFilterSize(); index++) {
            advanceSearch.selectDateFilter(searchPage.getContainerAssets(), index);
            // Check changes of Date filter.
            assertTrue("The previous counter of assets shouldn't be minor.", searchPage
                    .assetsCountsForDateFilter(prevCounterAssets));
        }

        // Use Reset button.
        advanceSearch.clickOnResetButton(searchPage.getContainerAssets());

        // Use the Asset Type filter
        for (int index = 0; index < advanceSearch.getAssetTypeFilterSize() && index < 5; index++) {
            int counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), index);
            // Check changes of AssetType filter.
            assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
            assertTrue("Assets are not shown for this filter.", !(searchPage.getCounterAssets() == 0));
            assertTrue("The counter of assets of the AssetType was wrong." + counterAssetType + " - "
                    + searchPage.getCounterAssets(), counterAssetType == searchPage.getCounterAssets());

            advanceSearch.removeAssetTypeFilter(searchPage.getContainerAssets());
        }

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Saving result in a new collection:
     *  @author mpapishe
     * -# @see loginAux()
     * -# Navigate to administartion ->views ->Landing Page 
     * -# Set the save collection asset limit to "3" 
     * -# Save it
     * -# Go back to search page
     * -# Try to save more number of assets i.e.., More than 3 in a  collection 
     * -# Pop up alert message should be shown that user cannot save more than 3 assets in the collection 
     * -# @see logoutAux()
     */
    @Test(description = "Saving result in a collection with limitation.")
    public void saveMoreAssetsInCollectionShowsPopup(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'CONTENT_PERMISSION'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.LANDING);

        // Navigate to Landing page of Administartion views
        LandingAndAssetDetailsPage landing = new LandingAndAssetDetailsPage(DriverManager.getDriver(), sections);

        // Update the value to 3 in save to my collection limit and save it
        landing.fillSavetoMyCollectionassetlimit("3");
        landing.clickOnSave();

        // GO back to search page
        searchPage.getHeader().clickOnLogo();

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add a new collection.
        String name = "Collection - " + new Date().getTime();
        saveInCollection.addToNewCollection(name, "Albums");

        // Assert that user cannot save more than 3 assets to save in collection popup is shown
        assertTrue("The Model popup meassage showild be shown", searchPage.isMaximunCountAlreartShown());
        searchPage.clickOnOkOfModal();

        DriverManager.getDriver().sleep(2);
        // Navigate to Administration area.
        searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate toLanding Page of Administartion page and set set the value in save in collection asset linit
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.LANDING);
        landing.fillSavetoMyCollectionassetlimit("100");
        landing.clickOnSave();
        DriverManager.getDriver().sleep(2);

        // Logout from the application
        logoutPage = logoutAux(dashboard.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }
}
