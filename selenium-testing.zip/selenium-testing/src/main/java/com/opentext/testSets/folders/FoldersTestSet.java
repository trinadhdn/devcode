/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.folders;

import static org.testng.AssertJUnit.assertTrue;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.Logger;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.api.DHApiResponse;
import com.opentext.pageObjects.assetDetails.AssetDetailsPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsDownloadPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsMetadatasPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsSaveInCollectionPage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.containerAssets.assetPreview.specificViews.AssetPreviewThumbsViewPage;
import com.opentext.pageObjects.containerCollections.ContainerCollectionsPage;
import com.opentext.pageObjects.folders.FoldersPage;
import com.opentext.pageObjects.folders.foldersSideBar.FoldersSideBar;
import com.opentext.pageObjects.header.HeaderPage;
import com.opentext.pageObjects.saveInCollection.SaveInCollectionPage;
import com.opentext.pageObjects.singleDownload.specificModal.MultiDownloadPage;
import com.opentext.pageObjects.singleDownload.specificModal.SingleDownloadPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.AssetCategoryValues.AssetType;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contain the tests of the Folders page in the web application.
 * 
 * @author Sowjanya Lankadasu <slankada@opentext.com>
 */
public class FoldersTestSet extends BasicTestSet {

    static Logger log = Logger.getLogger(FoldersTestSet.class);

    public FoldersTestSet() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
     * Check the Folder page elements:
     * -# @see loginAux()
     * -# Click on Folders button and navigate to Folders page.
     * -# @see logoutAux()
     */
    @Test(description = "Check the Folder page elements: TC#OTMM_PC_Folders_002", priority = 1)
    public void checkLayout(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        folderspage.waitForReady();
        assertTrue("TC#OTMM_PC_Folders_002: Folder page is not ready.", folderspage.isReady());

        // Perform the logout action.
        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check collapsing/expanding the Folder side bar and back to search button:
     * -# @see loginAux().
     * -# Click on Folders button and navigate to Folders page.
     * -# Click on hide folder button to collapse and verify.
     * -# click on show folder button to collapse and verify.
     * -# click on back to search button and verify.
     * -# @see logoutAux().
     */
    @Test(description = "Check collapsing/expanding the Folder side bar and back to search button:TC#OTMM_PC_Folders_005,OTMM_PC_Folders_006 and OTMM_PC_Folders_007", priority = 2)
    public void checkCollapseAndExpandFolderPanel(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // Click on hide folders button.
        FoldersSideBar foldersSideBar = folderspage.getFolderSideBar();
        foldersSideBar.hide();
        assertTrue("TC#OTMM_PC_Folders_005: Folders component is not collapsed.", !foldersSideBar
                .isFoldersSideBarOpen());

        // Click on show button.
        foldersSideBar.show();
        assertTrue("TC#OTMM_PC_Folders_006: Folders component is not Expanded.", foldersSideBar.isFoldersSideBarOpen());

        // click on back to search button
        searchPage = folderspage.clickOnBackToSearchButton();
        assertTrue("TC#OTMM_PC_Folders_007: Search page is not ready after clicking on back to search button in folder page.", searchPage
                .isReady());

        // Perform the logout action.
        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check Thumbnail view and list view in the folder home page:
     * -# @see loginAux().
     * -# Click on Folders button and navigate to Folders page.
     * -# Change to Thumbs view.
     * -# Verify assets are visible in thumnbails view.
     * -# Check the view.
     * -# Verify assets are visible in list view.
     * -# @see logoutAux().
     */
    @Test(description = "Check Thumbnailview and list view in the folder home page:TC#OTMM_PC_Folders_009,OTMM_PC_Folders_010", priority = 3)
    public void checkThumbnailAndListViewInHomePageTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // Change to Thumbs view.
        searchPage.changeToThumbsView();

        // Check the view.
        assertTrue("TC#OTMM_PC_Folders_009: Thumbs view is not active.", searchPage.isThumbsViewActive());

        // Change to List view.
        searchPage.changeToListView();

        // Check the view.
        assertTrue("TC#OTMM_PC_Folders_010: List view is not active.", !searchPage.isThumbsViewActive());

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check Thumbnailview and list view in a specific folder:
     * 
     * -# @see loginAux().
     * -# Click on Folders button and navigate to Folders page.
     * -# Navigate to a specific folder.
     * -# Change to Thumbs view.
     * -# Verify assets are visible in thumnbails view.
     * -# Check the view.
     * -# Verify assets are visible in list view.
     * -# Change the SortBy option. 
     * -# Check the changes.
     * -# @see logoutAux().
     */
    @Test(description = "Check Thumbnailview and list view in a specific folder:TC#OTMM_PC_Folders_008,OTMM_PC_Folders_011,OTMM_PC_Folders_012,OTMM_PC_Folders_027", priority = 4)
    public void checkSortInThumbnailAndListViewInFolderTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two parent folders ", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be two parent folders ", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // Expand all the subfodlers in Public folders.
        int folderNamesCount = foldersSideBar.expandAllPublicFolders();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the Public folders should be expanded.", foldersSideBar
                .isPublicFoldersExpanded(folderNamesCount));

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // navigate to a folder in Public folders
        // Change to Thumbs view.
        searchPage.changeToThumbsView();

        // Check the view.
        assertTrue("TC#OTMM_PC_Folders_011:Thumbs view is not active.", searchPage.isThumbsViewActive());

        // Verify sorting in the Thumbs view:
        // For every option:
        for (int index = 1; index < searchPage.getNumberOfOptionsInSortBy(); index++) {
            // Change the SortBy option.
            searchPage.changeSortByOptionSelected(index);
            // Check the changes.
            assertTrue("TC#OTMM_PC_Folders_027: Folder page is not ready after sorting in thumbnails view .", folderspage
                    .isReady());
        }

        // Change to List view.
        searchPage.changeToListView();

        // Check the view.
        assertTrue("TC#OTMM_PC_Folders_012: List view is not active.", !searchPage.isThumbsViewActive());

        // Verify sorting in list view, for every option.
        for (int index = 1; index < searchPage.getNumberOfOptionsInSortBy(); index++) {
            // Change the SortBy option.
            searchPage.changeSortByOptionSelected(index);
            // Check the changes.
            assertTrue("TC#OTMM_PC_Folders_023: Folder page is not ready after sorting in list view.", folderspage
                    .isReady());
        }

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Saving all result in a new Album collection:
     *
     *# @see loginAux().
     * -# Click on Folders button and navigate to Folders page.
     * -# Navigate to a specific folder.
     * -# Open the SaveInCollection component.
     * -# Add a new Album collection. 
     * -# Navigate to the Collection List Area. 
     * -# Navigate to the created collection. 
     * -# Check if the assets are saved in the collection. 
     * -# @see logoutAux()
     */
    @Test(description = "Saving result in a new Album collection:OTMM_PC_Folders_019", priority = 5)
    public void saveResultInANewCollectionTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Getting assets IDs to compare later.
        List<String> assetsIDs = folderAssetsPage.getAssetIDsOfAssetsShown();

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = folderspage.openSaveInCollection();
        assertTrue("TC#OTMM_PC_Folders_013:SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add a new collection.
        String name = "Folder Collection - " + new Date().getTime();
        saveInCollection.addToNewCollection(name, "Albums");

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        folderAssetsPage = collectionPage.getFolderContainerAssets();
        assertTrue("All the assets of the folder should be saved into the collection.", folderAssetsPage
                .compareLists(assetsIDs, folderAssetsPage.getAssetIDsOfAssetsShown()));

        // Delete the collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Saving result in a new Personal collection:
     *
     *# @see loginAux().
     * -# Click on Folders button and navigate to Folders page.
     * -# Navigate to a specific folder.
     * -# Open the SaveInCollection component.
     * -# Add a new collection. 
     * -# Navigate to the Collection List Area. 
     * -# Navigate to the created collection. 
     * -# Check if the assets are saved in the collection. 
     * -# @see logoutAux()
     */
    @Test(description = "Saving result in a new Personal collection:OTMM_PC_Folders_020", priority = 6)
    public void saveResultInANewPersonalCollectionTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Getting assets IDs to compare later.
        List<String> assetsIDs = folderAssetsPage.getAssetIDsOfAssetsShown();

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = folderspage.openSaveInCollection();
        assertTrue("TC#OTMM_PC_Folders_013:SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add a new collection.
        String name = "Folder Collection - " + new Date().getTime();
        saveInCollection.addToNewCollection(name, "Personal");

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        folderAssetsPage = collectionPage.getFolderContainerAssets();
        assertTrue("All the assets of the folder should be saved into the collection.", folderAssetsPage
                .compareLists(assetsIDs, folderAssetsPage.getAssetIDsOfAssetsShown()));
        // Delete the collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Perform the 'Saving result in an existing collection.' from the asset
     * details in a collection:
     *
     * -# @see loginAux() .
     * -# @see createSimpleCollectionAux(). 
     * -# Click on Folders button and navigate to Folders page.
     * -# Navigate to a specific folder.
     * -# Open the SaveInCollection component.
     * -# Add a existing collection. 
     * -# Navigate to the Collection List Area. 
     * -# Navigate to the created collection. 
     * -# Check if the assets are saved in the collection. 
     * -# @see deleteCollectionAux 
     * -# @see logoutAux()
     */
    @Test(description = "Perform the 'Saving result in an existing collection.' from the asset details in a collection:OTMM_PC_Folders_018", priority = 7)
    public void saveInExistingCollectionTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection simple
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Albums");

        // Save name collection
        String collName1 = collectionPage.getTitle();

        // Go to homepage
        searchPage.getHeader().clickOnLogo();
        assertTrue("Search page is not ready.", searchPage.isReady());

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Getting assets IDs to compare later.
        List<String> assetsIDs = folderAssetsPage.getAssetIDsOfAssetsShown();

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = folderspage.openSaveInCollection();
        assertTrue("TC#OTMM_PC_Folders_013:SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add the assets to existing collection.
        saveInCollection.addToExistingCollection(collName1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(collName1);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        folderAssetsPage = collectionPage.getFolderContainerAssets();
        assertTrue("All the assets of the folder should be saved into the collection.", folderAssetsPage
                .compareTwoLists(assetsIDs, folderAssetsPage.getAssetIDsOfAssetsShown()));

        // Delete the created collections
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), collName1);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
        * Multi selection of assets individually and adding to existing collection:
        *
        * -# @see loginAux()
        * -# Click on Folders button and navigate to Folders page.
        * -# Navigate to a specific folder with assets.
        * -# Using Ctrl key select different assets.
        * -# Check selected assets.
        * -# add the assets to an existing collection
        * -# @see logoutAux()
        */

    @Test(description = "Multi selection of assets individually and adding to existing collections:OTMM_PC_Folders_022,TC#OTMM_PC_Folders_015", priority = 8)
    public void multiSelectionIndividuallyAddingToExistingCollectionsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection simple
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Albums");

        // Save name collection
        String collName1 = collectionPage.getTitle();

        // Go to homepage
        searchPage.getHeader().clickOnLogo();
        assertTrue("Search page is not ready.", searchPage.isReady());

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Using Ctrl key select different assets.
        int numberOfSelected = folderAssetsPage.selectRandomAssetsUsingCtrlKey(folderspage);

        // Get selected asset ID`s
        List<String> assetsIDs = folderAssetsPage.getAssetIDsOfAssetsSelected();

        // Check selected assets.
        ContainerAssetsPage containerAssetsPage = new ContainerAssetsPage(DriverManager.getDriver());
        assertTrue("TC#OTMM_PC_Folders_022:Should be " + numberOfSelected + " selected assets but there are "
                + containerAssetsPage.getCountOfSelected()
                + ".", containerAssetsPage.getCountOfSelected() == numberOfSelected);

        // Add the assets to an exising collection. TC#OTMM_PC_Folders_015
        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = folderspage.openSaveInCollection();
        assertTrue("TC#OTMM_PC_Folders_013:SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add the assets to existing collection.
        saveInCollection.addToExistingCollection(collName1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(collName1);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        folderAssetsPage = collectionPage.getFolderContainerAssets();
        assertTrue("All the assets of the folder should be saved into the collection.", folderAssetsPage
                .compareLists(assetsIDs, folderAssetsPage.getAssetIDsOfAssetsShown()));

        // Delete the created collections
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), collName1);

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Multi selection of assets individually and adding to new album collections:
     *
     * -# @see loginAux()
     * -# Click on Folders button and navigate to Folders page.
     * -# Navigate to a specific folder with assets.
     * -# Using Ctrl key select different assets.
     * -# Check selected assets.
     * -# Create a Album collection
     * -# @see logoutAux()
     */

    @Test(description = "Multi selection of assets individually to new Album collections:TC#OTMM_PC_Folders_016", priority = 9)
    public void addingMultiSelectAssetsToNewAlbumCollectionsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Using Ctrl key select different assets.
        int numberOfSelected = folderAssetsPage.selectRandomAssetsUsingCtrlKey(folderspage);
        List<String> selectedIDs = folderAssetsPage.getAssetIDsOfAssetsSelected();

        // Check selected assets.
        ContainerAssetsPage containerAssetsPage = new ContainerAssetsPage(DriverManager.getDriver());
        assertTrue("TC#OTMM_PC_Folders_022:Should be " + numberOfSelected + " selected assets but there are "
                + containerAssetsPage.getCountOfSelected()
                + ".", containerAssetsPage.getCountOfSelected() == numberOfSelected);

        // Add the assets to an exising collection. TC#OTMM_PC_Folders_015
        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = folderspage.openSaveInCollection();
        assertTrue("TC#OTMM_PC_Folders_013:SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add the assets to Album and personal collection.
        String aName = "Folder Album -" + new Date().getTime();
        saveInCollection.addToNewCollection(aName, "Albums");

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(aName);
        assertTrue("Collection page is not ready.", collectionPage.isReady());
        Reporter.log("Collection - " + aName + "got created.");

        // Check if the assets are saved in the collection.
        folderAssetsPage = collectionPage.getFolderContainerAssets();
        assertTrue("All the assets of the folder should be saved into the collection.", folderAssetsPage
                .compareLists(selectedIDs, folderAssetsPage.getAssetIDsOfAssetsShown()));

        // Delete the created collections
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), aName);

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Multi selection of assets individually and adding to existing and new album/personal collections:
     *
     * -# @see loginAux()
     * -# Click on Folders button and navigate to Folders page.
     * -# Navigate to a specific folder with assets.
     * -# Using Ctrl key select different assets.
     * -# Check selected assets.
     * -# Create a Personal collection
     * -# @see logoutAux()
     */

    @Test(description = "Multi selection of assets individually to new Personal collections:TC#OTMM_PC_Folders_017", priority = 10)
    public void addingMultiSelectAssetsToPersonalCollectionsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Using Ctrl key select different assets.
        int numberOfSelected = folderAssetsPage.selectRandomAssetsUsingCtrlKey(folderspage);
        List<String> selectedIDs = folderAssetsPage.getAssetIDsOfAssetsSelected();

        // Check selected assets.
        ContainerAssetsPage containerAssetsPage = new ContainerAssetsPage(DriverManager.getDriver());
        assertTrue("TC#OTMM_PC_Folders_022:Should be " + numberOfSelected + " selected assets but there are "
                + containerAssetsPage.getCountOfSelected()
                + ".", containerAssetsPage.getCountOfSelected() == numberOfSelected);

        // Add the assets to an exising collection. TC#OTMM_PC_Folders_015
        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = folderspage.openSaveInCollection();
        assertTrue("TC#OTMM_PC_Folders_013:SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add the assets to Album and personal collection.
        String pName = "Folder Personal -" + new Date().getTime();
        saveInCollection.addToNewCollection(pName, "Personal");

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(pName);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        folderAssetsPage = collectionPage.getFolderContainerAssets();
        assertTrue("All the assets of the folder should be saved into the collection.", folderAssetsPage
                .compareLists(selectedIDs, folderAssetsPage.getAssetIDsOfAssetsShown()));

        // Delete the created collections
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), pName);

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Multi selection of assets from asset to asset:
      *
      * -# @see loginAux()
      * -# Click on Folders button and navigate to Folders page.
      * -# Navigate to a specific folder with assets.
      * -# Using Shift key select different assets.
      * -# Check selected assets.
      * -# @see logoutAux()
      */

    @Test(description = "Multi selection of assets from asset to asset:OTMM_PC_Folders_023", priority = 11)
    public void multiSelectionFromAssetToAssetTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Getting assets IDs to compare later.
        List<String> assetsIDs = folderAssetsPage.getAssetIDsOfAssetsShown();

        // Verify there are more than 5 assets in the folder.
        assertTrue("There should be atleast 5 assets in the folder for this test.", assetsIDs.size() >= 1);

        // Using Shift key select different assets.
        int numberOfSelected = folderAssetsPage.selectAssetsUsingShiftKey(folderspage, 1, 4);

        // Check selected assets.
        ContainerAssetsPage containerAssetsPage = new ContainerAssetsPage(DriverManager.getDriver());
        assertTrue("TC#OTMM_PC_Folders_022:Should be " + numberOfSelected + " selected assets but there are "
                + containerAssetsPage.getCountOfSelected()
                + ".", containerAssetsPage.getCountOfSelected() == numberOfSelected);

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * View download standalone modal and try to download without accepting and with accepting DRM:
      *
      * -# @see loginAux()
      * -# Click on Folders button and navigate to Folders page.
      * -# Navigate to a specific folder with assets.
      * -# Navigate to the SingleDownload modal.
      * -# Check the SingleDownload modal.
      *  -# Click on Download button without accepting DRM.
      *  -# verify download with accpeting DRM.
      * -# Close the SingleDownload modal.
      * -# Change to list view and download from link.
      * -# @see logoutAux()
      */

    @Test(description = "View download standalone modal and try to download without accepting and with accepting DRM:OTMM_PC_Folders_024,OTMM_PC_Folders_025,OTMM_PC_Folders_026,OTMM_PC_Folders_028", priority = 12)
    public void downloadStandaloneWithAndWithoutoutDrmTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Navigate to the SingleDownload modal.
        // ContainerAssetsPage containerAssets = new ContainerAssetsPage(DriverManager.getDriver());
        SingleDownloadPage singleDownload = folderAssetsPage
                .goToSingleDownloadOfTheAsset(folderAssetsPage.getRandomIndexOfAssetsShown());

        // Check the SingleDownload modal.
        assertTrue("SingleDownload modal is not ready.", singleDownload.isReady());

        // Click on Download button without accepting DRM.
        singleDownload.clickOnDownloadButton();
        assertTrue("TC#OTMM_PC_Folders_024:The error message should be shown.", singleDownload.isErrorMessageShown());

        // Accept the DRM.
        singleDownload.acceptDRM();
        // Click on Download button.
        singleDownload.clickOnDownloadButton();
        assertTrue("TC#OTMM_PC_Folders_025:The after download message and the link should be shown.", singleDownload
                .isAfterDownloadMessageAndLinkShown());
        // Close the SingleDownload modal.
        singleDownload.close();

        // Change to List view.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        // Navigate to the SingleDownload modal.
        singleDownload = folderAssetsPage.goToSingleDownloadOfTheAsset(folderAssetsPage.getRandomIndexOfAssetsShown());
        assertTrue("SingleDownload modal is not ready.", singleDownload.isReady());

        // Accept the DRM.
        singleDownload.acceptDRM();
        // Click on Download button.
        singleDownload.clickOnDownloadButton();
        assertTrue("TC#OTMM_PC_Folders_028:The after download message and the link should be shown.", singleDownload
                .isAfterDownloadMessageAndLinkShown());

        // Click on the download link.
        singleDownload.clickOnDownloadLink();

        // Close the SingleDownload modal.
        singleDownload.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Download of multiples assets:
      *
      * -# @see loginAux()
      * -# Click on Folders button and navigate to Folders page.
      * -# Navigate to a specific folder with assets.
      * -# Using Ctrl key select different assets.
      * -# Navigate to the MultiDownload modal.
      * -# Accept the DRM.
      * -# Click on Download button.
      * -# @see logoutAux()
      */

    @Test(description = "Download of multiples assets:OTMM_PC_Folders_029", priority = 13)
    public void multiDownloadTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Navigate to the MultiDownload modal.
        int numberOfSelected = folderAssetsPage.selectRandomAssetsUsingCtrlKey(folderspage);

        ContainerAssetsPage containerAssetsPage = new ContainerAssetsPage(DriverManager.getDriver());
        MultiDownloadPage multiDownload = folderspage
                .goToMultiDownloadOfTheAssets(containerAssetsPage.getCountOfSelected());
        assertTrue("MultiDownload modal is not ready.", multiDownload.isReady());

        // Accept the DRM.
        multiDownload.acceptDRM();
        // Click on Download button.
        multiDownload.clickOnDownloadButton();
        assertTrue("Logged in user does not have access to some of the downlaoded assets. Check the permissions.", !multiDownload
                .isErrorMessageShown());
        assertTrue("TC#OTMM_PC_Folders_029:The after download message should be shown.", multiDownload
                .isAfterDownloadMessageShown());

        // Close the MultiDownload modal.
        multiDownload.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
    * Search a metadata value from the asset details:
    *
    * -# @see loginAux()
    * -# Click on any asset to see the asset details.
    * -# Expand the Metadata complement.
    * -# Expand the group of metadatas.
    * -# Perform a search in the metadata input.
    * -# Check the text is found in the metadatas values.
    * -# Collapse the Metadata complement.
    * -# Close the asset details modal.
    * -# @see logoutAux()
    */
    @Test(description = "Search a metadata value from the asset details:OTMM_PC_Folders_030", priority = 14)
    public void searchMetadataFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Navigate to the MultiDownload modal.
        folderAssetsPage = folderspage.getFolderContainerAssets();

        AssetDetailsPage assetDetails = folderAssetsPage
                .goToAssetDetails(folderAssetsPage.getRandomIndexOfAssetsShown(), AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the Metadata complement.
        AssetDetailsMetadatasPage metadataComplement = AssetDetailsPage.getMetadataComplement();
        metadataComplement.open();

        // Expand the group of metadatas.
        metadataComplement.openGroup();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Perform a search in the metadata input.
        String textToSearch = "a";
        metadataComplement.search(textToSearch);
        metadataComplement.cleanSearchInput();
        int counter = metadataComplement.numberOfMetadatasValuesShown();
        textToSearch = "name";
        metadataComplement.search(textToSearch);

        // Check the text is found in the metadatas values.
        assertTrue("Should have less metadatas shown.", counter >= metadataComplement.numberOfMetadatasValuesShown());
        assertTrue("The visible values don't contain the searched text.", metadataComplement
                .isContainedInEveryValueShown(textToSearch));

        // Collapse the Metadata complement.
        // metadataComplement.closeGroup();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
    * Download asset and check the download count:
    *
    * -# @see loginAux()
    * -# Click on any asset to see the asset details.
    * -# Note download and View Counter of the asset, close the asset
    * -# Now reopen the asset and check whether counter increased or not
    * -# Close the asset details modal.
    * -# @see logoutAux()
    */
    @Test(description = "Download asset and check the download count:OTMM_PC_Folders_021", priority = 15)
    public void checkDownloadAndViewCounter(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Navigate to the MultiDownload modal.
        ContainerAssetsPage containerAssets = new ContainerAssetsPage(DriverManager.getDriver());
        int index = folderAssetsPage.getRandomIndexOfAssetsShown();
        String assetid = folderAssetsPage.getAssetID(index);
        int assetidIndex = containerAssets.getIndexOfAssetID(assetid);
        AssetDetailsPage assetDetails = folderAssetsPage.goToAssetDetails(assetidIndex, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        int perivousDownloadCount = assetDetails.getDownloadCount();
        int perivousViewCount = assetDetails.getViewCount();

        // Expand the Download complement.
        AssetDetailsDownloadPage downloadComplement = AssetDetailsPage.getDownloadComplement();
        downloadComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Accept the DRM.
        downloadComplement.acceptDRM();

        // Click on Download button.
        downloadComplement.clickOnDownloadButton();
        assertTrue("The selected asset does not have permissions to download.", !(downloadComplement
                .isErrorMessageShown()));
        assertTrue("The after download message and the link should be shown.", downloadComplement
                .isAfterDownloadMessageAndLinkShown());

        // Collapse the Download complement.
        downloadComplement.close();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        // Open Asset to get latest Download Count
        AssetPreviewThumbsViewPage.overlay = null;
        AssetDetailsPage assetDetailsagain = folderAssetsPage.goToAssetDetails(assetidIndex, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetailsagain.isReady());

        assertTrue("Download Count is not increated", assetDetailsagain.getDownloadCount() > perivousDownloadCount);
        assertTrue("View Count is not increated", assetDetailsagain.getViewCount() > perivousViewCount);

        assetDetailsagain.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Asset saved in a collection should appear as marked in the complement 'Save in' of the asset details:
      *  
      *  # @see loginAux()
      * -# Click on any asset to see the asset details.
      * -# Expand the SaveInCollection complement.
      * -# Add a new collection.
      * -# Close the asset details modal.
      * -# Navigate to the Collection List Area.
      * -# Navigate to the created collection.
      * -# Check if the assets are saved in the collection.
      * -# @see deleteCollectionAux()
      * -# @see logoutAux()
      *  
      */

    @Test(description = "Asset saved in a collection should appear as marked in the complement 'Save in' of the asset details: OTMM_PC_Folders_031", priority = 16)
    public void belongingToCollectionFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        int oldCounterCollection = searchPage.getHeader().getCollectionCounter();

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Click on any asset to see the asset details.
        folderAssetsPage = folderspage.getFolderContainerAssets();
        // ContainerAssetsPage collectionAssets = new ContainerAssetsPage(DriverManager.getDriver());
        int index = folderAssetsPage.getRandomIndexOfAssetsShown();
        List<String> assetsIDs = new ArrayList<String>();
        assetsIDs.add(folderAssetsPage.getAssetIDsOfAsset(index));

        AssetDetailsPage assetDetails = folderAssetsPage.goToAssetDetails(index, AssetType.ANY);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        AssetDetailsSaveInCollectionPage saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Add a new collection.
        String name = "Collection - " + new Date().getTime();
        saveInCollectionComplement.addToNewCollection(name, "Albums");

        // Collapse the SaveInCollection complement (not necessary).
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        searchPage.sleep20andRefresh();
        assertTrue("The counter of collections hasn't been increased.", searchPage.getHeader()
                .getCollectionCounter() > oldCounterCollection);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        containerAssets = collectionPage.getContainerAssets();
        /*        int beforeCounter = collectionPage.getCounterAssets();
        */
        assetDetails = containerAssets.goToAssetDetails(0, AssetType.ANY);
        assertTrue("AssetDetails modal for image is not ready.Check whether image asset type is present in folder.", assetDetails
                .isReady());

        // Expand the SaveInCollection complement.
        saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();

        // Check the save asset is in the collection
        assertTrue("Collection hasn't been found.", saveInCollectionComplement
                .checkCollectionIsSavingThisAsset(name) != null);

        // Delete an asset from a collection.
        saveInCollectionComplement.deleteAssetOfCollection(name);

        // Check if the assets are saved in the collection. //TODO defect is pending#15788. Below is the workaround.
        // collectionPage.rechargeContainerAssets();
        // containerAssets = collectionPage.getContainerAssets();
        /*int afterCounter = collectionPage.getCounterAssets();
        assertTrue("The assets counter should be decreased by one as one asset has been deleted.", beforeCounter == afterCounter
                + 1);*/

        // Delete the collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * 'Delete an asset from a collection by the complement 'Save in' of the asset details.':
      *
      * -# @see loginAux()
      * -# Create collection with assets.
      * -# Enter in the created collection.
      * -# Open the asset details.
      * -# Expand the SaveInCollection complement.
      * -# Delete an asset from a collection
      * -# Check if the assets are deleted in the collection.
      * -# @see deleteCollectionAux()
      * -# @see logoutAux()
      */

    @Test(description = "Delete an asset from a collection by the complement 'Save in' of the asset details:OTMM_PC_Folders_032", priority = 17)
    public void deletingOfCollectionFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two root folders.", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be public folders.", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        // navigate to a folder with assets.
        folderAssetsPage = foldersSideBar.expandPublicFoldersEnterWithAssets();
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        headerPage.getFocusOnLogo();

        // Getting assets IDs to compare later.
        // ContainerAssetsPage containerAssets = new ContainerAssetsPage(DriverManager.getDriver());
        List<String> assetsIDs = folderAssetsPage.getAssetIDsOfAssetsShown();

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = folderspage.openSaveInCollection();
        assertTrue("TC#OTMM_PC_Folders_013:SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add a new collection.
        String name = "Collection - " + new Date().getTime();
        saveInCollection.addToNewCollection(name, "Albums");

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        folderAssetsPage = collectionPage.getFolderContainerAssets();
        assertTrue("All the assets of the folder should be saved into the collection.", folderAssetsPage
                .compareLists(assetsIDs, folderAssetsPage.getAssetIDsOfAssetsShown()));

        // Enter in the created collection.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        // List<String> assetsIDs = containerAssets.getAssetIDsOfAssetsShown();

        // Open the asset details.
        int index = containerAssets.getRandomIndexOfAssetsShown();
        AssetDetailsPage assetDetails = folderAssetsPage.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        AssetDetailsSaveInCollectionPage saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        // Delete an asset from a collection.
        saveInCollectionComplement.deleteAssetOfCollection(name);

        // Check if the assets are saved in the collection.
        collectionPage.rechargeContainerAssets();
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", !containerAssets
                .compareLists(containerAssets.getAssetIDsOfAssetsShown(), assetsIDs));

        // Delete the collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Create a folder in OTMM and verify it is displayed in DH. 
     *
     * -# Create a folder in OTMM and  @see loginAux()
     * -# Verify the created folder is present in DH
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Create a folder in OTMM and verify it is displayed in DH:OTMM_PC_Folders_003", enabled = true, priority = 18)
    public void createFolderInOTMMCheckInDH(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMINOTMM, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());
        String folderName = apiResponse.createFolderApi(UserDomain.SUPERADMINOTMM, UserType.QA1, "createfolder");

        Reporter.log("The name of the created folder is - " + folderName);

        // click on folder button in search page
        FoldersPage folderspage = new FoldersPage(DriverManager.getDriver());
        folderspage.clickOnFolderButton();
        assertTrue("Folder page is not ready.", folderspage.isReady());

        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two parent folders ", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be two parent folders ", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());

        assertTrue("The folder name - " + folderName + "should be present in the folder list.", foldersSideBar
                .clickOnFolderName(folderName));

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }
}
