/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.asset;

import static org.testng.AssertJUnit.assertTrue;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.pageObjects.advanceSearch.AdvanceSearchPage;
import com.opentext.pageObjects.assetDetails.AssetDetailsPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsDownloadPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsMetadatasPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsSaveInCollectionPage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.containerAssets.assetPreview.specificViews.AssetPreviewThumbsViewPage;
import com.opentext.pageObjects.containerCollections.ContainerCollectionsPage;
import com.opentext.pageObjects.singleDownload.specificModal.MultiDownloadPage;
import com.opentext.pageObjects.singleDownload.specificModal.SingleDownloadPage;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.AssetCategoryValues.AssetType;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contain the tests of the Assets in the web application.
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public class AssetTestSet extends BasicTestSet {

    static Logger log = Logger.getLogger(AssetTestSet.class);

    public AssetTestSet() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
        * Multi selection of assets individually:
        *
        * -# @see loginAux()
        * -# Using Ctrl key select different assets.
        * -# Check selected assets.
        * -# @see logoutAux()
        */

    @Test(description = "Multi selection of assets individually.")
    public void multiSelectionIndividuallyTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        // Using Ctrl key select different assets.
        int numberOfSelected = containerAssets.selectRandomAssetsUsingCtrlKey(searchPage);
        // Check selected assets.
        assertTrue("Should be " + numberOfSelected + " selected assets but there are "
                + containerAssets.getCountOfSelected() + ".", containerAssets.getCountOfSelected() == numberOfSelected);

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Multi selection of assets from asset to asset:
      *
      * -# @see loginAux()
      * -# Using Shift key select different assets.
      * -# Check selected assets.
      * -# @see logoutAux()
      */

    @Test(description = "Multi selection of assets from asset to asset.")
    public void multiSelectionFromAssetToAssetTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        // Using Shift key select different assets.
        int numberOfSelected = containerAssets.selectAssetsUsingShiftKey(searchPage, 1, 5);
        // Check selected assets.
        assertTrue("Should be " + numberOfSelected + " selected assets but there are "
                + containerAssets.getCountOfSelected() + ".", containerAssets.getCountOfSelected() == numberOfSelected);

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * View download standalone modal:
      *
      * -# @see loginAux()
      * -# Navigate to the SingleDownload modal.
      * -# Check the SingleDownload modal.
      * -# Close the SingleDownload modal.
      * -# @see logoutAux()
      */

    @Test(description = "View download standalone modal.")
    public void viewDownloadStandaloneTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to the SingleDownload modal.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        SingleDownloadPage singleDownload = containerAssets
                .goToSingleDownloadOfTheAsset(containerAssets.getRandomIndexOfAssetsShown());
        // Check the SingleDownload modal.
        assertTrue("SingleDownload modal is not ready.", singleDownload.isReady());

        // Close the SingleDownload modal.
        singleDownload.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Try to download standalone without accepting DRM:
      *
      * -# @see loginAux()
      * -# Navigate to the SingleDownload modal.
      * -# Click on Download button without accepting DRM.
      * -# Close the SingleDownload modal.
      * -# @see logoutAux()
      */

    @Test(description = "Try to download standalone without accepting DRM.")
    public void downloadStandaloneWithoutDrmTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to the SingleDownload modal.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        SingleDownloadPage singleDownload = containerAssets
                .goToSingleDownloadOfTheAsset(containerAssets.getRandomIndexOfAssetsShown());
        assertTrue("SingleDownload modal is not ready.", singleDownload.isReady());

        // Click on Download button without accepting DRM.
        singleDownload.clickOnDownloadButton();
        assertTrue("The error message should be shown.", singleDownload.isErrorMessageShown());

        // Close the SingleDownload modal.
        singleDownload.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Perform a download standalone from thumbnail view:
      *
      * -# @see loginAux()
      * -# Navigate to the SingleDownload modal.
      * -# Accept the DRM.
      * -# Click on Download button.
      * -# Close the SingleDownload modal.
      * -# @see logoutAux()
      */

    @Test(description = "Perform a download standalone from thumbnail view.")
    public void downloadStandaloneFromThumbnailViewTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to the SingleDownload modal.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        SingleDownloadPage singleDownload = containerAssets
                .goToSingleDownloadOfTheAsset(containerAssets.getRandomIndexOfAssetsShown());
        assertTrue("SingleDownload modal is not ready.", singleDownload.isReady());

        // Accept the DRM.
        singleDownload.acceptDRM();
        // Click on Download button.
        singleDownload.clickOnDownloadButton();
        assertTrue("The after download message and the link should be shown.", singleDownload
                .isAfterDownloadMessageAndLinkShown());

        // Close the SingleDownload modal.
        singleDownload.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Perform a download standalone from list view:
      *
      * -# @see loginAux()
      * -# Change to List view.
      * -# Navigate to the SingleDownload modal.
      * -# Accept the DRM.
      * -# Click on Download button.
      * -# Close the SingleDownload modal.
      * -# @see logoutAux()
      */

    @Test(description = "Perform a download standalone from thumbnail view.")
    public void downloadStandaloneFromListViewTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Change to List view.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        // Navigate to the SingleDownload modal.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        SingleDownloadPage singleDownload = containerAssets
                .goToSingleDownloadOfTheAsset(containerAssets.getRandomIndexOfAssetsShown());
        assertTrue("SingleDownload modal is not ready.", singleDownload.isReady());

        // Accept the DRM.
        singleDownload.acceptDRM();
        // Click on Download button.
        singleDownload.clickOnDownloadButton();
        assertTrue("The after download message and the link should be shown.", singleDownload
                .isAfterDownloadMessageAndLinkShown());

        // Close the SingleDownload modal.
        singleDownload.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Perform a download standalone using the link:
      *
      * -# @see loginAux()
      * -# Navigate to the SingleDownload modal.
      * -# Accept the DRM.
      * -# Click on Download button.
      * -# Click on the download link.
      * -# Close the SingleDownload modal.
      * -# @see logoutAux()
      */

    @Test(description = "Perform a download standalone using the link.")
    public void downloadStandaloneByLinkTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to the SingleDownload modal.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        SingleDownloadPage singleDownload = containerAssets
                .goToSingleDownloadOfTheAsset(containerAssets.getRandomIndexOfAssetsShown());
        assertTrue("SingleDownload modal is not ready.", singleDownload.isReady());

        // Accept the DRM.
        singleDownload.acceptDRM();
        // Click on Download button.
        singleDownload.clickOnDownloadButton();
        assertTrue("The after download message and the link should be shown.", singleDownload
                .isAfterDownloadMessageAndLinkShown());

        // Click on the download link.
        singleDownload.clickOnDownloadLink();

        // Close the SingleDownload modal.
        singleDownload.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Download of multiples assets:
      *
      * -# @see loginAux()
      * -# Using Ctrl key select different assets.
      * -# Navigate to the MultiDownload modal.
      * -# Accept the DRM.
      * -# Click on Download button.
      * -# @see logoutAux()
      */

    @Test(description = "Download of multiples assets.")
    public void multiDownloadTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        // Using Ctrl key select different assets.
        int numberOfSelected = containerAssets.selectRandomAssetsUsingCtrlKey(searchPage);
        /*  assertTrue("Should be " + numberOfSelected + " selected assets but there are "
                + containerAssets.getCountOfSelected() + ".", containerAssets.getCountOfSelected() == numberOfSelected);*/

        // Navigate to the MultiDownload modal.
        MultiDownloadPage multiDownload = searchPage.goToMultiDownloadOfTheAssets(containerAssets.getCountOfSelected());
        assertTrue("MultiDownload modal is not ready.", multiDownload.isReady());

        // Accept the DRM.
        multiDownload.acceptDRM();
        // Click on Download button.
        multiDownload.clickOnDownloadButton();
        assertTrue("The after download message should be shown.", multiDownload.isAfterDownloadMessageShown());

        // Close the MultiDownload modal.
        multiDownload.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * View the assets details:
      *
      * -# @see loginAux()
      * -# Perform an advance search for just images.
      * -# Click on any asset to see the asset details.
      * -# Check the asset details modal.
      * -# Close the asset details modal.
      * -# Change to List view.
      * -# Click on any asset's view button to see the asset details.
      * -# Check the asset details modal.
      * -# Close the asset details modal.
      * -# @see logoutAux()
      */

    @Test(description = "View the assets details.")
    public void assetDetailsViewOfAnImageTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Perform an advance search for just images.
        AdvanceSearchPage advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());

        int counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "Image");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.IMAGE);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        // Change to List view.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        // Click on any asset's view button to see the asset details.
        assetDetails = containerAssets.goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.IMAGE);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * View the assets details of a document:
      *
      * -# @see loginAux()
      * -# Perform an advance search for just documents.
      * -# Click on any asset to see the asset details.
      * -# Check the asset details modal.
      * -# Close the asset details modal.
      * -# Change to List view.
      * -# Click on any asset's view button to see the asset details.
      * -# Check the asset details modal.
      * -# Change pages using arrows.
      * -# Close the asset details modal.
      * -# @see logoutAux()
      */

    @Test(description = "View the assets details of a document.")
    public void assetDetailsViewOfADocumentTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Perform an advance search for just documents.
        AdvanceSearchPage advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());

        int counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "MSOffice");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.DOCUMENT);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        // Change to List view.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        // Click on any asset's view button to see the asset details.
        assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.DOCUMENT);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Change pages using arrows.
        // commenting out as the functionality of next arrows is no more
        /* for (int i = 1; i < 5; i++) {
            String oldSrc = assetDetails.getCurrentSrc();
            int oldPage = assetDetails.getCurrentPage();
            assetDetails.goToNextPage();
            if (assetDetails.getNumberOfPages() > 1) {
                assertTrue("The page has not changed.", !oldSrc.equalsIgnoreCase(assetDetails.getCurrentSrc()));
                assertTrue("The page has not changed.", oldPage != assetDetails.getCurrentPage());
            } else {
                assertTrue("The page should be the same.", oldSrc.equalsIgnoreCase(assetDetails.getCurrentSrc()));
                assertTrue("The page has not changed.", oldPage == assetDetails.getCurrentPage());
            }
        }
        */
        // Close the asset details modal.
        assetDetails.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * View the assets details of a video:
      *
      * -# @see loginAux()
      * -# Perform an advance search for just documents.
      * -# Click on any asset to see the asset details.
      * -# Check the asset details modal.
      * -# Close the asset details modal.
      * -# Change to List view.
      * -# Click on any asset's view button to see the asset details.
      * -# Click play a video
      * -# Check the asset details modal.
      * -# Close the asset details modal.
      * -# @see logoutAux()
      */

    @Test(description = "View the assets details of a document.")
    public void assetDetailsViewOfAVideoTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Perform an advance search for just documents.
        AdvanceSearchPage advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());

        int counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "Video");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.VIDEO);
        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Click play a video
        assetDetails.goPlayVideo();

        // Close the asset details modal.
        assetDetails.close();

        // Change to List view.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        // Click on any asset's view button to see the asset details.
        assetDetails = containerAssets.goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.VIDEO);
        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Click play a video
        assetDetails.goPlayVideo();

        // Close the asset details modal.
        assetDetails.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Perform the download from the asset details:
      *
      * -# @see loginAux()
      * -# Click on any asset to see the asset details.
      * -# Expand the Download complement.
      * -# Accept the DRM.
      * -# Click on Download button.
      * -# Collapse the Download complement.
      * -# Close the asset details modal.
      * -# @see logoutAux()
      */

    @Test(description = "Perform the download from the asset details.")
    public void downloadFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the Download complement.
        AssetDetailsDownloadPage downloadComplement = AssetDetailsPage.getDownloadComplement();
        downloadComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Accept the DRM.
        downloadComplement.acceptDRM();

        // Click on Download button.
        downloadComplement.clickOnDownloadButton();
        assertTrue("The after download message and the link should be shown.", downloadComplement
                .isAfterDownloadMessageAndLinkShown());

        // Collapse the Download complement.
        downloadComplement.close();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Perform the 'save in a new collection' from the asset details:
      *
      * -# @see loginAux()
      * -# Click on any asset to see the asset details.
      * -# Expand the SaveInCollection complement.
      * -# Add a new collection.
      * -# Close the asset details modal.
      * -# Navigate to the Collection List Area.
      * -# Navigate to the created collection.
      * -# Check if the assets are saved in the collection.
      * -# @see logoutAux()
      */

    @Test(description = "Perform the 'save in a new collection' from the asset details.")
    public void saveInNewCollectionFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        int oldCounterCollection = searchPage.getHeader().getCollectionCounter();
        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();

        int index = containerAssets.getRandomIndexOfAssetsShown();
        // String assetsIDs = containerAssets.getAssetIDsOfAsset(index);
        List<String> assetsIDs = new ArrayList<String>();
        assetsIDs.add(containerAssets.getAssetIDsOfAsset(index));

        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        AssetDetailsSaveInCollectionPage saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Add a new collection.
        String name = "Collection - " + new Date().getTime();
        saveInCollectionComplement.addToNewCollection(name, "Albums");
        // Collapse the SaveInCollection complement (not necessary).
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        searchPage.sleep30andRefresh();

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));

        // Delete the created collection
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Perform the 'Perform the 'save result in an existing collection' from the asset details:
      *
      * -# @see loginAux()
      * -# Add a new collection.
      * -# Click on any asset to see the asset details.
      * -# Expand the SaveInCollection complement.
      * -# Select the checkbox of the existing collections to save in.
      * -# Close the asset details modal.
      * -# Navigate to the Collection List Area.
      * -# Navigate to the created collection.
      * -# Check if the assets are saved in the collection.
      * -# @see deleteCollectionAux()
      * -# @see logoutAux()
      */

    @Test(description = "Perform the 'save result in an existing collection' from the asset details.")
    public void saveInExistingCollectionFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        // Create collection simple
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Albums");
        // Save name collection
        String name = collectionPage.getTitle();

        searchPage = collectionPage.getHeader().clickOnLogo();
        searchPage.sleep30andRefresh();
        int oldCounterCollection = searchPage.getHeader().getCollectionCounter();
        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();

        int index = containerAssets.getRandomIndexOfAssetsShown();
        // String assetsIDs = containerAssets.getAssetIDsOfAsset(index);
        List<String> assetsIDs = new ArrayList<String>();
        assetsIDs.add(containerAssets.getAssetIDsOfAsset(index));

        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        AssetDetailsSaveInCollectionPage saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Select the checkbox of the existing collections to save in.
        saveInCollectionComplement.addToExistingCollection(name);
        // Collapse the SaveInCollection complement (not necessary).
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        searchPage.sleep30andRefresh();
        // System.out.println(searchPage.getHeader().getCollectionCounter());
        // assertTrue("The counter of collections hasn't been increased.", oldCounterCollection ==
        // searchPage.getHeader()
        // .getCollectionCounter());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));
        // Delete the collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Asset saved in a collection should appear as marked in the complement 'Save in' of the asset details:
      *  
      *  # @see loginAux()
      * -# Click on any asset to see the asset details.
      * -# Expand the SaveInCollection complement.
      * -# Add a new collection.
      * -# Close the asset details modal.
      * -# Navigate to the Collection List Area.
      * -# Navigate to the created collection.
      * -# Check if the assets are saved in the collection.
      * -# @see deleteCollectionAux()
      * -# @see logoutAux()
      *  
      */

    @Test(description = "Asset saved in a collection should appear as marked in the complement 'Save in' of the asset details")
    public void belongingToCollectionFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        int oldCounterCollection = searchPage.getHeader().getCollectionCounter();
        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();

        int index = containerAssets.getRandomIndexOfAssetsShown();
        List<String> assetsIDs = new ArrayList<String>();
        assetsIDs.add(containerAssets.getAssetIDsOfAsset(index));

        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        AssetDetailsSaveInCollectionPage saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Add a new collection.
        String name = "Collection - " + new Date().getTime();
        saveInCollectionComplement.addToNewCollection(name, "Albums");
        // Collapse the SaveInCollection complement (not necessary).
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        /*    searchPage.sleep30andRefresh();
        assertTrue("The counter of collections hasn't been increased.", searchPage.getHeader()
                .getCollectionCounter() > oldCounterCollection);
        */
        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Click on any asset to see the asset details.
        containerAssets = collectionPage.getContainerAssets();

        assetDetails = containerAssets.goToAssetDetails(0, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        // Check the save asset is in the collection
        assertTrue("Collection hasn't been found.", saveInCollectionComplement
                .checkCollectionIsSavingThisAsset(name) != null);
        // Close the asset details modal.
        assetDetails.close();
        // Delete the collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * 'Delete an asset from a collection by the complement 'Save in' of the asset details.':
      *
      * -# @see loginAux()
      * -# Create collection with assets.
      * -# Enter in the created collection.
      * -# Open the asset details.
      * -# Expand the SaveInCollection complement.
      * -# Delete an asset from a collection
      * -# Check if the assets are deleted in the collection.
      * -# @see deleteCollectionAux()
      * -# @see logoutAux()
      */

    @Test(description = "Delete an asset from a collection by the complement 'Save in' of the asset details.")
    public void deletingOfCollectionFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection with assets
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Albums");
        String name = collectionPage.getTitle();

        // Enter in the created collection.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        List<String> assetsIDs = containerAssets.getAssetIDsOfAssetsShown();

        // Open the asset details.
        int index = containerAssets.getRandomIndexOfAssetsShown();
        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        AssetDetailsSaveInCollectionPage saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        // Delete an asset from a collection.
        saveInCollectionComplement.deleteAssetOfCollection(name);

        // Check if the assets are saved in the collection.
        collectionPage.rechargeContainerAssets();
        containerAssets = collectionPage.getContainerAssets(); // TODO: pending of a bug.
        assertTrue("Collection page is not ready.", !containerAssets
                .compareLists(containerAssets.getAssetIDsOfAssetsShown(), assetsIDs));

        // Delete the collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
      * Search a metadata value from the asset details:
      *
      * -# @see loginAux()
      * -# Click on any asset to see the asset details.
      * -# Expand the Metadata complement.
      * -# Expand the group of metadatas.
      * -# Perform a search in the metadata input.
      * -# Check the text is found in the metadatas values.
      * -# Collapse the Metadata complement.
      * -# Close the asset details modal.
      * -# @see logoutAux()
      */
    @Test(description = "Search a metadata value from the asset details.")
    public void searchMetadataFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the Metadata complement.
        AssetDetailsMetadatasPage metadataComplement = AssetDetailsPage.getMetadataComplement();
        metadataComplement.open();
        // Expand the group of metadatas.
        metadataComplement.openGroup();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Perform a search in the metadata input.
        String textToSearch = "Image";
        metadataComplement.search(textToSearch);
        metadataComplement.cleanSearchInput();
        int counter = metadataComplement.numberOfMetadatasValuesShown();
        metadataComplement.search(textToSearch);

        // Check the text is found in the metadatas values.
        assertTrue("Should have less metadatas shown.", counter >= metadataComplement.numberOfMetadatasValuesShown());
        assertTrue("The visible values don't contain the searched text.", metadataComplement
                .isContainedInEveryValueShown(textToSearch));

        // Collapse the Metadata complement.
        // metadataComplement.closeGroup();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Download asset and check the download count:
     *
     * -# @see loginAux()
     * -# Click on any asset to see the asset details.
     * -# Note download and View Counter of the asset, close the asset
     * -# Now reopen the asset and check whether counter increased or not
     * -# Close the asset details modal.
     * -# @see logoutAux()
     */
    @Test(description = "Download asset and check the download count.")
    public void checkDownloadAndViewCounter(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        int index = containerAssets.getRandomIndexOfAssetsShown();
        String assetid = containerAssets.getAssetID(index);
        int asseridIndex = containerAssets.getIndexOfAssetID(assetid);
        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(asseridIndex, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        int perivousDownloadCount = assetDetails.getDownloadCount();
        int perivousViewCount = assetDetails.getViewCount();

        // Expand the Download complement.
        AssetDetailsDownloadPage downloadComplement = AssetDetailsPage.getDownloadComplement();
        downloadComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Accept the DRM.
        downloadComplement.acceptDRM();

        // Click on Download button.
        downloadComplement.clickOnDownloadButton();
        assertTrue("The after download message and the link should be shown.", downloadComplement
                .isAfterDownloadMessageAndLinkShown());

        // Collapse the Download complement.
        downloadComplement.close();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        // Open Asset to get latest Download Count
        AssetPreviewThumbsViewPage.overlay = null;
        AssetDetailsPage assetDetailsagain = containerAssets.goToAssetDetails(asseridIndex, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetailsagain.isReady());

        assertTrue("Download Count is not increated", assetDetailsagain.getDownloadCount() > perivousDownloadCount);
        assertTrue("View Count is not increated", assetDetailsagain.getViewCount() > perivousViewCount);

        assetDetailsagain.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

}
