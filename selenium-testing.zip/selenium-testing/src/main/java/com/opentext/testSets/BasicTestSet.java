/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets;

import static org.testng.AssertJUnit.assertTrue;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.opentext.pageObjects.collection.CollectionPage;
import com.opentext.pageObjects.collectionListArea.CollectionListAreaPage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.containerCollections.ContainerCollectionsPage;
import com.opentext.pageObjects.createAndEditionCollection.specific.CreateCollectionPage;
import com.opentext.pageObjects.folders.folderAssets.FolderAssetsPage;
import com.opentext.pageObjects.header.HeaderPage;
import com.opentext.pageObjects.inbox.InboxPage;
import com.opentext.pageObjects.login.LoginPage;
import com.opentext.pageObjects.login.LogoutPage;
import com.opentext.pageObjects.profile.ProfilePage;
import com.opentext.pageObjects.saveInCollection.SaveInCollectionPage;
import com.opentext.pageObjects.search.SearchPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.selenium.testSet.DefaultTestSet;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contains the common behavior of the tests class in the project.
 * Also contains the PageObjects variable references.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public abstract class BasicTestSet extends DefaultTestSet {

    /**
     * Items keys selectors.
     */
    protected final String SEARCH_WORD_1 = "MEDIA";
    protected final String SEARCH_WORD_2 = "OpenText";
    protected final String SEARCH_WORD_3 = "1";
    protected final String SEARCH_WORD_4 = "QA";
    protected final String COLLECTION_OWNER = "sowjanya";
    protected final String SHARED_USER = "trinadh";

    protected final String SEARCH_WORD_DONT_EXPECTED_RESULT = "DontResultExpected";
    protected final String SEARCH_WORD_WITH_MULTIBYTECHARACTERS = "漢";
    protected static final String SEARCH_WORD_MORETHAN_28 = "1";

    /**
     * Components
     */
    protected LoginPage loginPage;
    private static HeaderPage header;
    protected LogoutPage logoutPage;
    protected SearchPage searchPage;
    protected ProfilePage profilePage;
    protected InboxPage inboxPage;
    protected CollectionListAreaPage collectionListAreaPage;
    protected CollectionPage collectionPage;
    protected FolderAssetsPage folderAssetsPage;

    /**
     * Method auxiliary of Login logic to use in the tests:
     * 
     * @param userDomain
     *            to perform the login.
     * @param usertype
     *            to perform the login.
     * @return SearchPage ready to work with.
     */
    public synchronized SearchPage loginAux(UserDomain userDomain, UserType userType) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: loginAux");

        // Go to PC web.
        loginPage = new LoginPage(DriverManager.getDriver());
        loginPage.waitForReady();
        assertTrue("Login page is not ready.", loginPage.isReady());

        // Perform login action
        searchPage = loginPage.login(userDomain, userType);

        assertTrue("Search page is not ready.", searchPage.isReady());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: loginAux");

        return searchPage;
    }

    /**
     * Method auxiliary of Logout logic to use in the tests:
     * 
     * @param searchPage
     *            ready to perform the logout.
     * @return LogoutPage ready to work with.
     */
    public synchronized LogoutPage logoutAux(HeaderPage headerPage) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: logoutAux");

        assertTrue("Header page is not ready.", headerPage.isReady());

        // Perform the logout action.
        logoutPage = headerPage.clickOnLogoutButton();
        // Check logout page.
        assertTrue("Info logout message is not shown.", logoutPage.isInfoMessageShown());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: logoutAux");

        return logoutPage;
    }

    /**
     * Method auxiliary of 'navigate to CollectionListArea and create a new
     * collection' logic to use in the tests:
     * 
     * @param headerPage
     *            ready to perform the navigation.
     * @return CollectionPage ready to work with.
     */
    public synchronized CollectionPage createSimpleCollectionAux(HeaderPage headerPage, String cType) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: createSimpleCollectionAux");

        // Navigate to the Collection List Area.
        collectionListAreaPage = headerPage.clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to create collection area by New button.
        CreateCollectionPage createCollectionPage = collectionListAreaPage.goToCreateCollection();
        assertTrue("Create collection page is not ready.", createCollectionPage.isReady());

        // Fill 'Collection name' and Comment.
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
        Date now = Calendar.getInstance().getTime();
        Calendar after = Calendar.getInstance();
        after.setTime(now);
        after.add(Calendar.DAY_OF_YEAR, +1);
        Date nextDate = after.getTime();
        createCollectionPage.fillName("Collection - " + new Date().getTime());
        createCollectionPage.fillComment("Comment - " + df.format(now));
        createCollectionPage.selectAndFillType(cType);
        createCollectionPage.fillExpiredDate(df1.format(nextDate));

        /*// Selecting previoud date in Expire date filed.
        Calendar before = Calendar.getInstance();
        before.setTime(now);
        before.add(Calendar.DAY_OF_YEAR, -1);
        Date previousDate = before.getTime();
        createCollectionPage.fillExpiredDate(df1.format(previousDate));
        */
        // Click on Save button.
        collectionPage = createCollectionPage.clickOnSaveButton();
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: createSimpleCollectionAux");

        return collectionPage;
    }

    /**
     * Method auxiliary of 'navigate to CollectionListArea and delete a given
     * collection' logic to use in the tests:
     * 
     * @param headerPage
     *            ready to perform the navigation.
     * @return CollectionListAreaPage ready to work with.
     */
    public synchronized CollectionListAreaPage deleteCollectionAux(HeaderPage headerPage, String name) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: deleteCollectionAux");

        // Navigate to the Collection List Area.
        collectionListAreaPage = headerPage.clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Select the created collection.
        collectionListAreaPage.expandAll();
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        // int previousCounterOfCollections =
        // containerCollections.getNumberOfCollectionsShown();
        containerCollections.selectCollection(collectionListAreaPage, name);

        // Delete the selected collection.
        collectionListAreaPage.clickOnRemove();
        // containerCollections =
        // collectionListAreaPage.getContainerCollections();
        // assertTrue("Collection List Area page is not ready.",
        // collectionListAreaPage.isReady());
        /*
         * assertTrue("The number of collections hasn't been decreased.",
         * containerCollections .getNumberOfCollectionsShown() <
         * previousCounterOfCollections);
         */

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: deleteCollectionAux");

        return collectionListAreaPage;
    }

    /**
     * Method auxiliary of 'navigate to CollectionListArea and create a new
     * collection' logic to use in the tests:
     * 
     * @param headerPage
     *            ready to perform the navigation.
     * @param headerPage
     *            ready to perform the navigation.
     * @param type
     *            of the new collection.  
     * @return CollectionPage ready to work with.
     */
    public synchronized CollectionPage createCollectionWithAssetsAux(HeaderPage headerPage, String textToSearch,
            String type) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: createCollectionWithAssetsAux");

        /*Note: Commenting these lines to save time.
         * // Navigate to seach page. 
        searchPage = headerPage.clickOnLogo();
        assertTrue("Search page is not ready.", searchPage.isReady());*/

        // Search for a word with expected result.
        searchPage.search(textToSearch);
        assertTrue("Search page is not ready.", searchPage.isReady());
        // Getting assets IDs to compare later.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        List<String> assetsIDs = containerAssets.getAssetIDsOfAssetsShown();

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add a new collection.
        String name = "Collection - " + new Date().getTime();
        saveInCollection.addToNewCollection(name, type);
        DriverManager.getDriver().sleep(10);
        /*
         * if (searchPage.getHeader().getCollectionCounter() ==
         * oldCounterCollection) { this.DriverManager.getDriver().sleep(15); }
         * assertTrue("The counter of collections hasn't been increased.",
         * searchPage.getHeader() .getCollectionCounter() >
         * oldCounterCollection);
         */

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        if (collectionPage.getCounterAssets() <= collectionPage.getNumberOfAssetsShown()) {
            // Check if the assets are saved in the collection.
            containerAssets = collectionPage.getContainerAssets();
            assertTrue("The assets don't match.", containerAssets
                    .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));
        }

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: createCollectionWithAssetsAux");

        return collectionPage;
    }

    /**
     * Method auxiliary to logout and Login logic to use in the tests.
     * 
     * @param userDomain
     *            to perform the login.
     * @param usertype
     *            to perform the login.
     * @return SearchPage ready to work with.
     * @author Sowjanya Lankadasu<slankada@opentext.com>
     * @author tnakka
     */
    public synchronized SearchPage logoutAndLoginAux(UserDomain userDomain, UserType userType) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: logoutAndLoginAux");

        loginPage = new LoginPage(DriverManager.getDriver());

        // Logout from shared user
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        logoutPage = headerPage.clickOnLogoutButton();

        // Click on Sign in button in loggout page
        loginPage.clickOnSignInButton();

        // Go to PC web.
        // loginPage = new LoginPage(DriverManager.getDriver());
        loginPage.waitForReady();
        assertTrue("Login page is not ready.", loginPage.isReady());

        // Perform login action
        searchPage = loginPage.login(userDomain, userType);
        if ((!userDomain.toString().equals(UserDomain.WRONGCREDENTIALS.toString()))
                && (!userDomain.toString().equals(UserDomain.NON_ADMIN.toString()))) {

            assertTrue("Search page is not ready.", searchPage.isReady());
        }

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: logoutAndLoginAux");

        return searchPage;

    }

    /**
     * Method auxiliary of 'navigate to CollectionListArea and create a new
     * collection with users' logic to use in the tests.
     * 
     * @param headerPage
     *            ready to perform the navigation and collection type.
     * @param usertype
     *            to perform the login.
     * @return CollectionPage ready to work with.
     * @author Sowjanya Lankadasu <slankada@opentext.com>.
     */
    public synchronized CollectionPage createCollectionWithOwnerSharedUsersAux(HeaderPage headerPage, String cType) {
        log.info("[log-TestSet] " + this.getClass().getName()
                + " - Start test method: createCollectionWithSharedOwnerUsersAux");

        // Navigate to the Collection List Area.
        collectionListAreaPage = headerPage.clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to create collection area by New button.
        CreateCollectionPage createCollectionPage = collectionListAreaPage.goToCreateCollection();
        assertTrue("Create collection page is not ready.", createCollectionPage.isReady());

        // Fill 'Collection name', 'Collection type', 'Collection owner',
        // 'Shared user' and 'Comment'.
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date now = Calendar.getInstance().getTime();
        createCollectionPage.fillName("SharedCollection - " + new Date().getTime());
        createCollectionPage.fillComment("Comment - " + df.format(now));
        createCollectionPage.selectAndFillType(cType);
        createCollectionPage.fillCollectionOwnerEmail(COLLECTION_OWNER);
        createCollectionPage.fillSharetoEmail(SHARED_USER);

        // Click on Save button.
        collectionPage = createCollectionPage.clickOnSaveButton();
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        log.info("[log-TestSet] " + this.getClass().getName()
                + " - End test method: createCollectionWithSharedOwnerUsersAux");

        return collectionPage;
    }

}
