/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.rmm;

import java.io.IOException;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.pageObjects.uploadTestDataInRMM.UploadTestDataInRMMPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contain the tests of the Upload test data in RMM.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class RMMTestSet extends BasicTestSet {

	static Logger log = Logger.getLogger(RMMTestSet.class);

	public RMMTestSet() {
		super();
	}

	@BeforeMethod(description = "startTest")
	public void before() {
		super.before();
	}

	@AfterMethod(description = "endTest")
	public void afterAllIsSaidAndDone() {
		super.afterAllIsSaidAndDone();
	}

	/**
	 * Upload data to RMM:
	 * 
	 * -# Luanch RMM URL -# Login to RMM. -# Click on Upload and select Upload
	 * workflow -# Click on Add file button -# Select file and click on ok -#
	 * Check Uncompressed check box -# Click on ok to Upload -# Check upload is
	 * completed
	 * 
	 * @throws IOException
	 */
	@Test(description = "Upload data to RMM")
	public void uploadTestDataInRMM(Method method) throws IOException {
		log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

		UploadTestDataInRMMPage uploadtoRMM = new UploadTestDataInRMMPage(DriverManager.getDriver());

		// login to RMM
		uploadtoRMM.rmmLogin(UserDomain.RMM, UserType.QA1);
		DriverManager.getDriver().sleep(5);

		// click on Upload button
		uploadtoRMM.clickOnUploadTask();
		DriverManager.getDriver().sleep(3);

		// click on Add file button
		uploadtoRMM.clickOnAddFileButton();
		DriverManager.getDriver().sleep(3);

		// Select file at window and click on OK
		uploadtoRMM.uploadData();
		DriverManager.getDriver().sleep(2);

		// Select UncompressZipCheckBox
		uploadtoRMM.selectUncompressZipCheckBox();
		DriverManager.getDriver().sleep(2);

		// Click on OK to upload data
		uploadtoRMM.clickOnOK();

		// Close upload dialog after it completed
		uploadtoRMM.closeUploadDailog();

		// Click on Activity Manager
		uploadtoRMM.clickOnActivityManagerButton();

		// Check if upload is done
		uploadtoRMM.checkForUploadComplete();

		// Logout RMM
		uploadtoRMM.rmmLoginOut();

		log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
	}

}
