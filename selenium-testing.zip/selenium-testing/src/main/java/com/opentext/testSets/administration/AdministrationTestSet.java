/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.administration;

import static org.testng.AssertJUnit.assertTrue;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.general.checkall.CheckAllServicesPage;
import com.opentext.pageObjects.administration.general.cloudConfiguration.CreateAndEditCloudConfigPage;
import com.opentext.pageObjects.administration.general.emailAccountConfiguration.CreateAndEditEmailAccountConfigPage;
import com.opentext.pageObjects.administration.general.jobConfiguration.CreateAndEditJobConfigPage;
import com.opentext.pageObjects.administration.general.library.CreateAndEditLibraryServersPage;
import com.opentext.pageObjects.administration.general.library.LibraryServersPage;
import com.opentext.pageObjects.administration.general.mediabinServices.CreateAndEditMediabinServicesPage;
import com.opentext.pageObjects.administration.metadata.metadataList.MetadataConfiguration;
import com.opentext.pageObjects.administration.security.ad.ADSettingsPage;
import com.opentext.pageObjects.administration.security.contentPermissions.ContentPermissionsPage;
import com.opentext.pageObjects.administration.security.ldap.LDAPSettingsPage;
import com.opentext.pageObjects.administration.security.mappingPermissions.MappingPermissionsSettingsPage;
import com.opentext.pageObjects.administration.security.otds.OTDSSettingsPage;
import com.opentext.pageObjects.administration.security.roleConfiguration.RoleConfiguration;
import com.opentext.pageObjects.administration.views.exportTemplate.ExportTemplatePage;
import com.opentext.pageObjects.administration.views.general.FacetsInformationPage;
import com.opentext.pageObjects.administration.views.landingPage.LandingAndAssetDetailsPage;
import com.opentext.pageObjects.administration.views.texts.TextsTabPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.ConfigAD.ConfigADDetails;
import com.opentext.utils.ConfigCloudStorage.ConfigCloudDetails;
import com.opentext.utils.ConfigEmail.ConfigEMailDetails;
import com.opentext.utils.ConfigLDAP.ConfigLDAPDetails;
import com.opentext.utils.ConfigLibrary.ConfigDetails;
import com.opentext.utils.ConfigMB.ConfigMBDetails;
import com.opentext.utils.ConfigOTDS.ConfigOTDSDetails;
import com.opentext.utils.SectionType;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;
import com.opentext.utils.administration.DashboardBuilder;

/**
 * A test class contain the tests of the Administration area in the web
 * application.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class AdministrationTestSet extends BasicTestSet {

    static Logger log = Logger.getLogger(AdministrationTestSet.class);

    public AdministrationTestSet() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
     * Check the Dashboard of the Administration area:
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Check the
     * Dashboard page. -# @see logoutAux()
     */

    @Test(description = "Check the Dashboard of the Administration area.")
    public void checkDashboardLayout(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        // Check the Dashboard page.
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Perform the logout action.
        logoutPage = logoutAux(dashboard.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Create a new empty server:
     * 
     * -# @see loginAux() 
     * -# Go to Profile and get the roles. 
     * -# Get the list of the sections visible.
     * -# Navigate to Administration area. 
     * -# Navigate to 'Application Library Web Services'. 
     * -# Click on 'Add server'. 
     * -# With every field empty, click on Save button. 
     * -# Check the server hasn't been created. 
     * -# @see logoutAux()
     */

    @Test(description = "Create a new empty server.")
    public void createEmptyLibraryServerTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Application Library Web Services'.
        LibraryServersPage libraryPage = (LibraryServersPage) dashboard
                .goToSpecificSectionOrSubSectionPage(SectionType.LIBRARY_SERVERS);
        assertTrue("Library page is not ready.", libraryPage.isReady());

        // Click on 'Add server'.
        CreateAndEditLibraryServersPage createLibraryServerPage = libraryPage.goToAddServer();
        assertTrue("Create Library Server page is not ready.", createLibraryServerPage.isReady());

        // With every field empty, click on Save button.
        createLibraryServerPage.disableLibraryServer();
        createLibraryServerPage.clickOnSave();
        // Check the server hasn't been created.
        assertTrue("Create Library Server page is not ready.", createLibraryServerPage.isReady());
        assertTrue("Required field should be shown.", createLibraryServerPage.isRequiredFieldMessageShown());

        searchPage.getHeader().clickOnAdministrationButton(sections);

        // Perform the logout action.
        logoutPage = logoutAux(createLibraryServerPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Admin back to previous view to Application Library Web Services.
     * 
     * Navigate back from 'Application Library Web Services'.
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Application Library Web Services'. -# Click on 'BACK'. -# Check if it is
     * navigate to 'Application Library Web Services'. -# @see logoutAux()
     */

    @Test(description = "Navigate back from 'Application Library Web Services'")
    public void backToDashboardFromApplicationLibraryServices(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Application Library Web Services'.
        LibraryServersPage libraryPage = (LibraryServersPage) dashboard
                .goToSpecificSectionOrSubSectionPage(SectionType.LIBRARY_SERVERS);
        assertTrue("Library page is not ready.", libraryPage.isReady());

        // Navigate to 'Application Library Web Services'.
        libraryPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Perform the logout action.
        logoutPage = logoutAux(libraryPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check Invalid service details:
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Application Library Web Services'. -# Click on 'Add server'. -# Fill the
     * invalid details. -# Check the invalid services -# @see logoutAux()
     */

    @Test(description = "Check Invalid service details")
    public void checkInvalidLibraryServerTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Application Library Web Services'.
        LibraryServersPage libraryPage = (LibraryServersPage) dashboard
                .goToSpecificSectionOrSubSectionPage(SectionType.LIBRARY_SERVERS);
        assertTrue("Library page is not ready.", libraryPage.isReady());

        // Click on 'Add server'.
        CreateAndEditLibraryServersPage createLibraryServerPage = libraryPage.goToAddServer();
        assertTrue("Create Library Server page is not ready.", createLibraryServerPage.isReady());

        // Fill the details.
        String servername = "InvalidServerName" + new Date().getTime();
        createLibraryServerPage
                .fillLibraryServerDetails(servername, ConfigDetails.INVALIDSERVERHOSTNAME, ConfigDetails.USER, ConfigDetails.PASSWORD, ConfigDetails.PORT);

        // Check service
        assertTrue("Check service is not giving correct message for Invalid configuration", createLibraryServerPage
                .checkInvalidService());

        searchPage.getHeader().clickOnAdministrationButton(sections);

        // Perform the logout action.
        logoutPage = logoutAux(createLibraryServerPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Create a new server and check service :
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Application Library Web Services'. -# Click on 'Add server'. -# Fill the
     * details -# Check the service and validate the success -# Click on Save
     * button. -# Check the server should been created. -# Delete all disabled
     * servers -# @see logoutAux()
     */

    @Test(description = "Create a new server with details.")
    public void createLibraryServerTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Application Library Web Services'.
        LibraryServersPage libraryPage = (LibraryServersPage) dashboard
                .goToSpecificSectionOrSubSectionPage(SectionType.LIBRARY_SERVERS);
        assertTrue("Library page is not ready.", libraryPage.isReady());

        // Click on 'Add server'.
        CreateAndEditLibraryServersPage createLibraryServerPage = libraryPage.goToAddServer();
        assertTrue("Create Library Server page is not ready.", createLibraryServerPage.isReady());

        // Fill the details.
        String servername = "ServerName" + new Date().getTime();
        createLibraryServerPage
                .fillLibraryServerDetails(servername, ConfigDetails.SERVERHOSTNAME, ConfigDetails.USER, ConfigDetails.PASSWORD, ConfigDetails.PORT);

        // Check service
        assertTrue("Check service got failed.", createLibraryServerPage.checkService());

        // click on Save button.
        createLibraryServerPage.clickOnSave();

        // Check the server should be created.
        assertTrue("Library server NOT created sucessfully.", createLibraryServerPage
                .isSuccessfullyCreatedMessageShown());
        assertTrue("Newly created library not exists in library servers list", libraryPage
                .isNewlyCreatedServerShownInList(servername));

        // Delete all existing servers which are are not enabled
        libraryPage.deleteAllDisabledServers();

        // Perform the logout action.
        logoutPage = logoutAux(createLibraryServerPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Edit existing server:
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Application Library Web Services'. -# Click on 'Add server'. -# Fill the
     * details, click on Save button. -# Check the server should been created.
     * -# Edit server and check service -# Delete all disabled servers -# @see
     * logoutAux()
     */

    @Test(description = "Edit existing server")
    public void editExistingLibraryServerTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Application Library Web Services'.
        LibraryServersPage libraryPage = (LibraryServersPage) dashboard
                .goToSpecificSectionOrSubSectionPage(SectionType.LIBRARY_SERVERS);
        assertTrue("Library page is not ready.", libraryPage.isReady());

        // Click on 'Add server'.
        CreateAndEditLibraryServersPage createLibraryServerPage = libraryPage.goToAddServer();
        assertTrue("Create Library Server page is not ready.", createLibraryServerPage.isReady());

        // Fill the details.
        String servername = "ServerName" + new Date().getTime();
        createLibraryServerPage
                .fillLibraryServerDetails(servername, ConfigDetails.SERVERHOSTNAME, ConfigDetails.USER, ConfigDetails.PASSWORD, ConfigDetails.PORT);

        // Check service
        assertTrue("Check service got failed.", createLibraryServerPage.checkService());

        // click on Save button.
        createLibraryServerPage.clickOnSave();
        DriverManager.getDriver().sleep(2);

        // Edit existing server, asset service again and click on Save
        libraryPage.editExistingServer(servername);
        assertTrue("Check service got failed.", createLibraryServerPage.checkService());
        createLibraryServerPage.clickOnSave();
        DriverManager.getDriver().sleep(2);

        // Delete all existing servers which are are not enabled
        libraryPage.deleteAllDisabledServers();

        // Perform the logout action.
        logoutPage = logoutAux(libraryPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Delete existing server:
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Application Library Web Services'. -# Click on 'Add server'. -# Fill the
     * details, click on Save button. -# Check the server should been created.
     * -# Delete server -# @see logoutAux()
     */

    @Test(description = "Delete existing server")
    public void deleteExistingLibraryServerTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Application Library Web Services'.
        LibraryServersPage libraryPage = (LibraryServersPage) dashboard
                .goToSpecificSectionOrSubSectionPage(SectionType.LIBRARY_SERVERS);
        assertTrue("Library page is not ready.", libraryPage.isReady());

        // Click on 'Add server'.
        CreateAndEditLibraryServersPage createLibraryServerPage = libraryPage.goToAddServer();
        assertTrue("Create Library Server page is not ready.", createLibraryServerPage.isReady());

        // Fill the details.
        String servername = "ServerName" + new Date().getTime();
        createLibraryServerPage
                .disabledAndFillLibraryServerDetails(servername, ConfigDetails.SERVERHOSTNAME, ConfigDetails.USER, ConfigDetails.PASSWORD, ConfigDetails.PORT);

        // Check service
        assertTrue("Check service got failed.", createLibraryServerPage.checkService());

        // click on Save button.
        createLibraryServerPage.clickOnSave();
        DriverManager.getDriver().sleep(2);

        // Delete existing server
        libraryPage.deleteServer(servername);
        DriverManager.getDriver().sleep(1);

        // Perform the logout action.
        logoutPage = logoutAux(libraryPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check Services Tab
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Application Library Web Services'. -# Click on Services Tab -# Check for
     * Server Name drop which should contain server that are added -# @see
     * logoutAux()
     */

    @Test(description = "Check Services Tab")
    public void checkServicesTabAndServicesDropdown(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Application Library Web Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.LIBRARY_SERVERS);
        LibraryServersPage libraryPage = new LibraryServersPage(DriverManager.getDriver(), sections);
        assertTrue("Library page is not ready.", libraryPage.isReady());

        // Click on 'Add server'.
        CreateAndEditLibraryServersPage createLibraryServerPage = libraryPage.goToAddServer();
        String servername = "ServerName" + new Date().getTime();
        createLibraryServerPage
                .disabledAndFillLibraryServerDetails(servername, ConfigDetails.SERVERHOSTNAME, ConfigDetails.USER, ConfigDetails.PASSWORD, ConfigDetails.PORT);

        // click on Save button.
        createLibraryServerPage.clickOnSave();

        // Get list of servers
        List<String> serversList = libraryPage.getServerList();

        // Click on 'Add server'.
        libraryPage.goToServicesTab();
        assertTrue("Library services page is not ready.", libraryPage.serviceTabIsReady());

        assertTrue("Services ServerNames dropdown list not matched to servers list", libraryPage
                .isServerNamesDropDownListMatchedWithActualServersList(serversList));

        // Delete all disabled servers
        libraryPage.deleteAllDisabledServers();

        // Perform the logout action.
        logoutPage = logoutAux(libraryPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Fill and check MediaBin services
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'MediaBin Web Service'. -# Fill details -# Check service -# Click on Save
     * -# @see logoutAux()
     */

    @Test(description = "Fill and Check Media Bin Services")
    public void fillAndCheckMediaBinServices(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'MediaBin Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.MEDIABIN);

        // Go to MediaBin Service page
        CreateAndEditMediabinServicesPage mbServicesPage = new CreateAndEditMediabinServicesPage(
                DriverManager.getDriver(), sections);
        assertTrue("MediaBin Service page is not ready.", mbServicesPage.isReady());

        // Fill MB service details
        mbServicesPage
                .fillMediabBinServiceDetails(ConfigMBDetails.MBLOCATION, ConfigMBDetails.MBUSER, ConfigMBDetails.MBPASSWORD, ConfigMBDetails.MBCATEGORY, ConfigMBDetails.NONMBUSER);

        // Check service
        assertTrue("Service got failed", mbServicesPage.checkService());

        // Click on Save
        mbServicesPage.clickOnSave();

        // Perform the logout action.
        logoutPage = logoutAux(mbServicesPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check MediaBin services with empty details
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'MediaBin Web Service'. -# Dont fill the details -# Check service -# @see
     * logoutAux()
     */

    @Test(description = "Check MediaBin Services without filling details")
    public void CheckMediaBinServiceWithEmptyDetails(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'MediaBin Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.MEDIABIN);

        // Go to MediaBin Service page
        CreateAndEditMediabinServicesPage mbServicesPage = new CreateAndEditMediabinServicesPage(
                DriverManager.getDriver(), sections);
        assertTrue("MediaBin Service page is not ready.", mbServicesPage.isReady());

        // Clear MB service details
        mbServicesPage.clearDeatils();

        // Click on Save
        mbServicesPage.checkService();
        assertTrue("Validation Message NOT shown.", mbServicesPage.isRequiredFieldMessageShown());

        searchPage.getHeader().clickOnAdministrationButton(sections);

        // Perform the logout action.
        logoutPage = logoutAux(mbServicesPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Fill and check Email config
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Email Account Configuration'. -# Fill details -# Send Test email -#
     * Click on Save -# @see logoutAux()
     */

    @Test(description = "Fill and Check Email config")
    public void fillAndCheckEmailService(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Email Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.EMAIL);

        // Go to Email Service page
        CreateAndEditEmailAccountConfigPage emailconfigPage = new CreateAndEditEmailAccountConfigPage(
                DriverManager.getDriver(), sections);
        assertTrue("Email Service page is not ready.", emailconfigPage.isReady());

        // Expand Check Server Status section
        emailconfigPage.expandCheckServerStatus();

        // Fill Email service details
        emailconfigPage
                .fillEmailConfigDetails(ConfigEMailDetails.MAILSERVERNAMEINPUT, ConfigEMailDetails.EMAILPORTINPUT, ConfigEMailDetails.EMAILUSERNAMEINPUT, ConfigEMailDetails.EMAILUSERPASSINPUT, ConfigEMailDetails.SENDEREMAILACCOUNT, ConfigEMailDetails.SENDERNAME, ConfigEMailDetails.SENDEMAILTEST);

        // Click on Send Test email
        emailconfigPage.clickOnSendTestEmail();
        assertTrue("Email is NOT sent.", emailconfigPage.checkEmailService());

        // Click on Save
        emailconfigPage.clickOnSave();
        // assertTrue("Email configurations are NOT saved.",
        // emailconfigPage.isSuccessfullyCreatedMessageShown());

        // Perform the logout action.
        logoutPage = logoutAux(emailconfigPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check Email config without details
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Email Account Configuration'. -# clear details -# Send Test email -#
     * Click on Save -# @see logoutAux()
     */

    @Test(description = "Check Email config with empty details")
    public void checkEmailServiceWithEmptyDetails(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Email Config Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.EMAIL);

        // Go to Email Config Service page
        CreateAndEditEmailAccountConfigPage emailconfigPage = new CreateAndEditEmailAccountConfigPage(
                DriverManager.getDriver(), sections);
        assertTrue("Email Service page is not ready.", emailconfigPage.isReady());

        // Expand Check Server Status section
        emailconfigPage.expandCheckServerStatus();

        // Clear all details
        emailconfigPage.clearDeatils();
        assertTrue("Required field message is NOT showing.", emailconfigPage.isRequiredFieldsMessageShown());

        // Click on Save
        emailconfigPage.clickOnSendTestEmail();
        assertTrue("Error message NOT showing.", emailconfigPage.checkInvalidEmailService());

        searchPage.getHeader().clickOnAdministrationButton(sections);

        // Perform the logout action.
        logoutPage = logoutAux(emailconfigPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Send Email to Invalid Email
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Email Account Configuration'. -# Fill details -# Fill Invalid emailID -#
     * Click on Send -# @see logoutAux()
     */

    @Test(description = "Fill and Check Email config")
    public void sendEmailToInavlidEmail(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Email Config Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.EMAIL);

        // Go to Email Config Service page
        CreateAndEditEmailAccountConfigPage emailconfigPage = new CreateAndEditEmailAccountConfigPage(
                DriverManager.getDriver(), sections);
        assertTrue("Email Service page is not ready.", emailconfigPage.isReady());

        // Expand Check Server Status section
        emailconfigPage.expandCheckServerStatus();

        // Fill Email service details
        emailconfigPage
                .fillEmailConfigDetails(ConfigEMailDetails.MAILSERVERNAMEINPUT, ConfigEMailDetails.EMAILPORTINPUT, ConfigEMailDetails.EMAILUSERNAMEINPUT, ConfigEMailDetails.EMAILUSERPASSINPUT, ConfigEMailDetails.SENDEREMAILACCOUNT, ConfigEMailDetails.SENDERNAME, ConfigEMailDetails.SENDINVALIDEMAILTEST);

        // Click on Send Test email
        emailconfigPage.clickOnSendTestEmail();
        assertTrue("Error Message is NOT shown when we send email to Invalid Email ID.", emailconfigPage
                .checkInvalidEmailService());

        // Click on Save
        emailconfigPage.clickOnSave();
        assertTrue("Email configurations are NOT saved.", emailconfigPage.isSuccessfullyCreatedMessageShown());

        // Perform the logout action.
        logoutPage = logoutAux(emailconfigPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Configure G Drive with Valid Details
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Cloud Storage Configuration'. -# Fill details -# Check service -# Save
     * details -# @see logoutAux()
     */

    @Test(description = "Fill and Check Email config")
    public void fillAndCheckGdrive(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Cloud Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CLOUD);

        // Go to Cloud Service page
        CreateAndEditCloudConfigPage cloudconfigPage = new CreateAndEditCloudConfigPage(DriverManager.getDriver(),
                sections);
        assertTrue("Email Service page is not ready.", cloudconfigPage.isReady());

        // Fill Cloud service details
        cloudconfigPage.fillCloudConfigDetails(ConfigCloudDetails.CLOUDCLIENTID, ConfigCloudDetails.CLOUDSECRETID);

        // Click on Check status and validate message
        assertTrue("GDrive details NOT valid", cloudconfigPage.checkGDriveStatus());
        // Click on Save
        cloudconfigPage.clickOnSave();
        assertTrue("Email configurations are NOT saved.", cloudconfigPage.isSuccessfullyCreatedMessageShown());

        // Perform the logout action.
        logoutPage = logoutAux(cloudconfigPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Configure GDrive with empty Details and check service
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Cloud Storage Configuration'. -# Clear details -# Check service -# @see
     * logoutAux()
     */

    @Test(description = "Empty and Check cloud config")
    public void checkGdriveWithEmptyDetails(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Application Library Web Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CLOUD);

        // Go to Cloud Service page
        CreateAndEditCloudConfigPage cloudconfigPage = new CreateAndEditCloudConfigPage(DriverManager.getDriver(),
                sections);
        assertTrue("Email Service page is not ready.", cloudconfigPage.isReady());

        // Fill Cloud service details
        cloudconfigPage.clearDeatils();

        // Click on Check status and validate message
        assertTrue("GDrive details NOT valid", cloudconfigPage.checkInvalidGdriveDetails());

        // Click on Save
        cloudconfigPage.clickOnSave();
        assertTrue("Error Message NOT shown when empty details are saved", cloudconfigPage
                .isRequiredFieldsMessageShown());

        // Perform the logout action.
        logoutPage = logoutAux(cloudconfigPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Configure Job details
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Scheduled jobs'. -# Clear and fill details -# Refresh section and check
     * details are stored or no -# @see logoutAux()
     */

    @Test(description = "Fill Job details")
    public void fillJobDetailsAndCheck(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Job Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.SCHEDULED);

        // Go to Job Service page
        CreateAndEditJobConfigPage jobconfigPage = new CreateAndEditJobConfigPage(DriverManager.getDriver(), sections);
        assertTrue("Email Service page is not ready.", jobconfigPage.isReady());

        // Details Storing in Job
        String refreshCount = "1";
        String gdrivetimeout = "1";

        // Fill Cloud service details
        jobconfigPage.fillJobConfigDetails(refreshCount, gdrivetimeout);

        // Click on Save
        jobconfigPage.clickOnSave();
        assertTrue("Gdrive configurations are NOT saved.", jobconfigPage.isSuccessfullyCreatedMessageShown());

        // Check if data is saved or not
        assertTrue("Given Job details are not stored.", jobconfigPage
                .isGivenJobDetailsSaved(refreshCount, gdrivetimeout));

        // Perform the logout action.
        logoutPage = logoutAux(jobconfigPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Validate edit button in Check All tab
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Check All'. -# Click on Edit for each service and validate the landing
     * page -# @see logoutAux()
     */

    @Test(description = "Fill Job details")
    public void editAndCheckLandingPageInCheckAllTab(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Check All Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CHECK);

        // Go to Check All Service page
        CheckAllServicesPage checkallconfigPage = new CheckAllServicesPage(DriverManager.getDriver(), sections);
        assertTrue("Check ALL page is not ready.", checkallconfigPage.isReady());

        // Edit Library service and check the landing page
        checkallconfigPage.clickOnLibraryServiceEdit();
        assertTrue("LibraryService page is not ready.", checkallconfigPage.checkLibraryServiceEditResult());
        checkallconfigPage.navigateBack();

        // Edit MB service and check the landing page
        checkallconfigPage.clickOnMediaBinServiceEdit();
        assertTrue("MB page is not ready.", checkallconfigPage.checkMBEditResult());
        checkallconfigPage.navigateBack();

        // Edit GDrive service and check the landing page
        checkallconfigPage.clickOnGdriveEdit();
        assertTrue("GDrive page is not ready.", checkallconfigPage.checkGDriveEditResult());
        checkallconfigPage.navigateBack();

        // Edit AD service and check the landing page
        checkallconfigPage.clickOnADEdit();
        assertTrue("AD page is not ready.", checkallconfigPage.checkADEditResult());
        checkallconfigPage.navigateBack();

        // Edit LDAP service and check the landing page
        checkallconfigPage.clickOnLDAPEdit();
        assertTrue("LDAP page is not ready.", checkallconfigPage.checkLDAPEditResult());
        checkallconfigPage.navigateBack();

        // Edit OTDS service and check the landing page
        checkallconfigPage.clickOnOTDSEdit();
        assertTrue("LDAP page is not ready.", checkallconfigPage.checkOTDSEditResult());
        checkallconfigPage.navigateBack();

        // Perform the logout action.
        logoutPage = logoutAux(checkallconfigPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check Individual service check
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Check All'. -# Click on Check for each Individual service -# Validate
     * the status -# @see logoutAux()
     */

    @Test(description = "Check Indivudual service check")
    public void checkResultsForAllService(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Job Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CHECK);

        // Go to Check All Service page
        CheckAllServicesPage checkallconfigPage = new CheckAllServicesPage(DriverManager.getDriver(), sections);
        assertTrue("Check ALL page is not ready.", checkallconfigPage.isReady());

        // Click on all individual check button
        checkallconfigPage.clickOnIndividualCheckLinks();
        assertTrue("Library service is not success.", checkallconfigPage.checkLibraryCheckResult());
        assertTrue("MB service is not success.", checkallconfigPage.checkMBCheckResult());
        assertTrue("Google service is not success.", checkallconfigPage.checkGDriveCheckResult());
        assertTrue("AD service is not success.", checkallconfigPage.checkADCheckResult());
        assertTrue("LDAP service is not success.", checkallconfigPage.checkLDAPCheckResult());
        assertTrue("OTDS service is not success.", checkallconfigPage.checkOTDSCheckResult());

        // Perform the logout action.
        logoutPage = logoutAux(checkallconfigPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check checkAllService service
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Check All'. -# Validate the status -# @see logoutAux()
     */

    @Test(description = "Check ALL service ")
    public void checkAllService(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Job Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CHECK);

        // Go to Check All Service page
        CheckAllServicesPage checkallconfigPage = new CheckAllServicesPage(DriverManager.getDriver(), sections);
        assertTrue("Check ALL page is not ready.", checkallconfigPage.isReady());

        // Click on Check All and validate the status
        checkallconfigPage.clickOnCheckAll();
        assertTrue("Library service is not success.", checkallconfigPage.checkLibraryCheckResult());
        assertTrue("MB service is not success.", checkallconfigPage.checkMBCheckResult());
        assertTrue("Google service is not success.", checkallconfigPage.checkGDriveCheckResult());
        assertTrue("AD service is not success.", checkallconfigPage.checkADCheckResult());
        assertTrue("LDAP service is not success.", checkallconfigPage.checkLDAPCheckResult());
        assertTrue("OTDS service is not success.", checkallconfigPage.checkOTDSCheckResult());

        // Perform the logout action.
        logoutPage = logoutAux(checkallconfigPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Fill and check AD Settings
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Active Directory '. -# Fill details -# Check Settings -# Click on Save
     * -# @see logoutAux()
     */

    @Test(description = "Fill and Check AD Settings")
    public void fillAndCheckADSettings(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'ACTIVE_DIRECTORY'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.ACTIVE_DIRECTORY);

        // Go to MediaBin Service page
        ADSettingsPage adSettingsPage = new ADSettingsPage(DriverManager.getDriver(), sections);
        assertTrue("AD Settings page is not ready.", adSettingsPage.isReady());

        // Fill MB service details
        adSettingsPage
                .fillADSettingsDetails(ConfigADDetails.ADSERVERNAME, ConfigADDetails.ADPORT, ConfigADDetails.ADDN, ConfigADDetails.ADDNPASSWORD, ConfigADDetails.ADDOMAIN, ConfigADDetails.ADEMAIL, ConfigADDetails.ADBASEDN);
        // Click on Check status and validate message
        assertTrue("AD settings are NOT valid", adSettingsPage.checkService());

        // Click on Save
        adSettingsPage.clickOnSave();
        assertTrue("AD configurations are NOT saved.", adSettingsPage.isSuccessfullyCreatedMessageShown());

        // Perform the logout action.
        logoutPage = logoutAux(adSettingsPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Fill Invalid details and check AD Settings
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Active Directory '. -# Fill details -# Check Settings -# Click on Save
     * -# @see logoutAux()
     */

    @Test(description = "Fill Invalid details  and Check AD Settings")
    public void fillInvalidDetailsAndCheckADSettings(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'ACTIVE_DIRECTORY'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.ACTIVE_DIRECTORY);

        // Go to MediaBin Service page
        ADSettingsPage adSettingsPage = new ADSettingsPage(DriverManager.getDriver(), sections);
        assertTrue("AD Settings page is not ready.", adSettingsPage.isReady());

        // Fill MB service details
        adSettingsPage
                .fillADSettingsDetails(ConfigADDetails.INVALIDADSERVERNAME, ConfigADDetails.ADPORT, ConfigADDetails.ADDN, ConfigADDetails.ADDNPASSWORD, ConfigADDetails.ADDOMAIN, ConfigADDetails.ADEMAIL, ConfigADDetails.ADBASEDN);
        // Click on Check status and validate message
        assertTrue("AD Invalid check result got failed", adSettingsPage.checkInvalidService());

        searchPage.getHeader().clickOnAdministrationButton(sections);

        // Perform the logout action.
        logoutPage = logoutAux(adSettingsPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Empty and check AD Settings
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Active Directory '. -# Fill details -# Check Settings -# Click on Save
     * -# @see logoutAux()
     */

    @Test(description = "Empty and Check AD Settings")
    public void emptyAndCheckADSettings(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'ACTIVE_DIRECTORY'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.ACTIVE_DIRECTORY);

        // Go to MediaBin Service page
        ADSettingsPage adSettingsPage = new ADSettingsPage(DriverManager.getDriver(), sections);
        assertTrue("AD Settings page is not ready.", adSettingsPage.isReady());

        // Fill MB service details
        adSettingsPage.clearDeatils();
        // Click on Check status and validate message
        assertTrue("AD is not responded for invalid settings ", adSettingsPage.checkInvalidService());

        searchPage.getHeader().clickOnAdministrationButton(sections);

        // Perform the logout action.
        logoutPage = logoutAux(adSettingsPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Fill and check LDAP Settings
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'LDAP '. -# Fill details -# Check Settings -# Click on Save -# @see
     * logoutAux()
     */

    @Test(description = "Fill and Check LDAP Settings")
    public void fillAndCheckLDAPSettings(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'ACTIVE_DIRECTORY'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.LDAP);

        // Check LDAP Service page
        LDAPSettingsPage ldapSettingsPage = new LDAPSettingsPage(DriverManager.getDriver(), sections);
        assertTrue("LDAP Settings page is not ready.", ldapSettingsPage.isReady());

        // Fill ldap settings details
        ldapSettingsPage
                .fillLDAPSettingsDetails(ConfigLDAPDetails.LDAPSERVERNAME, ConfigLDAPDetails.LDAPPORT, ConfigLDAPDetails.LDAPDN, ConfigLDAPDetails.LDAPDNPASSWORD, ConfigLDAPDetails.LDAPFIRSTNAME, ConfigLDAPDetails.LDAPLASTNAME, ConfigLDAPDetails.LDAPEMAIL, ConfigLDAPDetails.LDAPBASEDN, ConfigLDAPDetails.LDAPSEARCHBASEDN, ConfigLDAPDetails.LDAPSEARCHGROUPFIELDNAME);
        // Click on Check status and validate message
        assertTrue("LDAP settings are NOT valid", ldapSettingsPage.checkService());

        // Click on Save
        ldapSettingsPage.clickOnSave();
        assertTrue("LDAP configurations are NOT saved.", ldapSettingsPage.isSuccessfullyCreatedMessageShown());

        // Perform the logout action.
        logoutPage = logoutAux(ldapSettingsPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Fill Invalid and check LDAP Settings
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'LDAP '. -# Fill Invalid details -# Check Settings -# Click on Save
     * -# @see logoutAux()
     */

    @Test(description = "Fill Invalid details and Check LDAP Settings")
    public void fillInvalidDetailsandCheckLDAPSettings(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'LDAP'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.LDAP);

        // Validate LDAP page
        LDAPSettingsPage ldapSettingsPage = new LDAPSettingsPage(DriverManager.getDriver(), sections);
        assertTrue("LDAP Settings page is not ready.", ldapSettingsPage.isReady());

        // Fill Invalid settings details
        ldapSettingsPage
                .fillLDAPSettingsDetails(ConfigLDAPDetails.INVALIDLDAPSERVERNAME, ConfigLDAPDetails.LDAPPORT, ConfigLDAPDetails.LDAPDN, ConfigLDAPDetails.LDAPDNPASSWORD, ConfigLDAPDetails.LDAPFIRSTNAME, ConfigLDAPDetails.LDAPLASTNAME, ConfigLDAPDetails.LDAPEMAIL, ConfigLDAPDetails.LDAPBASEDN, ConfigLDAPDetails.LDAPSEARCHBASEDN, ConfigLDAPDetails.LDAPSEARCHGROUPFIELDNAME);
        // Click on Check status and validate message
        assertTrue("LDAP settings are NOT valid", ldapSettingsPage.checkInvalidService());

        searchPage.getHeader().clickOnAdministrationButton(sections);

        // Perform the logout action.
        logoutPage = logoutAux(ldapSettingsPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Save empty details
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'LDAP '. -# Empty details -# Check Settings -# Click on Save -# @see
     * logoutAux()
     */

    @Test(description = "Save empty ldap details")
    public void emptyAndSaveLDAPSettings(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'LDAP'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.LDAP);

        // Validate LDAP page
        LDAPSettingsPage ldapSettingsPage = new LDAPSettingsPage(DriverManager.getDriver(), sections);
        assertTrue("LDAP Settings page is not ready.", ldapSettingsPage.isReady());

        // Empty settings details
        ldapSettingsPage.clearDeatils();
        // Click on Check status and validate message
        assertTrue("LDAP settings are NOT valid", ldapSettingsPage.checkInvalidService());

        searchPage.getHeader().clickOnAdministrationButton(sections);

        // Perform the logout action.
        logoutPage = logoutAux(ldapSettingsPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Fill and check OTDS Settings
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'OTDS '. -# Fill details -# Check Settings -# Click on Save -# @see
     * logoutAux()
     */

    @Test(description = "Fill and Check OTDS Settings")
    public void fillAndCheckOTDSSettings(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'OTDS'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.OTDS);

        // Check OTDS Settings page
        OTDSSettingsPage otdsSettingsPage = new OTDSSettingsPage(DriverManager.getDriver(), sections);
        assertTrue("LDAP Settings page is not ready.", otdsSettingsPage.isReady());

        // Fill OTDS settings details
        otdsSettingsPage
                .fillOTDSSettingsDetails(ConfigOTDSDetails.OTDSSERVERNAME, ConfigOTDSDetails.OTDSPORT, ConfigOTDSDetails.OTDSDN, ConfigOTDSDetails.OTDSDNPASSWORD, ConfigOTDSDetails.OTDSRESOURCEIDENTIFIER, ConfigOTDSDetails.OTDSDOMAINNAME, ConfigOTDSDetails.OTDSFIRSTNAME, ConfigOTDSDetails.OTDSLASTNAME, ConfigOTDSDetails.OTDSEMAIL, ConfigOTDSDetails.OTDSSEARCHGROUPFIELDNAME);
        // Click on Check status and validate message
        assertTrue("LDAP settings are NOT valid", otdsSettingsPage.checkService());

        // Click on Save
        otdsSettingsPage.clickOnSave();
        // assertTrue("OTDS configurations are NOT saved.",
        // otdsSettingsPage.isSuccessfullyCreatedMessageShown());

        // Perform the logout action.
        logoutPage = logoutAux(otdsSettingsPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Fill Invalid and check OTDS Settings
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'OTDS '. -# Fill Invalid details -# Check Settings -# Click on Save
     * -# @see logoutAux()
     */

    @Test(description = "Fill Invalid details and Check OTDS Settings")
    public void fillInvalidDetailsandCheckOTDSSettings(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'LDAP'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.OTDS);

        // Validate LDAP page
        OTDSSettingsPage otdsSettingsPage = new OTDSSettingsPage(DriverManager.getDriver(), sections);
        assertTrue("OTDS Settings page is not ready.", otdsSettingsPage.isReady());

        // Fill Invalid settings details
        otdsSettingsPage
                .fillOTDSSettingsDetails(ConfigOTDSDetails.INVALIDOTDSSERVERNAME, ConfigOTDSDetails.OTDSPORT, ConfigOTDSDetails.OTDSDN, ConfigOTDSDetails.OTDSDNPASSWORD, ConfigOTDSDetails.OTDSRESOURCEIDENTIFIER, ConfigOTDSDetails.OTDSDOMAINNAME, ConfigOTDSDetails.OTDSFIRSTNAME, ConfigOTDSDetails.OTDSLASTNAME, ConfigOTDSDetails.OTDSEMAIL, ConfigOTDSDetails.OTDSSEARCHGROUPFIELDNAME);
        // Click on Check status and validate message
        assertTrue("OTDS settings are NOT valid", otdsSettingsPage.checkInvalidService());

        // Perform the logout action.
        logoutPage = logoutAux(otdsSettingsPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Save empty details
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'OTDS '. -# Empty details -# Check Settings -# Click on Save -# @see
     * logoutAux()
     */

    @Test(description = "Save empty otds details")
    public void emptyAndSaveOTDSSettings(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'LDAP'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.OTDS);

        // Validate LDAP page
        OTDSSettingsPage otdsSettingsPage = new OTDSSettingsPage(DriverManager.getDriver(), sections);
        assertTrue("OTDS Settings page is not ready.", otdsSettingsPage.isReady());

        // Empty settings details
        otdsSettingsPage.clearDeatils();
        // Click on Check status and validate message
        assertTrue("OTDS settings are NOT valid", otdsSettingsPage.checkInvalidService());

        searchPage.getHeader().clickOnAdministrationButton(sections);

        // Perform the logout action.
        logoutPage = logoutAux(otdsSettingsPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Create Custom permissions and check in list
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Manage permissions '. -# Click on Add -# Create New -# Click on Submit
     * -# @see logoutAux()
     */

    @Test(description = "Create new Custom permissions and check in list")
    public void createNewPermission(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'MANAGE_PERMISSIONS'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.MANAGE_PERMISSIONS);

        // Validate LDAP page
        MappingPermissionsSettingsPage mappingPermissions = new MappingPermissionsSettingsPage(
                DriverManager.getDriver(), sections);
        assertTrue("mappingPermissions page is not ready.", mappingPermissions.isReady());

        // Create permission settings details
        mappingPermissions.clickOnNew();
        String permissionName = "Permission" + new Date().getTime();
        String description = "Description" + new Date().getTime();
        mappingPermissions.fillMPDetails(permissionName, description);
        mappingPermissions.clickOnSubmit();
        assertTrue("Permission NOT exists in list", mappingPermissions.isPermissionExistsInList(permissionName));

        mappingPermissions.deletePermission(permissionName);
        assertTrue("Record NOT deleted", mappingPermissions.isRecorddeleted(permissionName));

        // Perform the logout action.
        logoutPage = logoutAux(mappingPermissions.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Edit existing Custom permissions and updated Desc.
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Manage permissions '. -# Click on Add -# Check Settings -# Click on Save
     * -# @see logoutAux()
     */

    @Test(description = "Edit existing Custom permissions and updated Desc")
    public void editPermission(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'LDAP'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.MANAGE_PERMISSIONS);

        // Validate LDAP page
        MappingPermissionsSettingsPage mappingPermissions = new MappingPermissionsSettingsPage(
                DriverManager.getDriver(), sections);
        assertTrue("mappingPermissions page is not ready.", mappingPermissions.isReady());

        // Create permission settings details
        mappingPermissions.clickOnNew();
        String permissionName = "Permission" + new Date().getDate() + new Date().getTime();
        String description = "Description" + new Date().getDate() + new Date().getTime();
        mappingPermissions.fillMPDetails(permissionName, description);
        mappingPermissions.clickOnSubmit();
        assertTrue("Permission NOT exists in list", mappingPermissions.isPermissionExistsInList(permissionName));

        // Edit existing Permission
        mappingPermissions.editPermissionDeatils(permissionName);
        String updatedPermission = "Permission_udpated" + new Date().getDate() + new Date().getTime();
        String updatedDescription = "Description_udpated" + new Date().getDate() + new Date().getTime();
        mappingPermissions.editMPDetails(updatedPermission, updatedDescription);
        mappingPermissions.clickOnEditSubmit();
        assertTrue("Desc is NOT updated", mappingPermissions
                .isPermissionAndDescUpdated(updatedPermission, updatedDescription));

        mappingPermissions.deletePermission(updatedPermission);
        assertTrue("Record NOT deleted", mappingPermissions.isRecorddeleted(updatedPermission));

        // Perform the logout action.
        logoutPage = logoutAux(mappingPermissions.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Create new general Filter and check data in home page
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Content Permission Mappings'. -# Click on Add -# Fill details -# Click
     * on Save -# @see logoutAux()
     */

    @Test(description = "Create new general Filter and check data in home page")
    public void createNewGeneralFilterAndCheckAssets(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'CONTENT_PERMISSION'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CONTENT_PERMISSION);

        // Validate LDAP page
        ContentPermissionsPage filters = new ContentPermissionsPage(DriverManager.getDriver(), sections);
        assertTrue("Filter page is not ready.", filters.isReady());

        // Create new filters
        filters.clickOnAddFilterButton();
        assertTrue("Filter Add page is not ready.", filters.isAddFilterReady());

        // Fill the details
        String filterName = "Permission" + new Date().getDate() + new Date().getTime();
        String description = "Description" + new Date().getDate() + new Date().getTime();
        filters.fillFilterDetails(filterName, description, "Content Type", "Image", "general");

        // Click On save
        filters.clickOnSave();
        assertTrue("Filter page is not ready.", filters.isConditionExistsInList(filterName));

        // Logout and Login with Normal User
        searchPage = logoutAndLoginAux(UserDomain.NON_ADMIN, UserType.QA1);

        filters.checkDataFilterWithUserLogin("JPEG");

        // Logout and Login with Admin User
        searchPage = logoutAndLoginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to Administration area.
        DashboardPage dashboard2 = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard2.isReady());

        // Navigate to 'CONTENT_PERMISSION'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CONTENT_PERMISSION);

        // Delete the filter
        filters.deleteALLConditions();

        // Perform the logout action.
        logoutPage = logoutAux(filters.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Create new general Filter With empty details and validate required
     * messages
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Content Permission Mappings'. -# Click on Add -# Dont fill any details
     * -# Click on Save -# Validate the messages -# @see logoutAux()
     */

    @Test(description = "Create new general Filter With empty details and validate required messages")
    public void createNewGeneralFilterWithEmptyDetails(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'CONTENT_PERMISSION'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CONTENT_PERMISSION);

        // Validate LDAP page
        ContentPermissionsPage filters = new ContentPermissionsPage(DriverManager.getDriver(), sections);
        assertTrue("Filter page is not ready.", filters.isReady());

        // Create new filters
        filters.clickOnAddFilterButton();
        assertTrue("Filter Add page is not ready.", filters.isAddFilterReady());

        // Click On save
        filters.clickOnSave();
        assertTrue("Filter page is not ready.", filters.isRequiredFieldMessageShown());

        // Perform the logout action.
        logoutPage = logoutAux(filters.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Create and edit filter
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Content Permission Mappings'. -# Click on Add -# Fill details -# Click
     * on Save -# @see logoutAux()
     */

    @Test(description = "Create and edit filter")
    public void editFilterAndCheckAssets(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'CONTENT_PERMISSION'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CONTENT_PERMISSION);

        // Validate LDAP page
        ContentPermissionsPage filters = new ContentPermissionsPage(DriverManager.getDriver(), sections);
        assertTrue("Filter page is not ready.", filters.isReady());

        // Create new filters
        filters.clickOnAddFilterButton();
        assertTrue("Filter Add page is not ready.", filters.isAddFilterReady());

        // Fill the details
        String filterName = "Permission" + new Date().getDate() + new Date().getTime();
        String description = "Description" + new Date().getDate() + new Date().getTime();
        filters.fillFilterDetails(filterName, description, "Content Type", "Image", "general");

        // Click On save
        filters.clickOnSave();
        assertTrue("Filter page is not ready.", filters.isConditionExistsInList(filterName));

        // Edit the filter
        filters.editCondition(filterName);
        String updatedFilterName = "Updated_Permission" + new Date().getDate() + new Date().getTime();
        String updatedDescription = "Updated_Description" + new Date().getDate() + new Date().getTime();
        filters.fillFilterDetails(updatedFilterName, updatedDescription, "Content Type", "Video", "general");

        // Click On save
        filters.clickOnSave();
        assertTrue("Filter page is not ready.", filters.isConditionExistsInList(updatedFilterName));

        // Logout and Login with Normal User
        searchPage = logoutAndLoginAux(UserDomain.NON_ADMIN, UserType.QA1);

        filters.checkDataFilterWithUserLogin("PDF");

        // Logout and Login with Admin User
        searchPage = logoutAndLoginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to Administration area.
        DashboardPage dashboard2 = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard2.isReady());

        // Navigate to 'CONTENT_PERMISSION'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CONTENT_PERMISSION);

        // Delete the filter
        filters.deleteALLConditions();

        // Perform the logout action.
        logoutPage = logoutAux(filters.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check permissions list for role
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Content Permission Mappings'. -# Click on Add -# Fill details -# Click
     * on Save -# @see logoutAux()
     */

    @Test(description = "Check permissions list for role")
    public void checkPermissionsForRole(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'LDAP'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.MANAGE_PERMISSIONS);

        // Validate MappingPermissionsSettingsPage
        MappingPermissionsSettingsPage mappingPermissions = new MappingPermissionsSettingsPage(
                DriverManager.getDriver(), sections);
        assertTrue("mappingPermissions page is not ready.", mappingPermissions.isReady());

        List<String> permissionsList = mappingPermissions.getPermissions();

        // Navigate to Administration area.
        DashboardPage dashboard2 = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard2.isReady());

        // Navigate to 'ROLE'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.ROLE);

        // Validate RoleConfiguration page
        RoleConfiguration rolesConfig = new RoleConfiguration(DriverManager.getDriver(), sections);
        assertTrue("Roles Config page is not ready.", rolesConfig.isReady());

        // Edit Roles
        rolesConfig.editRole("PortalClient");

        // Check all boxs
        rolesConfig.selectAllRole();

        rolesConfig.clickOnsaveRole();

        // Search for given role and validate the roles
        assertTrue("Roles are not matched.", rolesConfig
                .isRolePermissionsMatchWithContentPermissions(permissionsList, "PortalClient"));

        // Perform the logout action.
        logoutPage = logoutAux(rolesConfig.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Edit role and de-select admin and check the same by login with particular
     * user
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Roles'. -# Edit existing role and de-select admin -# Login with
     * particular user and check admin tab -# @see logoutAux()
     */

    @Test(description = "Check permissions list for role")
    public void editRoleConfiguration(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'ROLE'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.ROLE);

        // Validate LDAP page
        RoleConfiguration rolesConfig = new RoleConfiguration(DriverManager.getDriver(), sections);
        assertTrue("Roles Config page is not ready.", rolesConfig.isReady());

        rolesConfig.editRole("PortalClient");
        rolesConfig.uncheckAdminRole();

        rolesConfig.clickOnsaveRole();

        // Logout and Login with Normal User
        searchPage = logoutAndLoginAux(UserDomain.NON_ADMIN, UserType.QA1);
        assertTrue("Admin Page is shown.", rolesConfig.checkAdminTabInLoginPage());

        // Logout and Login with Admin User
        searchPage = logoutAndLoginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to Administration area.
        DashboardPage dashboard2 = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard2.isReady());

        // Navigate to 'ROLE'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.ROLE);

        rolesConfig.editRole("PortalClient");
        rolesConfig.checkAdminRole();

        rolesConfig.clickOnsaveRole();

        // Perform the logout action.
        logoutPage = logoutAux(rolesConfig.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * 
     * Click on Sync roles and check for relevant roles
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Roles'. -# Click on Sync roles button -# Search for relevant groups -#
     * Validate them -# @see logoutAux()
     */

    @Test(description = "Check permissions list for role")
    public void syncGroups(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'ROLE'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.ROLE);

        // Validate LDAP page
        RoleConfiguration rolesConfig = new RoleConfiguration(DriverManager.getDriver(), sections);
        assertTrue("Roles Config page is not ready.", rolesConfig.isReady());

        // Click on Sync Groups
        rolesConfig.clickOnSyncGroups();

        // Check if relevant group exits in list
        assertTrue("Group NOT shown in list", rolesConfig.isGroupExistInList("PortalClient"));

        // Perform the logout action.
        logoutPage = logoutAux(rolesConfig.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Remove roles for a group and login with user who has relevant group and
     * validate
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Roles'. -# Edit existing role and de-select roles -# Login with
     * particular user and check particular tab -# @see logoutAux()
     */

    @Test(description = "Check permissions list for role")
    public void removeRolesAndCheckPermissionWithUserLogin(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'ROLE'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.ROLE);

        // Validate LDAP page
        RoleConfiguration rolesConfig = new RoleConfiguration(DriverManager.getDriver(), sections);
        assertTrue("Roles Config page is not ready.", rolesConfig.isReady());

        // Edit role and Uncheck all roles
        rolesConfig.editRole("PortalClient");
        rolesConfig.uncheckAdminRole();
        rolesConfig.uncheckAssetRole();
        rolesConfig.uncheckCollectionRole();
        rolesConfig.uncheckInboxRole();

        // Save Group
        rolesConfig.clickOnsaveRole();

        // Logout and Login with Normal User
        searchPage = logoutAndLoginAux(UserDomain.NON_ADMIN, UserType.QA1);
        assertTrue("Admin Page is shown.", rolesConfig.checkAdminTabInLoginPage());

        // Logout and Login with Admin User
        searchPage = logoutAndLoginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to Administration area.
        DashboardPage dashboard2 = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard2.isReady());

        // Navigate to 'ROLE'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.ROLE);

        // Edit Role and select all
        rolesConfig.editRole("PortalClient");
        rolesConfig.selectAllRole();

        // Save Group
        rolesConfig.clickOnsaveRole();

        // Perform the logout action.
        logoutPage = logoutAux(rolesConfig.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Refresh Metadata and compare list
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Mappings'. -# Refresh meta data and compare before and after list
     * -# @see logoutAux()
     */

    @Test(description = "Refresh Metadata and compare list")
    public void refreshMetadataAndCompare(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'ROLE'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.MAPPINGS);

        // Validate LDAP page
        MetadataConfiguration metadata = new MetadataConfiguration(DriverManager.getDriver(), sections);
        assertTrue("Metadata page is not ready.", metadata.isReady());

        // Click on Refresh Metadata file
        metadata.clickOnRefreshPropertyFile();
        assertTrue("Metadata page is not ready.", metadata.isReady());

        // Click on Metadata LIST Tab
        metadata.clickOnMetaDataListTab();
        assertTrue("Metadata list page is not ready.", metadata.isMetadataListReady());

        // get before refresh list
        List<String> listBeforeRefresh = metadata.getMetaDataList();

        // Click on refresh metadata button
        metadata.clickOnRefreshMetaData();

        // get After refresh list
        List<String> listAfterRefresh = metadata.getMetaDataList();

        // Compare list
        assertTrue("List after refresh are NOT same", metadata
                .checkMetaDataListBeforeAndAfterRefresh(listBeforeRefresh, listAfterRefresh));

        // Perform the logout action.
        logoutPage = logoutAux(metadata.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Select Facets in View general page and save
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Views_general'. -# Select facets for each sections -# Save it -# @see
     * logoutAux()
     */

    @Test(description = "Select Facets in View general page and save")
    public void configureFacetsSettings(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'MAPPINGS'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.MAPPINGS);

        // Validate MetadataConfiguration page
        MetadataConfiguration metadata = new MetadataConfiguration(DriverManager.getDriver(), sections);
        assertTrue("Metadata page is not ready.", metadata.isReady());

        // Click on Metadata LIST Tab
        metadata.clickOnMetaDataListTab();

        // Get list of Available metadata options
        List<String> avalibleMedaDataOptionsList = metadata.getMetaDataList();

        // Navigate to Administration area.
        DashboardPage dashboard2 = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard2.isReady());

        // Navigate to 'GENERAL_VIEWS'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.GENERAL_VIEWS);

        // Validate LDAP page
        FacetsInformationPage facets = new FacetsInformationPage(DriverManager.getDriver(), sections);
        assertTrue("Views General page is not ready.", facets.isReady());

        // Expand all sections
        facets.expandAllSections();
        assertTrue("Views General page is not ready.", facets.isReadyAfterExpandAll());

        // Move Options from available to selected for Parametric filters box
        facets.selectAllOptionsForParametricFilters();

        // list to be Selected in TitleAttributes
        List<String> listThatUsedToSelectForAssetThumbnailsInformationDisplayedOnHover = facets
                .getListToBeselectedInAssetThumbnailsInformationDisplayedOnHover();

        // Move Options from available to selected for Thumbnails filters box
        facets.selectOptionsForAssetThumbnailsInformationDisplayedOnHover();

        // list to be Selected in Asset list - Information displayed in table
        // columns
        List<String> listThatUsedToSelectForAssetlistInformationDisplayedInTableColumns = facets
                .getListToBeselectedInAssetListInformationDisplayedOnTable();

        // Move Options from available to selected for Asset list - Information
        // displayed in table columns
        facets.selectOptionsForAssetListInformationDisplayedOnTable();

        // Select all for options for Title Attribute box
        facets.selectAllOptionsForTitleAttributes();

        // Select all for Title Attribute Download box
        facets.selectAllOptionsForTitleAttributesForDownloads();

        // Click on SAVE
        facets.clickOnSave();

        // Expand all sections again to asset
        facets.expandAllSections();
        assertTrue("Views General page is not ready.", facets.isReadyAfterExpandAll());

        // Get list of Selected options in Parametric filters
        List<String> selectedParamtericFiltersList = facets.getListOfParametricSelectedFilters();

        // Get list of Selected options in TitleAttributes
        List<String> selectedTitleAttributesList = facets.getListOfTitleAttributes();

        // Get list of Selected options in TitleAttributes for download
        List<String> selectedTitleAttributesListForDownload = facets.getListOfTitleAttributesForDownloads();

        // Get list of Selected options in TitleAttributes for download
        List<String> selectedAssetlistInformationDisplayedInTableColumns = facets
                .getSelectedListAssetListInformationDisplayed();

        // Get list of Selected options in
        // AssetThumbnailsInformationDisplayedOnHover
        List<String> selectedAssetThumbnailsInformationDisplayedOnHover = facets
                .getSelectedListOfAssetThumbnailsInformationDisplayedOnHover();

        // Check SELECTED list has all the value which are selected before save
        assertTrue("Parametric selcted list is not with all selected values", facets
                .compareTwoLists(avalibleMedaDataOptionsList, selectedParamtericFiltersList));

        // Check SELECTED list has all the value which are selected before save
        assertTrue("Title Attributes selcted list is not with all selected values", facets
                .compareTwoLists(avalibleMedaDataOptionsList, selectedTitleAttributesList));

        // Check SELECTED list has all the value which are selected before save
        assertTrue("Title Attributes for download selcted list is not with all selected values", facets
                .compareTwoLists(avalibleMedaDataOptionsList, selectedTitleAttributesListForDownload));

        // Check SELECTED list has all the value which are selected before save
        assertTrue("Asset Thumbnails - Information displayed on hover selcted list is not with actuals selected values", facets
                .compareTwoLists(listThatUsedToSelectForAssetThumbnailsInformationDisplayedOnHover, selectedAssetThumbnailsInformationDisplayedOnHover));

        // Check SELECTED list has all the value which are selected before save
        assertTrue("Asset list - Information displayed in table columns selcted list is not with actuals selected values", facets
                .compareTwoLists(listThatUsedToSelectForAssetlistInformationDisplayedInTableColumns, selectedAssetlistInformationDisplayedInTableColumns));

        // Perform the logout action.
        logoutPage = logoutAux(facets.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Fill the texts for DRM , CopyRight and settings
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Views_Texts'. -# Select facets for each sections -# Save it -# @see
     * logoutAux()
     */

    @Test(description = "Select Facets in View general page and save")
    public void configureTextsSettings(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'TEXTS_VIEWS'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.TEXTS);

        // Validate LDAP page
        TextsTabPage texts = new TextsTabPage(DriverManager.getDriver(), sections);
        assertTrue("Views General page is not ready.", texts.isReady());

        // Fill details
        texts.fillDetails();

        // Save the details
        texts.clickOnSave();
        assertTrue("Views General page is not ready.", texts.isReady());

        // Perform the logout action.
        logoutPage = logoutAux(texts.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Fill landing page details
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Views_LandingPage'. -# Fill the details -# Save it -# @see logoutAux()
     */

    @Test(description = "Fill landing page details ")
    public void configureLandingAndAssetsDetails(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'LANDING'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.LANDING);

        // Validate LDAP page
        LandingAndAssetDetailsPage landingPage = new LandingAndAssetDetailsPage(DriverManager.getDriver(), sections);
        assertTrue("Landing page is not ready.", landingPage.isReady());

        // Fill the configuration details
        landingPage.fillLandingPageDetails();

        // Select SortBy Options
        landingPage.selectOptionsForSortByInLandingPage();

        // Save the LandingPage
        landingPage.clickOnSave();
        assertTrue("Landing page is not ready.", landingPage.isReady());

        /*  // Configure Assets Tab Page
        landingPage.configureAssetDetailsTab();*/

        // Select the options for Asset Information
        landingPage.selectOptionsForAssetInformation();

        // Save the Asset Details Tab Page
        landingPage.clickOnSave();

        // Perform the logout action.
        logoutPage = logoutAux(landingPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Create and Validate New diff types of Template
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * 'Views_Export template'. -# Fill the details -# Save it -# check if
     * exists in list -# @see logoutAux()
     */

    @Test(description = "Fill landing page details ")
    public void createNewExportTemplate(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'EXPORT'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.EXPORT);

        // Validate EXPORT page
        ExportTemplatePage exportTemplate = new ExportTemplatePage(DriverManager.getDriver(), sections);
        assertTrue("Export Template page is not ready.", exportTemplate.isReady());

        // Creating Template with empty details and validating isRequire message
        // Click on new Template
        exportTemplate.clickOnAddTemplate();
        assertTrue("Export Template create and edit page is not ready.", exportTemplate.isCreateAndEditPageReady());

        // Click On save with out filling details
        exportTemplate.clickOnSave();
        assertTrue("Required message is NOT shown", exportTemplate.isRequireMessageShown());

        // Adding List View Template
        // Fill details and create new Template
        String templateNameForListView = "ListViewExportTemplate" + new Date().getDate() + new Date().getTime();
        exportTemplate.fillAndSelectTemplateType(templateNameForListView, "List view Template");
        exportTemplate.selectAllOptionsForTemplateMetadataConfiguration();
        exportTemplate.clickOnSave();
        assertTrue("New template not shown in list", exportTemplate
                .isTemplateNameExistsInList(templateNameForListView));

        // Adding Detail View Template
        // Click on new Template
        exportTemplate.clickOnAddTemplate();
        assertTrue("Export Template create and exist page is not ready.", exportTemplate.isCreateAndEditPageReady());

        // Fill details and create new Template
        String templateNameforDetailView = "DetailviewExportTemplate" + new Date().getDate() + new Date().getTime();
        exportTemplate.fillAndSelectTemplateType(templateNameforDetailView, "detail view Template");
        exportTemplate.selectAllOptionsForTemplateMetadataConfiguration();
        exportTemplate.clickOnSave();
        assertTrue("New template not shown in list", exportTemplate
                .isTemplateNameExistsInList(templateNameforDetailView));

        // Adding Detail grid view with 2 columns TEMPLATE
        // Click on new Template
        exportTemplate.clickOnAddTemplate();
        assertTrue("Export Template create and exist page is not ready.", exportTemplate.isCreateAndEditPageReady());

        // Fill details and create new Template
        String templateNameforGridviewWith2columns = "GridviewWith2columnsExportTemplate" + new Date().getDate()
                + new Date().getTime();
        exportTemplate.fillAndSelectTemplateType(templateNameforGridviewWith2columns, "grid view with 2 columns");
        exportTemplate.selectAllOptionsForTemplateMetadataConfiguration();
        exportTemplate.clickOnSave();
        assertTrue("New template not shown in list", exportTemplate
                .isTemplateNameExistsInList(templateNameforGridviewWith2columns));

        // Adding Detail grid view with 4 columns TEMPLATE
        // Click on new Template
        exportTemplate.clickOnAddTemplate();
        assertTrue("Export Template create and exist page is not ready.", exportTemplate.isCreateAndEditPageReady());

        // Fill details and create new Template
        String templateNameforGridviewWith4columns = "GridviewWith4columnsExportTemplate" + new Date().getDate()
                + new Date().getTime();
        exportTemplate.fillAndSelectTemplateType(templateNameforGridviewWith4columns, "grid view with 4 columns");
        exportTemplate.selectAllOptionsForTemplateMetadataConfiguration();
        exportTemplate.clickOnSave();
        assertTrue("New template not shown in list", exportTemplate
                .isTemplateNameExistsInList(templateNameforGridviewWith4columns));

        // Perform the logout action.
        logoutPage = logoutAux(exportTemplate.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Click on Back from all sections
     * 
     * -# @see loginAux() -# Go to Profile and get the roles. -# Get the list of
     * the sections visible. -# Navigate to Administration area. -# Navigate to
     * all sections -# Click on Back -# Check the dashboard section -# @see
     * logoutAux()
     */

    @Test(description = "Click on Back from all sections ")
    public void goBackFromAllSections(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to Profile and get the roles.
        profilePage = searchPage.getHeader().clickOnProfileButton();
        List<String> roles = profilePage.getRoles();
        // Get the list of the sections visible.
        List<Section> sections = DashboardBuilder.buildDashboard(roles);

        // Navigate to Administration area.
        DashboardPage dashboard = searchPage.getHeader().clickOnAdministrationButton(sections);
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Application Library Web Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.LIBRARY_SERVERS);
        LibraryServersPage libraryPage = new LibraryServersPage(DriverManager.getDriver(), sections);
        assertTrue("Library page is not ready.", libraryPage.isReady());
        // Go back
        libraryPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'MediaBin Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.MEDIABIN);
        CreateAndEditMediabinServicesPage mbServicesPage = new CreateAndEditMediabinServicesPage(
                DriverManager.getDriver(), sections);
        assertTrue("MediaBin Service page is not ready.", mbServicesPage.isReady());
        // Go back
        mbServicesPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Email Services'.
        DashboardPage dashbrd = new DashboardPage(DriverManager.getDriver(), sections);
        dashbrd.goToSpecificSectionOrSubSectionPage(SectionType.EMAIL);
        CreateAndEditEmailAccountConfigPage emailconfigPage = new CreateAndEditEmailAccountConfigPage(
                DriverManager.getDriver(), sections);
        assertTrue("Email Service page is not ready.", emailconfigPage.isReady());
        // Go back
        emailconfigPage.goBack();
        assertTrue("Dashboard page is not ready.", dashbrd.isReady());

        // Navigate to 'Email Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CLOUD);
        // Go to Cloud Service page
        CreateAndEditCloudConfigPage cloudconfigPage = new CreateAndEditCloudConfigPage(DriverManager.getDriver(),
                sections);
        assertTrue("Email Service page is not ready.", cloudconfigPage.isReady());
        // Go back
        cloudconfigPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Job Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.SCHEDULED);
        CreateAndEditJobConfigPage jobconfigPage = new CreateAndEditJobConfigPage(DriverManager.getDriver(), sections);
        assertTrue("Email Service page is not ready.", jobconfigPage.isReady());
        // Go back
        jobconfigPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'Check All Services'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CHECK);
        CheckAllServicesPage checkallconfigPage = new CheckAllServicesPage(DriverManager.getDriver(), sections);
        assertTrue("Check ALL page is not ready.", checkallconfigPage.isReady());
        // Go back
        checkallconfigPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'MAPPINGS'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.MAPPINGS);
        MetadataConfiguration metadata = new MetadataConfiguration(DriverManager.getDriver(), sections);
        assertTrue("Metadata page is not ready.", metadata.isReady());
        // Go back
        metadata.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'METADATA'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.METADATA);
        MetadataConfiguration metadata2 = new MetadataConfiguration(DriverManager.getDriver(), sections);
        assertTrue("Metadata page is not ready.", metadata.isReady());
        // Go back
        metadata2.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'GENERAL_VIEWS'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.GENERAL_VIEWS);
        FacetsInformationPage facets = new FacetsInformationPage(DriverManager.getDriver(), sections);
        assertTrue("Views General page is not ready.", facets.isReady());
        // Go back
        facets.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'TEXTS_VIEWS'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.TEXTS);
        TextsTabPage texts = new TextsTabPage(DriverManager.getDriver(), sections);
        assertTrue("Views General page is not ready.", texts.isReady());
        // Go back
        texts.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'LANDING'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.LANDING);
        LandingAndAssetDetailsPage landingPage = new LandingAndAssetDetailsPage(DriverManager.getDriver(), sections);
        assertTrue("Landing page is not ready.", landingPage.isReady());
        // Go back
        landingPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'EXPORT'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.EXPORT);
        ExportTemplatePage exportTemplate = new ExportTemplatePage(DriverManager.getDriver(), sections);
        assertTrue("Export Template page is not ready.", exportTemplate.isReady());
        // Go back
        exportTemplate.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'CONTENT_PERMISSION'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.CONTENT_PERMISSION);
        ContentPermissionsPage filters = new ContentPermissionsPage(DriverManager.getDriver(), sections);
        assertTrue("Filter page is not ready.", filters.isReady());
        // Go back
        filters.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'MANAGE_PERMISSIONS'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.MANAGE_PERMISSIONS);
        MappingPermissionsSettingsPage mappingPermissions = new MappingPermissionsSettingsPage(
                DriverManager.getDriver(), sections);
        assertTrue("mappingPermissions page is not ready.", mappingPermissions.isReady());
        // Go back
        mappingPermissions.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'OTDS'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.OTDS);
        OTDSSettingsPage otdsSettingsPage = new OTDSSettingsPage(DriverManager.getDriver(), sections);
        assertTrue("LDAP Settings page is not ready.", otdsSettingsPage.isReady());
        // Go back
        otdsSettingsPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'ACTIVE_DIRECTORY'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.ACTIVE_DIRECTORY);
        ADSettingsPage adSettingsPage = new ADSettingsPage(DriverManager.getDriver(), sections);
        assertTrue("AD Settings page is not ready.", adSettingsPage.isReady());
        // Go back
        adSettingsPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'LDAP'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.LDAP);
        LDAPSettingsPage ldapSettingsPage = new LDAPSettingsPage(DriverManager.getDriver(), sections);
        assertTrue("LDAP Settings page is not ready.", ldapSettingsPage.isReady());
        // Go back
        ldapSettingsPage.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Navigate to 'ROLE'.
        dashboard.goToSpecificSectionOrSubSectionPage(SectionType.ROLE);
        RoleConfiguration rolesConfig = new RoleConfiguration(DriverManager.getDriver(), sections);
        assertTrue("Roles Config page is not ready.", rolesConfig.isReady());
        // Go back
        rolesConfig.goBack();
        assertTrue("Dashboard page is not ready.", dashboard.isReady());

        // Perform the logout action.
        logoutPage = logoutAux(rolesConfig.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

}