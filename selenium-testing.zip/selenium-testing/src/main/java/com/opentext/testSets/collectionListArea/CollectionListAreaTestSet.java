/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.collectionListArea;

import static org.testng.AssertJUnit.assertTrue;

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.pageObjects.containerCollections.ContainerCollectionsPage;
import com.opentext.pageObjects.createAndEditionCollection.specific.CreateCollectionPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contain the tests of the Collection List Area page in the web
 * application.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 * @author Trinadh Nakka<tnakka@opentext.com>
 * @author Mavya Papishetty <mpapishe@opentext.com>
 */
public class CollectionListAreaTestSet extends BasicTestSet {

    static Logger log = Logger.getLogger(CollectionListAreaTestSet.class);

    public CollectionListAreaTestSet() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
     * Check the Collection List Area page elements:
     * 
     * -# @see loginAux() -# Navigate to the Collection List Area. -# Check the
     * Collection List Area page. -# Navigate back to the Search page. -# @see
     * logoutAux()
     */
    @Test(description = "Check the Collection List Area page elements.")
    public void checkLayout(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        // Check the Collection List Area page.
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate back to the Search page.
        searchPage = collectionListAreaPage.goBackToSearch();
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Perform the logout action.
        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the Sort by of the collection list:
     *
     * -# @see loginAux() -# @see createSimpleCollectionAux() -# Navigate to the
     * Collection List Area. -# Expand all to see the collections. -# Change the
     * SortBy option. -# Check the changes. -# Collapse all. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Check the Sort by of the collection list.")
    public void sortByCollectionListTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        List<String> collecionName = new ArrayList<String>();

        // Create collections
        for (int i = 0; i < 3; i++) {
            collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Albums");
            collecionName.add(collectionPage.getTitle());
        }

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Expand all to see the collections.
        DriverManager.getDriver().sleep(2);
        collectionListAreaPage.expandAll();

        // For every option:
        for (int index = 1; index < collectionListAreaPage.getNumberOfOptionsInSortBy(); index++) {
            // Change the SortBy option.
            collectionListAreaPage.changeSortByOptionSelected(index);
            DriverManager.getDriver().sleep(2);
            // Check the changes.
            collectionListAreaPage.expandAll();
            assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        }
        // Collapse all.
        DriverManager.getDriver().sleep(2);
        collectionListAreaPage.collapseAll();

        // Delete the collection.
        for (int i = 0; i < 3; i++) {
            collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), collecionName.get(i));

        }

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Multi selection of collections:
     *
     * -# @see loginAux() -# @see createSimpleCollectionAux() -# Navigate to the
     * Collection List Area. -# Using Ctrl key select different collections. -#
     * Check selected collections. -# @see deleteCollectionAux() -# @see
     * logoutAux()
     */
    @Test(description = "Multi selection of collections.")
    public void multiSelectionIndividuallyTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        List<String> collecionName = new ArrayList<String>();

        // Create collections
        for (int i = 0; i < 3; i++) {
            collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Albums");
            collecionName.add(collectionPage.getTitle());
        }

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        // Using Ctrl key select different collections.
        int numberOfSelected = containerCollections.selectRandomCollections(collectionListAreaPage);
        // Check selected collections.
        assertTrue("Should be " + numberOfSelected + " selected collections but there are "
                + containerCollections.getCountOfSelected()
                + ".", containerCollections.getCountOfSelected() == numberOfSelected);

        // Delete the collection.
        for (int i = 0; i < 3; i++) {
            collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), collecionName.get(i));

        }

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Creation of a collection with an old expired date:
     *
     * -# @see loginAux(). -# Navigate to the Collection List Area. -# Navigate
     * to create collection area by New button. -# Fill 'Collection name' and
     * Comment. -# Fill expired date with an old expired date. -# Click on Save
     * button. -# @see logoutAux()
     */
    @Test(description = "Creation of a collection with an old expired date.")
    public void createCollectionOldExpiredDateTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to create collection area by New button.
        CreateCollectionPage createCollectionPage = collectionListAreaPage.goToCreateCollection();
        assertTrue("Create collection page is not ready.", createCollectionPage.isReady());

        // Fill 'Collection name' and Comment.
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date now = Calendar.getInstance().getTime();
        createCollectionPage.fillName("Collection - " + now.getTime());
        createCollectionPage.fillComment("Comment - " + df.format(now));

        // Fill expired date with an old expired date.
        df = new SimpleDateFormat("yyyy-MM-dd");
        createCollectionPage.fillExpiredDate(df.format(now));

        // Click on Save button.
        collectionPage = createCollectionPage.clickOnSaveButton();
        assertTrue("Collection page shouldn't be ready.", collectionPage == null);
        assertTrue("Create collection page is not ready.", createCollectionPage.isReady());

        logoutPage = logoutAux(createCollectionPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Creation of a collection and sharing to user:
     * 
     * -# @see loginAux() -# The user enters and log in the web. -# Create
     * Collection with assets and navigate to particular collection. -# Click on
     * Share button. -# Write a correct email. -# Fill Email and Comment. -#
     * Click on SendEmail. -# @see logoutAux()
     */
    @Test(description = "Creation of a collection and sharing with correct email address.")
    public void createCollectionAndShareWithCorrectEmail(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Search for asserts and create collection and also navigated to
        // created Collection
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_3, "Albums");

        // Click on Share button
        collectionPage.clickOnShareButton();
        assertTrue("SendEmail and Cancel buttons are not visible.", collectionPage.isSendEmailAndCancelButtonVisible());

        // Fill Email and ShareComment
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date now = Calendar.getInstance().getTime();
        collectionPage.fillShareCollectionEmail(UserDomain.LDAP_USER, UserType.QA1);
        collectionPage.fillShareCollectionComment("SharedComment - " + df.format(now));

        // Click on SendEmail
        collectionPage.clickOnSendEmail();
        assertTrue("Alert Message is NOT maching.", collectionPage
                .isSharedEmailMessageValid(UserDomain.LDAP_USER, UserType.QA1));

        // Logout
        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check that User tries to share a collection with an incorrect email.
     * 
     * -# @see loginAux() -# The user enters and log in the web. -# Create
     * Collection with assets and navigate to particular collection. -# Click on
     * Share button. -# Write an incorrect email. -# Click on Send button.
     * -# @see logoutAux()
     */
    @Test(description = "Share a collection with an incorrect email.")
    public void shareCollectionwithIncorrectemail(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Search for asserts and create collection and also navigated to
        // created Collection
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Albums");

        // Click on Share button
        collectionPage.clickOnShareButton();
        assertTrue("SendEmail and Cancel buttons are not visible.", collectionPage.isSendEmailAndCancelButtonVisible());

        // Fill Email and ShareComment
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date now = Calendar.getInstance().getTime();
        collectionPage.fillShareCollectionEmail(UserDomain.INVALID, UserType.QA1);
        collectionPage.fillShareCollectionComment("SharedComment - " + df.format(now));

        // Asserting Email text area description for invaild email's
        assertTrue("Invalid email textarea description is not present", collectionPage.isErrorMessageForInavlidEmail());

        // Click on SendEmail
        collectionPage.clickOnSendEmail();
        assertTrue("Alert Message is NOT maching.", collectionPage
                .isSharedEmailMessageInvalid(UserDomain.INVALID, UserType.QA1));

        // Logout
        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the counter of the collection when a collection is created or
     * deleted.
     * 
     * -# @see loginAux() -# The user enters and log in the web. -# Create a
     * Collection and check the collection counter. -# Delete a collection and
     * check the collection counter. -# @see logoutAux()
     */
    @Test(description = "Check the counter of the collection when a collection is created or deleted.")
    public void checkCollectionCounterTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Get the collection counter before creating a collection.
        int beforeCollectionCounter = searchPage.getHeader().getCollectionCounter();

        // Search for asserts and create collection and also navigated to created Collection
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Albums");
        String name = collectionPage.getTitle();

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Validate the collection counter.
        // collectionListAreaPage.expandAll();
        assertTrue("The number of collections should be increased by one, as a new collection - " + name
                + " is created. But Before Counter: " + beforeCollectionCounter + " After Counter: "
                + searchPage.getHeader().getCollectionCounter(), searchPage.getHeader()
                        .getCollectionCounter() == beforeCollectionCounter + 1);

        // ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        // int currentCollCount = containerCollections.getNumberOfCollectionsShown();

        collectionListAreaPage = deleteCollectionAux(searchPage.getHeader(), name);
        assertTrue("The number of collections should be decreased after deleting collection - " + name
                + " .", searchPage.getHeader().getCollectionCounter() == beforeCollectionCounter);

        // Logout
        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }
}
