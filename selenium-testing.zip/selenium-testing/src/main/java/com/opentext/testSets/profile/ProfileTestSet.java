/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.profile;

import static org.testng.AssertJUnit.assertTrue;

import java.awt.AWTException;
import java.io.IOException;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.pageObjects.profile.components.UploadPage;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contain the tests of the Profile page in the web application.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class ProfileTestSet extends BasicTestSet {

    static Logger log = Logger.getLogger(ProfileTestSet.class);

    public ProfileTestSet() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
        * Check the Profile page elements:
        * 
        * -# @see loginAux()
        * -# Go to profile page.
        * -# Check the profile page.
        * -# Go back to search page.
        * -# Check we have returned in search page.
        * -# @see logoutAux()
        */
    @Test(description = "Check the Profile page elements.")
    public void checkLayout(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to profile page.
        profilePage = searchPage.goToProfile();
        // Check the profile page.
        assertTrue("Profile page is not ready.", profilePage.isReady());

        // Go back to search page.
        searchPage = profilePage.clickOnBackButton();
        // Check we have returned in search page.
        assertTrue("Search page is not ready.", searchPage.isReady());

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the upload of profile image:
     * 
     * -# @see loginAux()
     * -# Go to profile page.
     * -# Click on Change button.
     * -# Upload a image.
     * -# Check the change of profile image.
     * -# @see logoutAux()
     * -# @throws AWTException 
     * @throws IOException 
     */
    @Test(description = "Check the upload of profile image.")
    public void uploadProfileImageTest(Method method) throws AWTException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to profile page.
        profilePage = searchPage.goToProfile();
        assertTrue("Profile page is not ready.", profilePage.isReady());

        String oldSrc = profilePage.getImageSrc();

        // Click on Change button.
        UploadPage uploadPage = profilePage.clickOnChangeButton();
        assertTrue("Upload page is not ready.", uploadPage.isReady());

        // Upload a image
        profilePage = uploadPage.uploadImage();
        assertTrue("Profile page is not ready.", profilePage.isReady());

        // Check the change of profile image.
        assertTrue("The new src of the profile image should be different to the old one.", !oldSrc
                .equalsIgnoreCase(profilePage.getImageSrc()));

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
        * Check the delete of profile image:
        * 
        * -# @see loginAux()
        * -# Go to profile page.
        * -# Upload a image.
        * -# Click on Delete button.
        * -# Check the profile image deleted.
        * -# @see logoutAux()
        * -# @throws AWTException 
     * @throws IOException 
        */

    @Test(description = "Check the delete of profile image.")
    public void deleteProfileImageTest(Method method) throws AWTException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Go to profile page.
        profilePage = searchPage.goToProfile();
        assertTrue("Profile page is not ready.", profilePage.isReady());
        String oldSrc = profilePage.getImageSrc();

        // Click on Change button.
        UploadPage uploadPage = profilePage.clickOnChangeButton();
        assertTrue("Upload page is not ready.", uploadPage.isReady());
        // Upload a image
        profilePage = uploadPage.uploadImage();
        assertTrue("Profile page is not ready.", profilePage.isReady());
        // Check the change of profile image.
        assertTrue("The new src of the profile image should be different to the old one.", !oldSrc
                .equalsIgnoreCase(profilePage.getImageSrc()));

        oldSrc = profilePage.getImageSrc();
        // Click on Delete button.
        profilePage.clickOnDeleteButton();
        // Check the profile image deleted.
        assertTrue("The new src of the profile image should be different to the old one.", !oldSrc
                .equalsIgnoreCase(profilePage.getImageSrc()));

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

}
