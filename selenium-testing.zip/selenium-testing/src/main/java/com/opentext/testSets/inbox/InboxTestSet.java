/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.inbox;

import static org.testng.AssertJUnit.assertTrue;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.pageObjects.collectionInfo.CollectionInfoPage;
import com.opentext.pageObjects.containerCollections.ContainerCollectionsPage;
import com.opentext.pageObjects.createAndEditionCollection.specific.CreateCollectionPage;
import com.opentext.pageObjects.createAndEditionCollection.specific.EditionCollectionPage;
import com.opentext.pageObjects.export.ExportPage;
import com.opentext.pageObjects.header.HeaderPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contain the tests of the Inbox in the web application.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class InboxTestSet extends BasicTestSet {
    static Logger log = Logger.getLogger(InboxTestSet.class);

    public InboxTestSet() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
     * Check the Inbox page elements:
     * 
     * -# @see loginAux() -# Go to inbox modal. -# Check the inbox modal. -#
     * Close inbox modal. -# @see logoutAux()
     */
    @Test(description = "Check the Inbox page elements.")
    public void checkLayout(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        // Go to inbox modal.
        inboxPage = searchPage.getHeader().clickOnInboxButton();
        // Check the inbox page.
        assertTrue("Inbox modal is not ready.", inboxPage.isReady());
        // Close inbox modal.
        inboxPage.close();
        logoutPage = logoutAux(searchPage.getHeader());
        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Mark all messages as read in the inbox:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Export the
     * content. -# Export the content again. -# Click on PDF button of one of
     * the templates. -# Check the counter of Inbox's messages has increased. -#
     * Enter in the Inbox and check the last 2 messages. -# Perform a click on
     * 'Mark all as read' button. -# Check unread messages. -# Close inbox
     * modal. -# @see deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Mark all messages as read in the inbox.")
    public void markAllAsReadTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();
        int inboxCounter = collectionPage.getHeader().getInboxCounter();
        // Export the content pdf format.
        ExportPage exportModal = collectionPage.goToExport();
        assertTrue("Export modal is not ready (or there are not any template created).", exportModal != null
                && exportModal.isReady());
        DriverManager.getDriver().sleep(2);
        exportModal.clickOnPDFButton(0);
        DriverManager.getDriver().sleep(1);
        // Export the content again in csv format.
        exportModal = collectionPage.goToExport();
        assertTrue("Export modal is not ready (or there are not any template created).", exportModal != null
                && exportModal.isReady());
        DriverManager.getDriver().sleep(2);
        exportModal.clickOnCSVButton(0);
        // Check the counter of Inbox's messages has increased.
        exportModal.sleep20andRefresh(); // This wait is needed to leave time to
                                         // receive the message.
        assertTrue("The inbox counter should have been increased.", collectionPage.getHeader()
                .getInboxCounter() == inboxCounter + 2);
        // Enter in the Inbox and check the last 2 messages.
        inboxPage = collectionListAreaPage.getHeader().clickOnInboxButton();
        assertTrue("The message should be as unread.", !inboxPage.isMessageRead(0));
        assertTrue("The message should be as unread.", !inboxPage.isMessageRead(1));
        // Perform a click on 'Mark all as read' button.
        inboxPage.clickOnMarkAllAsReadButton();
        // Check unread messages.
        assertTrue("Every message should be marked as read.", inboxPage.getNumberOfUnreadMessages() == 0);
        // Close inbox modal.
        inboxPage.close();
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);
        logoutPage = logoutAux(collectionListAreaPage.getHeader());
        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Using a download link of a message in the inbox:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Export the
     * content. -# Check the counter of Inbox's messages has increased. -# Enter
     * in the Inbox and check the last message. -# Use the link to download the
     * file. -# Check message status. -# @see deleteCollectionAux() -# @see
     * logoutAux()
     */
    @Test(description = "Using a download link of a message in the inbox.")
    public void usingDownloadLinkOfMessageTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Albums");
        String name = collectionPage.getTitle();
        int inboxCounter = collectionPage.getHeader().getInboxCounter();
        // Export the content.
        ExportPage exportModal = collectionPage.goToExport();
        assertTrue("Export modal is not ready (or there are not any template created).", exportModal != null
                && exportModal.isReady());
        exportModal.clickOnPDFButton(0);
        // Check the counter of Inbox's messages has increased.
        exportModal.sleep20andRefresh(); // This wait is needed to leave time to
                                         // receive the message.
        assertTrue("The inbox counter should have been increased.", collectionListAreaPage.getHeader()
                .getInboxCounter() == inboxCounter + 1);
        // Enter in the Inbox and check the last message.
        inboxPage = collectionListAreaPage.getHeader().clickOnInboxButton();
        assertTrue("The message should be as unread.", !inboxPage.isMessageRead(0));
        assertTrue("The message is not the correct one.", inboxPage.isMessageOfExportFile(0));
        // Use the link to download the file.
        inboxPage.clickOnLinkOfMessage(0);
        // Check message status.
        assertTrue("The message should be as unread.", inboxPage.isMessageRead(0));
        inboxPage.close();
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);
        logoutPage = logoutAux(collectionListAreaPage.getHeader());
        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Delete a message in the inbox:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Export the
     * content. -# Check the counter of Inbox's messages has increased. -# Enter
     * in the Inbox and check the last message. -# Click on Delete button of the
     * created message. -# Check the counter of messages. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Delete a message in the inbox.")
    public void deleteMessageTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Albums");
        String name = collectionPage.getTitle();
        int inboxCounter = collectionPage.getHeader().getInboxCounter();
        // Export the content.
        ExportPage exportModal = collectionPage.goToExport();
        assertTrue("Export modal is not ready (or there are not any template created).", exportModal != null
                && exportModal.isReady());
        exportModal.clickOnPDFButton(0);
        // Check the counter of Inbox's messages has increased.
        exportModal.sleep20andRefresh(); // This wait is needed to leave time to
                                         // receive the message.
        assertTrue("The inbox counter should have been increased.", collectionListAreaPage.getHeader()
                .getInboxCounter() == inboxCounter + 1);
        // Enter in the Inbox and check the last message.
        inboxPage = collectionListAreaPage.getHeader().clickOnInboxButton();
        assertTrue("The message should be as unread.", !inboxPage.isMessageRead(0));
        assertTrue("The message is not the correct one.", inboxPage.isMessageOfExportFile(0));
        // Click on Delete button of the created message.
        inboxCounter = inboxPage.getTotalMessages();
        inboxPage.clickOnDeleteButton(0);
        // Check the counter of messages.
        assertTrue("The message should be as unread.", inboxCounter == inboxPage.getTotalMessages() + 1);
        inboxPage.close();
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);
        logoutPage = logoutAux(collectionListAreaPage.getHeader());
        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Deleting all messages in the inbox:
     * 
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     * 
     *         -# @see loginAux() -# Check the counter of Inbox's messages. -#
     *         If counter greated than zero then enter in the Inbox. -# Click on
     *         Delete button of the created message. -# Check the counter of
     *         messages. -# @see deleteCollectionAux() -# Delete all the
     *         messages until the counter is zero and verify no messages text.
     *         -# @see logoutAux()
     * 
     */
    @Test(description = "Delete all messages in the inbox and verify no messages text.")
    public void deleteAllMessageTestVerifyNoMessagesText(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());
        // Login to the application
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        // Enter in the Inbox and check the last message.
        inboxPage = searchPage.getHeader().clickOnInboxButton();
        // delete all messages
        inboxPage.deleteAllMessages();
        // Check the counter of messages is zero.
        assertTrue("The counter of the message should be zero.", inboxPage.getTotalMessages() == 0);
        // Close the Inbox
        inboxPage.close();
        // Logout
        logoutPage = logoutAux(searchPage.getHeader());
        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * User tries to create a new collection with assets and edit collection by
     * adding shared user and collection user and verify inbox alerts.
     * 
     * @author Sowjanya Lankadasu <slankada@opentext.com>.
     * 
     *         -# @see loginAux() with superuser. -# @see
     *         createCollectionWithAssetsAux(). -# Navigate to the Collection
     *         List Area. -# Navigate to the created collection -# Navigate to
     *         collection info modal. -# Navigate to edit collection modal. -#
     *         Add another Collection owner and shared user to the created
     *         collection and save. -# @see logoutAndLoginAux() with Collection
     *         Owner user. -# Check for inbox message. -# Navigate to the
     *         Collection List Area. -# Check if the Collection owner have the
     *         collection in My Collection tab. -# @see logoutAndLoginAux() with
     *         Shared user. -# Check for inbox message. -# Navigate to the
     *         Collection List Area. -# Check if the Shared User have the
     *         collection in Shared tab. -# @see logoutAux().
     */
    @Test(description = "Verify inbox messages when user tries to share a new collection with a shared user and with another owner user.")
    public void verifyCollectionRelatedInboxTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName()
                + " - Start test method: verifyCollectionRelatedInboxTest");
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        // Create collection by giving shared user and Collection Owner.
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Albums");
        // Save name of the collection.
        String name = collectionPage.getTitle();
        // Navigate to the Collection List Area.
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        collectionListAreaPage = headerPage.clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());
        // Navigate to collection info modal.
        CollectionInfoPage infoModal = collectionPage.goToInfo();
        assertTrue("Collection Info modal is not ready.", infoModal.isReady());
        // Navigate to edit collection modal.
        EditionCollectionPage editPage = infoModal.goToEditModal();
        assertTrue("Edit collection modal is not ready.", editPage.isReady());
        // Add Collection owner and shared user to the created collection
        CreateCollectionPage createCollectionPage = new CreateCollectionPage(DriverManager.getDriver());
        createCollectionPage.fillCollectionOwnerEmail(COLLECTION_OWNER);
        createCollectionPage.fillSharetoEmail(SHARED_USER);
        // Click on Save button.
        editPage.clickOnSaveButton();
        assertTrue("Collection page is not ready.", collectionPage.isReady());
        // log out and login again with Shared user.
        searchPage = logoutAndLoginAux(UserDomain.SHAREDUSER, UserType.QA1);
        // Enter in the Inbox and check the last message.
        inboxPage = searchPage.getHeader().clickOnInboxButton();
        // Get the number of messages
        int inboxCounterShared = inboxPage.getTotalMessages();
        assertTrue("The message is not collection related message.", inboxPage
                .isMessageGeneratedForCollection(name, UserDomain.SUPERADMIN, UserType.QA1, "Shared"));
        // Check the counter of messages decreased by one.
        assertTrue("The message count is not decreased by one.", inboxCounterShared == inboxPage.getTotalMessages()
                + 1);
        // Closing the inbox dialog
        inboxPage.close();
        // log out and login again with Collection owner user.
        searchPage = logoutAndLoginAux(UserDomain.COLLECTIONOWNER, UserType.QA1);
        // Enter in the Inbox and check the last message.
        inboxPage = searchPage.getHeader().clickOnInboxButton();
        // Get the number of messages
        int inboxCounter = inboxPage.getTotalMessages();
        assertTrue("The message is not collection related message.", inboxPage
                .isMessageGeneratedForCollection(name, UserDomain.SUPERADMIN, UserType.QA1, "Owner"));
        // Check the counter of messages decreased by one.
        assertTrue("The message count is not decreased by one.", inboxCounter == inboxPage.getTotalMessages() + 1);
        // Closing the inbox dialog
        inboxPage.close();
        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        // Navigate to the created collection.
        ContainerCollectionsPage containerCollection = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollection.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());
        // Delete the created collection
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);
        // Logout from shared user
        logoutPage = logoutAux(collectionListAreaPage.getHeader());
        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: verifyCollectionRelatedInboxTest");
    }
}