/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils;

/**
 * Abstraction that represents an Configuration.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class ConfigAD {

    public enum ConfigADDetails {
        ADSERVERNAME, INVALIDADSERVERNAME, ADPORT, ADDN, ADDNPASSWORD, ADDOMAIN, ADEMAIL, ADBASEDN;
    }

    /**
     * AD serverame Input.
     */
    private String adServerName;

    /**
    * AD portNumberInput .
    */
    private String adPortNumberInput;

    /**
    * AD DN .
    */
    private String addn;

    /**
    * AD DN Password
    */
    private String adDNPassword;

    /**
    * AD Domain
    */
    private String adDomain;

    /**
    * AD Email
    */
    private String adEmail;

    /**
    * AD Email
    */
    private String adBaseDN;

    /**
     * Constructor.
     * @param adServerName to be used
     * @param adPort to be used.
     * @param addn to be used.
     * @param adDNPassword to be used.
     * @param adDomain to be used.
     * @param adEmail to be used.
     * @param adBaseDN to be used.
     */
    public ConfigAD(String adServerName, String adPort, String addn, String adDNPassword, String adDomain,
            String adEmail, String adBaseDN) {

        this.setADServerName(adServerName);
        this.setADPortNumberInput(adPort);
        this.setADdn(addn);
        this.setADDNPassword(adDNPassword);
        this.setADDomain(adDomain);
        this.setADEmail(adEmail);
        this.setADBaseDN(adBaseDN);

    }

    /**
    * @return the check adServerInput
    */
    public String getADServerName() {
        return adServerName;
    }

    /**
    * @param check adServerInput to set.
    */
    public void setADServerName(String adServerName) {
        this.adServerName = adServerName;
    }

    /**
    * @return the check ADPortNumberInput
    */
    public String getADPortNumberInput() {
        return adPortNumberInput;
    }

    /**
    * @param check ADPortNumberInput to set.
    */
    public void setADPortNumberInput(String adPortNumberInput) {
        this.adPortNumberInput = adPortNumberInput;
    }

    /**
    * @return the check ADdn
    */
    public String getADdn() {
        return addn;
    }

    /**
    * @param check ADdn to set.
    */
    public void setADdn(String addn) {
        this.addn = addn;
    }

    /**
    * @return the check ADDNPassword
    */
    public String getADDNPassword() {
        return adDNPassword;
    }

    /**
    * @param check ADDNPassword to set.
    */
    public void setADDNPassword(String adDNPassword) {
        this.adDNPassword = adDNPassword;
    }

    /**
     * @return the check ADDomain
     */
    public String getADDomain() {
        return adDomain;
    }

    /**
    * @param check ADDomain to set.
    */
    public void setADDomain(String adDomain) {
        this.adDomain = adDomain;
    }

    /**
     * @return the check ADEmail
     */
    public String getADEmail() {
        return adEmail;
    }

    /**
    * @param check ADEmail to set.
    */
    public void setADEmail(String adEmail) {
        this.adEmail = adEmail;
    }

    /**
     * @return the check ADBaseDN
     */
    public String getADBaseDN() {
        return adBaseDN;
    }

    /**
    * @param check ADBaseDN to set.
    */
    public void setADBaseDN(String adBaseDN) {
        this.adBaseDN = adBaseDN;
    }

}
