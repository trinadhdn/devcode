/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils;

/**
 * Abstraction that represents an user.
 * 
 * @author Alejandro Gomez <amoron@emergya.com>
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class UserTest {

    public enum UserType {
        QA1, QA2, QA3;
    }

    public enum UserDomain {

        SUPERADMIN, SUPERADMINOTMM, LDAP_ADMIN, LDAP_USER, NO_COLLECTION, NON_ADMIN, NO_CREATE_COLLECTION, NO_DOWNLOAD, NO_VIEW_INBOX, NO_VIEW_VIDEOS, WRONGCREDENTIALS, GOOGLE, INVALID, SHAREDUSER, COLLECTIONOWNER, RMM, DHAMTDEFAULTUSER;

    }

    /**
     * Username.
     */
    private String username;

    /**
     * Password.
     */
    private String password;

    /**
     * Constructor.
     * @param username to be used
     * @param password to be used.
     */
    public UserTest(String username, String password) {
        this.setUsername(username);
        this.setPassword(password);
    }

    /**
     * @return the username.
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the password.
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set.
     */
    public void setPassword(String password) {
        this.password = password;
    }

}
