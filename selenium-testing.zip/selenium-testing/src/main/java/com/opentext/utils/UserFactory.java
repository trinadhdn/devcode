/**
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;

import com.opentext.selenium.utils.PropertiesHandler;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

public abstract class UserFactory {

    /**
     * It retrieves a {@link UserTest} instance depending on the provided domain.
     * It looks for an user that matches in users.properties file like:
     *    domain.userType.username
     *    domain.userType.password
     * @param domain of the user to be retrieved.
     * @userType of the user you want to be retrieved.
     * @return a {@link UserTest}.
     */
    public static UserTest getUser(UserDomain domain, UserType userType) {
        String username = "NOT_DEFINED";
        String password = "NOT_DEFINED";
        // domain and userType are mandatory
        if (domain != null && userType != null) {
            PropertiesHandler handler = PropertiesHandler.getInstance();
            handler.load("users.properties");
            // getting username
            if (StringUtils.isNotBlank(handler
                    .get(domain.name().toLowerCase() + "." + userType.name().toLowerCase() + ".username"))) {
                username = handler.get(domain.name().toLowerCase() + "." + userType.name().toLowerCase() + ".username");
            } else {
                Assert.assertTrue(false, "There is no defined username for " + domain.name().toLowerCase() + "."
                        + userType.name().toLowerCase());
            }
            // getting password
            if (StringUtils.isNotBlank(handler
                    .get(domain.name().toLowerCase() + "." + userType.name().toLowerCase() + ".password"))) {
                password = handler.get(domain.name().toLowerCase() + "." + userType.name().toLowerCase() + ".password");
            } else {
                Assert.assertTrue(false, "There is no defined password for " + domain.name().toLowerCase() + "."
                        + userType.name().toLowerCase());
            }
        }
        UserTest user = new UserTest(username, password);
        return user;
    }

}
