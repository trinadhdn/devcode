/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils;

/**
 * Abstraction that represents a section/subsection category.
 * 
 * @author Alejandro Gomez <amoron@emergya.com>
 * @author Ivan Gomez <igomez@emergya.com>
 */
public enum SectionType {

    // @formatter:off
    // Sections, subsection, subsectionTabs:
    GENERAL("section:general"), LIBRARY("subsection:general-web_services"), LIBRARY_SERVERS("subsection-tab:general-web_services-servers"), LIBRARY_SERVICES("subsection-tab:general-web_services-services"), MEDIABIN("subsection:general-mediabin"), EMAIL("subsection:general-email"), CLOUD("subsection:general-gdrive"), SCHEDULED("subsection:general-scheduled_jobs"), CHECK("subsection:general-check_services"), 
    METADATA("section:metadata"),  MAPPINGS("subsection:metadata-mappings"), LIST("subsection:metadata-list"),
    VIEWS("section:views"), GENERAL_VIEWS("subsection:views-general_views"), TEXTS("subsection:views-settings"), LANDING("subsection:views-landing_page"), DETAILS("subsection:views-asset_details"), EXPORT("subsection:views-export_templates"),
    SECURITY("section:security"), CONTENT_PERMISSION("subsection:security-filters"), ACTIVE_DIRECTORY("subsection:security-active_directory"), OTDS("subsection:security-otds"), LDAP("subsection:security-ldap"), ROLE("subsection:security-permissions"), MANAGE_PERMISSIONS("subsection:security-manage_permissions"), 
    MICROSITES("section:microsite"), GENERAL_MICROSITES("subsection:microsite-general_microsite"), LINKS("subsection:microsite-links_microsite"), BANNERS("subsection:microsite-banners_microsite"), TEST_USERS("subsection:microsite-users_microsite");
    //@formatter:on

    private String type;

    private SectionType(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

}
