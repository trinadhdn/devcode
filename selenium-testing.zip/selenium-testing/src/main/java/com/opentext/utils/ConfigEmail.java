/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils;

/**
 * Abstraction that represents an Configuration.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class ConfigEmail {

    public enum ConfigEMailDetails {
        MAILSERVERNAMEINPUT, EMAILPORTINPUT, EMAILUSERNAMEINPUT, EMAILUSERPASSINPUT, SENDEREMAILACCOUNT, SENDERNAME, SENDEMAILTEST, SENDINVALIDEMAILTEST, SENDINVALIDMAILTEST;
    }

    /**
     * Mail server name.
     */
    private String mailservernameinput;

    /**
     * Mail server name.
     */
    private String emailportinput;

    /**
    * Email UserName Input.
    */
    private String emailuserNameInput;

    /**
     * Email Password Input.
     */
    private String emailuserPassInput;

    /**
    * Sender Email Account.
    */
    private String senderEmailAccount;

    /**
     * Sender Name.
     */
    private String sendername;

    /**
    * Check Email Test.
    */
    private String sendemailtest;

    /**
     * Check InValid Email Test.
     */
    private String sendInvalidemailtest;

    /**
    * Constructor.
    * @param mailservername to be used
    * @param emailportinput to be used.
    * @param emailuserNameInput to be used.
    * @param emailuserPassInput to be used.
    * @param senderEmailAccount to be used.
    * @param sendername to be used.
    * @param checkEmailTest to be used.
    */
    public ConfigEmail(String mailservernameinput, String emailportinput, String emailuserNameInput,
            String emailuserPassInput, String senderEmailAccount, String sendername, String checkEmailTest) {
        this.setMailServerName(mailservernameinput);
        this.setEmailPortInput(emailportinput);
        this.setEmailUserNameInput(emailuserNameInput);
        this.setEmailPassNameInput(emailuserPassInput);
        this.setEmailAccountInput(senderEmailAccount);
        this.setSenderName(sendername);
        this.setSendEmailTest(checkEmailTest);

    }

    /**
    * @return the mailservernameinput.
    */
    public String getMailServerName() {
        return mailservernameinput;
    }

    /**
    * @param mailservername to set.
    */
    public void setMailServerName(String mailservernameinput) {
        this.mailservernameinput = mailservernameinput;
    }

    /**
    * @return the EmailUserNameInput.
    */
    public String getEmailUserNameInput() {
        return emailuserNameInput;
    }

    /**
    * @param EmailUserNameInput to set.
    */
    public void setEmailUserNameInput(String emailuserNameInput) {
        this.emailuserNameInput = emailuserNameInput;
    }

    /**
    * @return the EmailPassNameInput.
    */
    public String getEmailPassNameInput() {
        return emailuserPassInput;
    }

    /**
    * @param EmailPassNameInput to set.
    */
    public void setEmailPassNameInput(String emailuserPassInput) {
        this.emailuserPassInput = emailuserPassInput;
    }

    /**
    * @return the EmailAccountInput.
    */
    public String getEmailAccountInput() {
        return senderEmailAccount;
    }

    /**
    * @param EmailAccountInput to set.
    */
    public void setEmailAccountInput(String senderEmailAccount) {
        this.senderEmailAccount = senderEmailAccount;
    }

    /**
    * @return the Sender Name.
    */
    public String getSenderName() {
        return sendername;
    }

    /**
    * @param Sender Name to set.
    */
    public void setSenderName(String senderName) {
        this.sendername = senderName;
    }

    /**
    * @return the checkEmailTest
    */
    public String getSendEmailTest() {
        return sendemailtest;
    }

    /**
    * @param checkEmailTest to set.
    */
    public void setSendEmailTest(String sendemailtest) {
        this.sendemailtest = sendemailtest;
    }

    /**
     * @return the EmailPortInput
     */
    public String getEmailPortInput() {
        return emailportinput;
    }

    /**
    * @param EmailPortInput to set.
    */
    public void setEmailPortInput(String emailportinput) {
        this.emailportinput = emailportinput;
    }

    /**
    * @return the check Invalid EmailTest
    */
    public String getSendInvalidEmailTest() {
        return sendInvalidemailtest;
    }

    /**
    * @param check invalid EmailTest to set.
    */
    public void setSendInvalidEmailTest(String sendInvalidemailtest) {
        this.sendInvalidemailtest = sendInvalidemailtest;
    }

}
