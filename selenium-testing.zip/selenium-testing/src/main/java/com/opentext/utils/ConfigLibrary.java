/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils;

/**
 * Abstraction that represents an Configuration.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class ConfigLibrary {

    public enum ConfigDetails {
        SERVERNAME, SERVERHOSTNAME, USER, PASSWORD, PORT, INVALIDSERVERHOSTNAME;
    }

    /**
     * ServerName.
     */
    private String servername;

    /**
     * ServerHostName.
     */
    private String serverhostname;

    /**
     * User.
     */
    private String user;

    /**
     * Password.
     */
    private String password;

    /**
     * Port.
     */
    private String port;

    /**
     * Constructor.
     * @param servername to be used
     * @param serverhostname to be used.
     * @param user to be used.
     * @param password to be used.
     * @param port to be used.
     */
    public ConfigLibrary(String servername, String serverhostname, String user, String password, String port) {
        this.setServerName(servername);
        this.setServerHostName(serverhostname);
        this.setUser(user);
        this.setPassword(password);
        this.setPort(port);
    }

    /**
     * @return the servername.
     */
    public String getServerName() {
        return servername;
    }

    /**
     * @param servername the servername to set.
     */
    public void setServerName(String servername) {
        this.servername = servername;

    }

    /**
     * @return the serverhostname.
     */
    public String getServerHostName() {
        return serverhostname;
    }

    /**
     * @param serverhostname the serverhostname to set.
     */
    public void setServerHostName(String serverhostname) {
        this.serverhostname = serverhostname;

    }

    /**
     * @return the user.
     */
    public String getUser() {
        return user;
    }

    /**
     * @param user the user to set.
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * @return the password.
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the port.
     */
    public String getPort() {
        return port;
    }

    /**
     * @param port to set.
     */
    public void setPort(String port) {
        this.port = port;
    }

}
