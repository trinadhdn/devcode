/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.containerAssets;

import static org.testng.AssertJUnit.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.assetDetails.AssetDetailsPage;
import com.opentext.pageObjects.collection.CollectionPage;
import com.opentext.pageObjects.containerAssets.assetPreview.AssetPreviewPage;
import com.opentext.pageObjects.containerAssets.assetPreview.specificViews.AssetPreviewListViewPage;
import com.opentext.pageObjects.containerAssets.assetPreview.specificViews.AssetPreviewThumbsViewPage;
import com.opentext.pageObjects.search.SearchPage;
import com.opentext.pageObjects.singleDownload.specificModal.SingleDownloadPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.AssetCategoryValues.AssetType;

/**
 * This PO contains the methods to interact with the Container of assets.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class ContainerAssetsPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(ContainerAssetsPage.class);

    /**
     * Components
     */
    protected CopyOnWriteArrayList<AssetPreviewPage> assetsPreviews;
    private volatile boolean thumbsView;
    private volatile int counterAssets;

    /**
     * Items keys selectors.
     */
    private final static String LIST_ASSETS = "listAssets";
    private final static String LIST_ASSETIDS = "listAssetIDs";
    private final static String LIST_SELECTED = "listSelected";

    private final static String NOTFOUND_TEXT = "notFoundText";

    private final static String BACK_TO_TOP = "backToTop";
    protected final static String SPINNER_MORE_ASSETS = "spinnerMoreAssets";
    private final static String ITEMS_LEFT = "itemsLeft";

    /**
     * Constructor method.
     * 
     * @param driver
     *            selenium webdriver.
     * @param true
     *            if we are in thumbsview, false if we are in listview.
     * @param number
     *            of assets given by search bar counter.
     */
    public ContainerAssetsPage(EmergyaWebDriver driver, boolean thumbsView, int counterAssets) {
        super(driver);
        this.thumbsView = thumbsView;
        this.counterAssets = counterAssets;
        this.initializeList();
        this.isReady();
    }

    /**
     * Constructor method.
     * 
     * @param driver
     *            selenium webdriver.
     * @param true
     *            if we are in thumbsview, false if we are in listview.
     * @param number
     *            of assets given by search bar counter.
     */
    public ContainerAssetsPage(EmergyaWebDriver driver) {
        super(driver);

    }

    /**
     * Method to initialize the list.
     */
    public synchronized void initializeList() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start initializeList method");

        this.waitUntilDisappearByXPath(SPINNER);
        this.waitUntilDisappearByXPath(SPINNER_MORE_ASSETS);
        if (counterAssets > 0) {
            assetsPreviews = new CopyOnWriteArrayList<AssetPreviewPage>();
            if (thumbsView) {
                // Thumbs view
                for (int i = 0; i < getNumberOfAssetsShown(); i++) {
                    assetsPreviews.add(new AssetPreviewThumbsViewPage(driver, i));
                }
            } else {
                // List view
                for (int i = 0; i < getNumberOfAssetsShown(); i++) {
                    assetsPreviews.add(new AssetPreviewListViewPage(driver, i));
                }
            }
        } else {
            assetsPreviews = null;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End initializeList method");
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = true;
        if (counterAssets > 0) {
            for (int i = 0; i < assetsPreviews.size() && isReady; i++) {
                if (!assetsPreviews.get(i).isReady()) {
                    isReady = false;
                }
            }
            // If the total of asset > the number of assets shown -> ITEMS_LEFT
            // should be exists
            if (this.counterAssets > this.getNumberOfAssetsShown() && this.isElementVisibleByXPath(ITEMS_LEFT)) {
                // The assets shown + assets left should be equal to total of
                // assets
                if (this.counterAssets != this.getNumberOfAssetsShown() + this.getNumberOfAssetsLeft()) {
                    isReady = false;
                }
            }
        } else { // No assets: should appear Not found text.
            if (!this.isElementVisibleByXPath(NOTFOUND_TEXT)) {
                isReady = false;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        if (counterAssets > 0) {
            for (int i = 0; i < assetsPreviews.size(); i++) {
                assetsPreviews.get(i).waitForReady();
            }
            // If the total of asset > the number of assets shown -> ITEMS_LEFT
            // should be waited
            if (this.counterAssets > this.getNumberOfAssetsShown()) {
                this.waitForByXPath(ITEMS_LEFT);
            }
        } else { // Wait for NOTFOUND_TEXT if there are not assets.
            this.waitForByXPath(NOTFOUND_TEXT);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return number of assets shown.
     */
    public int getNumberOfAssetsShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getNumberOfAssetsShown method");

        this.waitUntilDisappearByXPath(SPINNER);
        this.waitForByXPath(LIST_ASSETS);
        this.driver.sleep(2);
        int counterAssetsShown = 0;
        for (int i = 0; i <= 3; i++) {
            if (this.retryAndGetElementsByXPath(LIST_ASSETS)) {
                if (this.getElementsByXPath(LIST_ASSETS).size() != 0) {
                    counterAssetsShown = this.getElementsByXPath(LIST_ASSETS).size();
                    break;
                }

            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumberOfAssetsShown method");

        return counterAssetsShown;
    }

    /**
     * @return number of assets left.
     */
    private synchronized int getNumberOfAssetsLeft() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getNumberOfAssetsLeft method");

        this.waitForByXPath(ITEMS_LEFT);
        this.waitUntilDisappearByXPath(SPINNER);
        this.waitUntilDisappearByXPath(SPINNER_MORE_ASSETS);
        int counterAssetsLeft = Integer
                .parseInt(this.getElementByXPath(ITEMS_LEFT).getText().replaceAll("[^0-9]", "").trim());
        if ((Integer) counterAssetsLeft == null) {

            this.driver.sleep(10);
            counterAssetsLeft = Integer
                    .parseInt(this.getElementByXPath(ITEMS_LEFT).getText().replaceAll("[^0-9]", "").trim());

        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumberOfAssetsLeft method");

        return counterAssetsLeft;
    }

    /**
     * Method to charge more assets using Scroll.
     */
    public void scrollToChargeMoreAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start scrollToChargeMoreAssets method");
        this.driver.sleep(3);
        this.waitUntilDisappearByXPath(SPINNER);
        this.waitForByXPath(ITEMS_LEFT);
        this.retryAndGetElementByXPath(ITEMS_LEFT);
        assertTrue("ItemsLeft element is not ready.", this.isElementVisibleByXPath(ITEMS_LEFT));
        this.scrollBottom();
        this.waitForByXPath(SPINNER_MORE_ASSETS);
        this.driver.sleep(1);
        this.waitUntilDisappearByXPath(SPINNER_MORE_ASSETS);
        this.driver.sleep(3);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End scrollToChargeMoreAssets method");
    }

    /**
     * Method to charge more assets using Scroll.
     */
    public void scrollTopByGoToTopButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start scrollTopByGoToTopButton method");

        assertTrue("ItemsLeft element is not ready.", this.isBackToTopButtonShown());

        this.getElementByXPath(BACK_TO_TOP).click();
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(2);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End scrollTopByGoToTopButton method");
    }

    /**
     * @return if the BackToTop button is shown or not.
     */
    public boolean isBackToTopButtonShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isBackToTopButtonShown method");

        this.waitUntilDisappearByXPath(SPINNER_MORE_ASSETS);
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(1);

        boolean isReady = false;
        if (this.isElementVisibleByXPath(BACK_TO_TOP, 5)) {
            if (this.getElementByXPath(BACK_TO_TOP).isDisplayed()) {
                isReady = true;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isBackToTopButtonShown method");

        return isReady;
    }

    /**
     * Method to select randomly the assets shown, using Ctrl Key.
     * 
     * @param searchPage
     *            to get the focus out.
     * @return Integer number of selected assets.
     */
    public Integer selectRandomAssetsUsingCtrlKey(SearchPage searchPage) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectRandomAssetsUsingCtrlKey method");

        int numberOfSelected = 0;
        boolean selected = false;

        action.keyDown(Keys.LEFT_CONTROL).perform();
        List<WebElement> listofAssets = this.getElementsByXPath(LIST_ASSETS);
        searchPage.waitForDownloadButtonReady();

        do {
            numberOfSelected = 0;
            for (int index = 0; index < assetsPreviews.size(); index++) {
                if ((int) (Math.random() * 2 + 1) == 1) { // If a random number
                                                          // between 1 & 2 is
                                                          // equal to 1
                    ((AssetPreviewThumbsViewPage) assetsPreviews.get(index)).selectAssets(listofAssets.get(index));
                    searchPage.getHeader().getFocusOnLogo();
                    numberOfSelected++;
                    selected = true;
                }
            }
        } while (!selected);

        action.keyUp(Keys.LEFT_CONTROL).perform();
        assertTrue("The download button should be shown.", searchPage.isDownloadButtonShown());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectRandomAssetsUsingCtrlKey method");

        return numberOfSelected;
    }

    /**
     * Method to select randomly the assets shown, using Ctrl Key.
     * 
     * @param collectionPage
     *            to get the focus out.
     * @param index
     *            of the asset to select.
     * @return Integer number of selected assets.
     */
    public void selectGivenAssetUsingCtrlKey(CollectionPage collectionPage, int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectGivenAssetUsingCtrlKey method");

        action.keyDown(Keys.LEFT_CONTROL).perform();
        List<WebElement> listofAssets = this.getElementsByXPath(LIST_ASSETS);

        ((AssetPreviewThumbsViewPage) assetsPreviews.get(index)).selectAssets(listofAssets.get(index));
        collectionPage.setActionAreaOpen(true);
        collectionPage.waitForReady();

        action.keyUp(Keys.LEFT_CONTROL).perform();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectGivenAssetUsingCtrlKey method");
    }

    /**
     * Method to select randomly the assets shown, using Ctrl Key.
     * 
     * @param collectionPage
     *            to get the focus out.
     * @return Integer number of selected assets.
     */
    public Integer selectRandomAssetsUsingCtrlKey(CollectionPage collectionPage) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectRandomAssetsUsingCtrlKey method");

        int numberOfSelected = 0;
        boolean selected = false;

        List<WebElement> listofAssets = this.getElementsByXPath(LIST_ASSETS);
        action.keyDown(Keys.LEFT_CONTROL).perform();

        do {
            numberOfSelected = 0;
            for (int index = 2; index < assetsPreviews.size(); index++) {
                if ((int) (Math.random() * 2 + 1) == 1) { // If a random number
                                                          // between 1 & 2 is
                                                          // equal to 1
                    ((AssetPreviewThumbsViewPage) assetsPreviews.get(index)).selectAssets(listofAssets.get(index));
                    collectionPage.getHeader().getFocusOnLogo();
                    numberOfSelected++;
                    selected = true;
                    collectionPage.setActionAreaOpen(true);
                }
            }
        } while (!selected);

        action.keyUp(Keys.LEFT_CONTROL).perform();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectRandomAssetsUsingCtrlKey method");

        return numberOfSelected;
    }

    /**
     * @return the counter of selected assets.
     */
    public int getCountOfSelected() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCountOfSelected method");

        int count = 0;
        if (this.isElementVisibleByXPath(LIST_SELECTED)) {
            count = this.getElementsByXPath(LIST_SELECTED).size();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCountOfSelected method");

        return count;
    }

    /**
     * Method to select a range of assets from/to given index, using Shift key.
     * 
     * @param searchPage
     *            to get the focus out.
     * @param index
     *            of the first asset to select.
     * @param index
     *            of the last asset to select.
     * @return Integer number of selected assets.
     */
    public int selectAssetsUsingShiftKey(SearchPage searchPage, int first, int last) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAssetsUsingShiftKey method");

        int numberOfSelected = 0;
        searchPage.getHeader().getFocusOnLogo();
        List<WebElement> listofAssets = this.getElementsByXPath(LIST_ASSETS);
        action.keyDown(Keys.LEFT_SHIFT).perform();
        searchPage.waitForDownloadButtonReady();

        if (first >= 0 && first < assetsPreviews.size() && last >= 0 && last < assetsPreviews.size()) {
            ((AssetPreviewThumbsViewPage) assetsPreviews.get(first)).selectAssets(listofAssets.get(first));
            ((AssetPreviewThumbsViewPage) assetsPreviews.get(last)).selectAssets(listofAssets.get(last));
            searchPage.getHeader().getFocusOnLogo();
            numberOfSelected = Math.abs(first - last) + 1;
        }

        action.keyUp(Keys.LEFT_SHIFT).perform();
        assertTrue("The download button should be shown.", searchPage.isDownloadButtonShown());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAssetsUsingShiftKey method");

        return numberOfSelected;
    }

    /**
     * Method to select a range of assets from/to given index, using Shift key.
     * 
     * @param collectionPage
     *            to get the focus out.
     * @param index
     *            of the first asset to select.
     * @param index
     *            of the last asset to select.
     * @return Integer number of selected assets.
     */
    public int selectAssetsUsingShiftKey(CollectionPage collectionPage, int first, int last) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAssetsUsingShiftKey method");

        int numberOfSelected = 0;
        this.waitForByXPath(LIST_ASSETS);
        this.retryAndGetElementsByXPath(LIST_ASSETS);
        List<WebElement> listofAssets = this.getElementsByXPath(LIST_ASSETS);
        collectionPage.getHeader().getFocusOnLogo();
        action.keyDown(Keys.LEFT_SHIFT).perform();

        if (first >= 0 && first < assetsPreviews.size() && last >= 0 && last < assetsPreviews.size()) {
            ((AssetPreviewThumbsViewPage) assetsPreviews.get(first)).selectAssets(listofAssets.get(first));
            ((AssetPreviewThumbsViewPage) assetsPreviews.get(last)).selectAssets(listofAssets.get(last));
            collectionPage.getHeader().getFocusOnLogo();
            numberOfSelected = Math.abs(first - last) + 1;
        }

        action.keyUp(Keys.LEFT_SHIFT).perform();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAssetsUsingShiftKey method");

        return numberOfSelected;
    }

    /**
     * @return a random index of an asset shown.
     */
    public synchronized int getRandomIndexOfAssetsShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getRandomIndexOfAssetsShown method");

        this.expandSortOptionsInSearchPage();

        if (this.driver
                .findElement(By
                        .xpath("//div[@class='btn-group mbpc-switch_views_group_selector']/label/input[@id='list']//parent::label"))
                .getAttribute("class").contains("active")) {

            this.thumbsView = false;
            this.initializeList();

        }

        // If a random number between (the size assetsPreviews -1) & 0.
        int index = (int) (Math.random() * (assetsPreviews.size() - 1) + 0);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getRandomIndexOfAssetsShown method");

        return index;
    }

    /**
     * Method to navigate to the SingleDownload modal of the given asset.
     * 
     * @param index
     *            of the asset to take the SingleDownload modal.
     * @return SingleDownload modal ready to work with.
     */
    public SingleDownloadPage goToSingleDownloadOfTheAsset(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start goToSingleDownloadOfTheAsset method");

        SingleDownloadPage singleDownload = assetsPreviews.get(index).goToSingleDownloadModal();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToSingleDownloadOfTheAsset method");

        return singleDownload;
    }

    /**
     * Method to navigate to the AssetDetails modal of the given asset.
     * 
     * @param index
     *            of the asset to take the AssetDetails modal.
     * @return AssetDetails modal ready to work with.
     */
    public synchronized AssetDetailsPage goToAssetDetails(int index, AssetType assetType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToAssetDetails method");

        AssetDetailsPage assetDetails = assetsPreviews.get(index).goToAssetDetails(assetType);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToAssetDetails method");

        return assetDetails;
    }

    /**
     * Method to get index of AssetDetails with AssetId.
     * 
     * @param assetid
     * @return index
     */
    public synchronized int getIndexOfAssetID(String assetid) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToAssetDetails method");

        int indexOfAsset = 0;
        List<String> assetID = this.getList(LIST_ASSETS);

        for (String asst : assetID) {
            if (asst.equalsIgnoreCase(assetid)) {
                indexOfAsset = assetID.indexOf(asst);
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToAssetDetails method");

        return indexOfAsset;
    }

    /**
     * Method to navigate to the AssetDetails modal of the given asset.
     * 
     * @param index
     *            of the asset to take the AssetDetails modal.
     * @return AssetDetails modal ready to work with.
     */
    public synchronized String getAssetID(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getAssetID method");

        String assetDetails = assetsPreviews.get(index).getAssetId(index);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getAssetID method");

        return assetDetails;
    }

    /**
     * Method to navigate to the AssetDetails modal of the given asset.
     * 
     * @param index
     *            of the asset to take the AssetDetails modal.
     * @return AssetDetails modal ready to work with.
     */
    public synchronized AssetDetailsPage openAssetWithAssetID(String assetID) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToAssetDetails method");

        List<String> assetIDS = this.getList(LIST_ASSETS);

        int indexOfAsset = 0;

        for (String astID : assetIDS) {

            if (astID.equalsIgnoreCase(assetID)) {

                break;

            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToAssetDetails method");
        return null;

    }

    /**
     * @return list of assets IDs of every asset shown.
     */
    public List<String> getAssetIDsOfAssetsShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getAssetIDsOfAssetsShown method");

        if (assetsPreviews == null) {
            this.initializeList();
        }

        List<String> assetsIDs = new ArrayList<String>();
        // For every assetPreview we get its assetID.
        for (AssetPreviewPage assetPreview : assetsPreviews) {
            assetsIDs.add(assetPreview.getAssetId(assetsPreviews.lastIndexOf(assetPreview)));
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getAssetIDsOfAssetsShown method");

        return assetsIDs;
    }

    /**
     * Method to give back the asset IDs of the given asset.
     * 
     * @param index
     *            of the asset position
     * @return asset IDs of the given asset.
     */
    public String getAssetIDsOfAsset(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getAssetIDsOfAsset method");

        if (assetsPreviews == null) {
            this.initializeList();
        }

        String assetsIDs = assetsPreviews.get(index).getAssetId(index);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getAssetIDsOfAsset method");

        return assetsIDs;
    }

    /**
     * Method to unselect the assets shown, using Ctrl Key.
     * 
     * @param collectionPage
     *            to get the focus out.
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     */
    public void unselectAllSelectedAssetsUsingCtrlKey(CollectionPage collectionPage) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start unselectAllSelectedAssetsUsingCtrlKey method");

        /*
         * action.keyDown(Keys.LEFT_CONTROL).perform();
         * 
         * for (int index = 0; index < assetsPreviews.size(); index++) {
         * ((AssetPreviewThumbsViewPage)
         * assetsPreviews.get(index)).unselectAsset();
         * collectionPage.getHeader().getFocusOnLogo();
         * collectionPage.setActionAreaOpen(true); }
         * 
         * action.keyUp(Keys.LEFT_CONTROL).perform();
         */
        collectionPage.getActionArea().clickOnSelectUnselectAll();

        collectionPage.getActionArea().clickOnSelectUnselectAll();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End unselectAllSelectedAssetsUsingCtrlKey method");

    }

    /**
       * Method to select randomly the assets shown, using Ctrl Key for selecting assets in collections.
       * @param searchPage to get the focus out.
       * @return Integer number of selected assets.
       * @modified by Sowjanya Lankadasu <slankada@opentext.com>
       */
    public Integer selectRandomAssetsUsingCtrlKeyInCollections(CollectionPage collectionPage) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectRandomAssetsUsingCtrlKeyInCollections method");

        int numberOfSelected = 0;
        boolean selected = false;

        action.keyDown(Keys.LEFT_CONTROL).perform();

        do {
            numberOfSelected = 0;
            // selected = false;
            for (int index = 0; index < assetsPreviews.size(); index++) {
                if ((int) (Math.random() * 2 + 1) == 1) { // If a random number between 1 & 2 is equal to 1
                    ((AssetPreviewThumbsViewPage) assetsPreviews.get(index)).selectAsset(index);
                    collectionPage.getHeader().getFocusOnLogo();
                    numberOfSelected++;
                    selected = true;
                }
            }
        } while (!selected);

        action.keyUp(Keys.LEFT_CONTROL).perform();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectRandomAssetsUsingCtrlKeyInCollections method");

        log.info("Then number of assets selected are : ---------------" + numberOfSelected);
        return numberOfSelected;
    }

    /**
     * Method to select randomly the assets shown, using Ctrl Key.
     * 
     * @param searchPage
     *            to get the focus out.
     * @return asset IDS
     */
    public List getAssetIDSForDownload(String downloadType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectRandomAssetsUsingCtrlKey method");

        List assetIDs = new ArrayList<int[]>();

        action.keyDown(Keys.LEFT_CONTROL).perform();
        List<WebElement> listofAssets = this.getElementsByXPath(LIST_ASSETS);

        SearchPage searchPage = new SearchPage(driver);
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();

        for (int index = 0; index < assetsPreviews.size(); index++) {
            if ((int) (Math.random() * 2 + 1) == 1) { // If a random number
                                                      // between 1 & 2 is
                                                      // equal to 1
                ((AssetPreviewThumbsViewPage) assetsPreviews.get(index)).selectAssets(listofAssets.get(index));
                searchPage.getHeader().getFocusOnLogo();
                // String assetID = assetsPreviews.get(index).getAssetId(index).toString();
                String assetID = "\"" + assetsPreviews.get(index).getAssetId(index).toString() + "\"";

                assetIDs.add(assetID);

                if (downloadType.equalsIgnoreCase("single")) {
                    break;

                }
            }
        }

        action.keyUp(Keys.LEFT_CONTROL).perform();
        assertTrue("The download button should be shown.", searchPage.isDownloadButtonShown());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectRandomAssetsUsingCtrlKey method");

        return assetIDs;
    }

    /**
     * Method to charge more assets using Scroll.
     */
    public void scrollToDown() {

        for (int i = 0; i <= 10000; i++) {

            if (!this.isElementVisibleByXPath(ITEMS_LEFT, 5)) {

                break;

            }

            this.scrollToChargeMoreAssets();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End scrollToDown method");
    }

    /**
     * @return list of assets IDs of every asset shown.
     */
    public List<String> getAllAssetIDsOfAssetsShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getAllAssetIDsOfAssetsShown method");

        List<String> assetsIDs = this.getListForAttribute(LIST_ASSETIDS, "data-id");

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getAllAssetIDsOfAssetsShown method");

        return assetsIDs;
    }

    /**
     * @return list of assets IDs of every asset shown.
     */
    public List<String> getAssetIDsOfSelectedAsset() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getAllAssetIDsOfAssetsShown method");

        List<String> assetsIDs = this.getListForAttribute(LIST_ASSETIDS, "data-id");

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getAllAssetIDsOfAssetsShown method");

        return assetsIDs;
    }

}
