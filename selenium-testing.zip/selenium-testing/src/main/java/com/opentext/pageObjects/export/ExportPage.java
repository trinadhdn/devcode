/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.export;

import static org.testng.AssertJUnit.assertTrue;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Export page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class ExportPage extends PCBasePage {

	/**
	 * Logger class initialization.
	 */
	static Logger log = Logger.getLogger(ExportPage.class);

	/**
	 * Items keys selectors.
	 */
	private final static String X_BUTTON = "xButton";
	private final static String TITLE = "title";

	private final static String ICONS = "icons";
	private final static String NAMES = "names";
	private final static String METADATAS = "metadatas";
	private final static String CSV_BUTTONS = "csvButtons";
	private final static String PDF_BUTTONS = "pdfButtons";

	/**
	 * Constructor method
	 * 
	 * @param driver
	 *            selenium webdriver
	 */
	public ExportPage(EmergyaWebDriver driver) {
		super(driver);
		this.isReady();
	}

	/**
	 * @return boolean about this PO is ready
	 */
	@Override
	public boolean isReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

		boolean isReady = false;
		for (int i = 0; i <= 5; i++) {
			if (this.isElementVisibleByXPath(X_BUTTON) && this.isElementVisibleByXPath(TITLE)
					&& this.isElementVisibleByXPath(ICONS) && this.isElementVisibleByXPath(NAMES)
					&& this.isElementVisibleByXPath(METADATAS) && this.isElementVisibleByXPath(CSV_BUTTONS)
					&& this.isElementVisibleByXPath(PDF_BUTTONS)) {
				isReady = true;
				break;
			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

		return isReady;
	}

	/**
	 * This method will wait until this PO is ready
	 */
	@Override
	public void waitForReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

		this.waitForByXPath(X_BUTTON);
		this.waitForByXPath(TITLE);
		this.waitForByXPath(ICONS);
		this.waitForByXPath(NAMES);
		this.waitForByXPath(METADATAS);
		this.waitForByXPath(CSV_BUTTONS);
		this.waitForByXPath(PDF_BUTTONS);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
	}

	/**
	 * Method to click on the X button, to close this modal.
	 */
	public void close() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start close method");

		WebElement xButton = this.getElementByXPath(X_BUTTON);
		if (!xButton.isDisplayed()) {
			this.scrollTo(xButton);
		}
		xButton.click();
		this.waitUntilDisappearWebElement(xButton);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End close method");
	}

	/**
	 * Method to export all assets of the collection to CSV.
	 * 
	 * @param index
	 *            of the template to use for exporting.
	 */
	public void clickOnCSVButton(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnCSVButton method");

		// There is not necessary check for templates because is checked in
		// isReady() method.
		this.waitUntilElementVisibileByXPath(CSV_BUTTONS);
		this.getElementsByXPath(CSV_BUTTONS).get(index).click();
		this.driver.sleep(1);
		this.waitUntilDisappearByXPath(SPINNER);

		assertTrue("Ok button of the modal is not ready.", this.isOkOfModalShown());
		this.clickOnOkOfModal();
		this.driver.sleep(10);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnCSVButton method");
	}

	/**
	 * Method to export all assets of the collection to PDF.
	 * 
	 * @param index
	 *            of the template to use for exporting.
	 */
	public void clickOnPDFButton(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnPDFButton method");

		// There is not necessary check for templates because is checked in
		// isReady() method.
		this.waitUntilElementVisibileByXPath(PDF_BUTTONS);
		this.getElementsByXPath(PDF_BUTTONS).get(index).click();
		this.driver.sleep(1);
		this.waitUntilDisappearByXPath(SPINNER);

		assertTrue("Ok button of the modal is not ready.", this.isOkOfModalShown());
		this.clickOnOkOfModal();

		this.driver.sleep(15);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnPDFButton method");
	}

}
