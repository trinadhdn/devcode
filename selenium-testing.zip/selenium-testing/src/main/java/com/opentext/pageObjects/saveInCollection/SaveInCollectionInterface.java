/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.saveInCollection;

public interface SaveInCollectionInterface {

    /**
     * Method to open the panel of the SaveInCollection component.
     */
    public void open();

    /**
     * Method to close the panel of the SaveInCollection component.
     */
    public void close();

    /**
     * Method to add the assets to a new collection:
     * @param title of the new collection.
     * @param type of the new collection.
     */
    public void addToNewCollection(String title, String type);

    /**
     * Method to add the assets to a created collection:
     * @param title of the created collection.
     */
    public void addToExistingCollection(String name);

}
