/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.subsectionTabs.specifics;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.SectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.SubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the General subsections tabs.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class GeneralSubsectionsTabsPage extends SubsectionsTabsPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(GeneralSubsectionsTabsPage.class);

    /**
     * Components
     */
    // Not necessary.

    /**
     * Items keys selectors.
     */
    private static String LIBRARY = "library";
    private static String MEDIABIN = "mediabin";
    private static String EMAIL = "email";
    private static String CLOUD = "cloud";
    private static String SCHEDULED = "scheduled";
    private static String CHECK = "check";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of visible {@link SectionPage}.
     */
    public GeneralSubsectionsTabsPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = true;

        if (this.isKeyShown(LIBRARY)) {
            if (!this.isElementVisibleByXPath(LIBRARY, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(MEDIABIN)) {
            if (!this.isElementVisibleByXPath(MEDIABIN, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(EMAIL)) {
            if (!this.isElementVisibleByXPath(EMAIL, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(CLOUD)) {
            if (!this.isElementVisibleByXPath(CLOUD, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(SCHEDULED)) {
            if (!this.isElementVisibleByXPath(SCHEDULED, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(CHECK)) {
            if (!this.isElementVisibleByXPath(CHECK, 1)) {
                isReady = false;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        if (this.isKeyShown(LIBRARY)) {
            this.waitForByXPath(LIBRARY);
        }
        if (this.isKeyShown(MEDIABIN)) {
            this.waitForByXPath(MEDIABIN);
        }
        if (this.isKeyShown(EMAIL)) {
            this.waitForByXPath(EMAIL);
        }
        if (this.isKeyShown(CLOUD)) {
            this.waitForByXPath(CLOUD);
        }
        if (this.isKeyShown(SCHEDULED)) {
            this.waitForByXPath(SCHEDULED);
        }
        if (this.isKeyShown(CHECK)) {
            this.waitForByXPath(CHECK);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

}
