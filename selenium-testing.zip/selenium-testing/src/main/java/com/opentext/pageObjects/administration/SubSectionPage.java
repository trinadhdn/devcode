/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the commons methods to interact with the Subsections page.
 *
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public abstract class SubSectionPage extends SectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(SubSectionPage.class);

    /**
     * Components
     */
    // Not necessary.

    /**
     * Items keys selectors.
     */
    // Not necessary.

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public SubSectionPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        // this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = super.isReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

}
