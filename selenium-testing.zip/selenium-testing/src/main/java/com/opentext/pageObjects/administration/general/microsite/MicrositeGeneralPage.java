/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText Technologies.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.general.microsite;

import java.awt.AWTException;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.MicrositeSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Microsite subsections.
 * 
 * @author MavyaPapishetty <mpapishe@opentext.com>
 */
public class MicrositeGeneralPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(MicrositeGeneralPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private static final String BACK_BUTTON = "backButton";

    private static final String ADD_MICROSITE = "addMicrosite";
    private static final String SEARCH_INPUT = "searchInput";

    private static final String MICROSITE_NAME = "micrositeName";
    private static final String MICROSITE_NAMES_LIST = "micrositeNameList";
    private static final String FRIENDLYURL = "friendlyURL";
    private static final String FRIENDLY_URL_LIST = "friendlyURLList";
    private static final String OWNER = "owner";
    private static final String OWNERS_LIST = "ownerList";
    private static final String STATUS = "status";
    private static final String STATUS_LIST = "statusList";

    private static final String EDIT_BUTTONS = "editButtons";
    private static final String CLONE_BUTTONS = "clonebuttons";
    private static final String DELETE_BUTTONS = "deleteButtons";
    DELETE_BUTTONS.
    
    
    

    private static final String LINKS_TAB = "linksTab";
    private static final String BANNERS_TAB = "bannersTab";
    private static final String TESTUSERS_TAB = "testUsersTab";

    private static final String MODAL_OK = "deleteButton";
    private static final String CANCEL_BUTTON = "cancelButton";
    private static final String CONFIRMATION_dELETE_MICROSITE = "confirmationForDeleteMicrosite";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     * @author mpapishe
     */
    public MicrositeGeneralPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new MicrositeSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     * @author mpapishe
     */
    @Override
    public boolean isReady() {

    	Character.toString(DELETE_BUTTONS.charAt(0)).matches("[A-Za-z]");
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(MICROSITE_NAME)) {
            if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                    && this.isElementVisibleByXPath(ADD_MICROSITE) && this.isElementVisibleByXPath(SEARCH_INPUT)
                    && this.isElementVisibleByXPath(MICROSITE_NAME) && this.isElementVisibleByXPath(FRIENDLYURL)
                    && this.isElementVisibleByXPath(OWNER) && this.isElementVisibleByXPath(STATUS)
                    && this.isElementVisibleByXPath(EDIT_BUTTONS) && this.isElementVisibleByXPath(CLONE_BUTTONS)
                    && this.isElementVisibleByXPath(LINKS_TAB) && this.isElementVisibleByXPath(BANNERS_TAB)
                    && this.isElementVisibleByXPath(DELETE_BUTTONS) && this.isElementVisibleByXPath(TESTUSERS_TAB)) {
                isReady = true;
            }
        } else {
            if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                    && this.isElementVisibleByXPath(ADD_MICROSITE) && this.isElementVisibleByXPath(SEARCH_INPUT)
                    && this.isElementVisibleByXPath(LINKS_TAB) && this.isElementVisibleByXPath(BANNERS_TAB)
                    && this.isElementVisibleByXPath(TESTUSERS_TAB)) {
                isReady = true;
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     * @author mpapishe
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(ADD_MICROSITE);
        this.waitForByXPath(SEARCH_INPUT);

        this.waitForByXPath(MICROSITE_NAME);
        this.waitForByXPath(FRIENDLYURL);
        this.waitForByXPath(OWNER);
        this.waitForByXPath(STATUS);
        this.waitForByXPath(EDIT_BUTTONS);
        this.waitForByXPath(CLONE_BUTTONS);
        this.waitForByXPath(DELETE_BUTTONS);
        this.waitForByXPath(LINKS_TAB);
        this.waitForByXPath(BANNERS_TAB);
        this.waitForByXPath(TESTUSERS_TAB);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate to the Create MicroSite page.
     * @return {@link CreateAndEditMicrositeGeneralPage} ready to work with.
     * @author mpapishe
     */
    public CreateAndEditMicrositeGeneralPage goToAddMicrosite() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToAddMicrosite method");

        this.getElementByXPath(ADD_MICROSITE).click();
        this.waitUntilDisappearByXPath(ADD_MICROSITE);
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(1);

        CreateAndEditMicrositeGeneralPage createMicroSitePage = new CreateAndEditMicrositeGeneralPage(driver,
                this.getSectionsVisible());
        createMicroSitePage.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToAddMicrosite method");

        return createMicroSitePage;
    }

    /**
     * Method to navigate back to the Dashboard
     * @return {@link DashboardPage} ready to work with.
     * @author mpapishe
     */
    @Override
    public DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(BACK_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");

        return dashboard;
    }

    /**
     * Method to check library List has newly created Microsite.
     * @return boolean about if Microsite created successfully or not.
     * @author mpapishe
    */
    public boolean isNewlyCreatedMicrositeNameShownInList(String micrositeName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isNewlyCreatedMicrositeNameShownInList method");

        boolean isShown = false;
        List<WebElement> micrositeNameList = this.getElementsByXPath(MICROSITE_NAMES_LIST);
        for (WebElement micrositenames : micrositeNameList) {
            if (micrositenames.getText().equalsIgnoreCase(micrositeName)) {
                isShown = true;
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isNewlyCreatedMicrositeNameShownInList method");

        return isShown;

    }

    /**
     * Accesing the Newly created Public Microsite as guest user
     * @param micrositeName
     * @author mpapishe
     */
    public String accessPublicMicroSite(String micrositeName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start accessPublicSite method");

        Map<String, String> mp = new HashMap<String, String>();
        List<WebElement> key = this.getElementsByXPath(MICROSITE_NAMES_LIST);
        List<WebElement> value = this.getElementsByXPath(FRIENDLY_URL_LIST);
        Iterator<WebElement> keyIterator = key.iterator();
        Iterator<WebElement> valueIterator = value.iterator();
        while (keyIterator.hasNext()) {
            mp.put(keyIterator.next().getText(), valueIterator.next().getText());
        }
        Actions keyAction = new Actions(driver);
        keyAction.moveToElement(driver.findElement(By.tagName("html")));
        keyAction.click(driver.findElement(By.tagName("html")));
        keyAction.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).sendKeys("n").keyUp(Keys.CONTROL).keyUp(Keys.SHIFT).build()
                .perform();
        Set<String> win = this.driver.getWindowHandles();
        String defaultWindow = this.driver.getWindowHandle();
        Iterator<String> winIterator = win.iterator();
        while (winIterator.hasNext()) {
            String temp = winIterator.next();

            if (!(temp.equals(defaultWindow)))
                driver.switchTo().window(temp);
        }
        driver.get(mp.get(micrositeName));

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End accessPublicSite  method");

        return defaultWindow;
    }

    /**
     * Method to get the URL for the created Microsite
     * @param micrositeName
     * @return Friendly URL
     * @author mpapishe 
     */

    public String getMicrositeURL(String micrositeName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start gettingMicrositeURL method");

        Map<String, String> mp = new HashMap<String, String>();

        List<WebElement> key = this.getElementsByXPath(MICROSITE_NAMES_LIST);
        List<WebElement> value = this.getElementsByXPath(FRIENDLY_URL_LIST);
        Iterator<WebElement> keyIterator = key.iterator();
        Iterator<WebElement> valueIterator = value.iterator();

        while (keyIterator.hasNext()) {
            mp.put(keyIterator.next().getText(), valueIterator.next().getText());
        }
        String friendlyURL = mp.get(micrositeName);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End accessPublicSite  method");

        return friendlyURL;
    }

    /**
     * Method to handle the window using the WindowHandler
     * @return Defaultwindow when handling the windows using window handler
     * @throws AWTException
     * @author mpapishe
     */
    public String handlingNewWindow() throws AWTException {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start gettingMicrositeURL method");

        Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
        String browserName = cap.getBrowserName().toLowerCase();
        System.out.println(browserName);

        if (browserName.equalsIgnoreCase("chrome")) {

            driver.pressKey(KeyEvent.VK_CONTROL, 1);
            driver.pressKey(KeyEvent.VK_SHIFT, 1);
            driver.pressKey(KeyEvent.VK_N, 1);
            driver.pressReleaseKey(KeyEvent.VK_CONTROL);
            driver.pressReleaseKey(KeyEvent.VK_SHIFT);

            this.driver.sleep(2);
        } else {
            driver.pressKey(KeyEvent.VK_CONTROL, 1);
            driver.pressKey(KeyEvent.VK_SHIFT, 1);
            driver.pressKey(KeyEvent.VK_P, 1);
            driver.pressReleaseKey(KeyEvent.VK_CONTROL);
            driver.pressReleaseKey(KeyEvent.VK_SHIFT);
        }

        Set<String> win = this.driver.getWindowHandles();
        String defaultWindow = this.driver.getWindowHandle();
        Iterator<String> winIterator = win.iterator();
        while (winIterator.hasNext()) {
            String temp = winIterator.next();

            if (!(temp.equals(defaultWindow)))
                driver.switchTo().window(temp);
        }

        this.driver.sleep(2);
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End handlingNewWindow  method");

        return defaultWindow;

    }

    /**
     * Method to switch to the Microsite
     * @param friendlyURL
     * @author mpapishe
     */

    public void switchingToNewMicrosite(String friendlyURL) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start switchingToNewMicrosite method");

        driver.get(friendlyURL);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End switchingToNewMicrosite  method");
    }

    /**
     * Method to Close the Microsite
     * @author mpapishe
     */
    public void closingMicrosite() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start closingMicrosite method");

        driver.close();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End closingMicrosite  method");
    }

    /**
     * Method to Switch to Default window.
     * @param defaultWindow.
     * @author mpapishe.
     */

    public void switchingToDefaultwindow(String defaultWindow) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start closingMicrosite method");

        driver.switchTo().window(defaultWindow);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End closingMicrosite  method");
    }

    /**
     * Method to Delete the microsite.
     * @param micrositeName.
     * @author mpapishe.
    */
    public void deleteMicrosite(String micrositeName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start delete Microsite method");

        List<String> micrositeslist = this.getList(MICROSITE_NAMES_LIST);

        for (String microsite : micrositeslist) {

            if (microsite.equalsIgnoreCase(micrositeName)) {
                this.getElementsByXPath(DELETE_BUTTONS).get(micrositeslist.indexOf(microsite)).click();
                this.driver.sleep(2);
                this.getElementByXPath(MODAL_OK).click();
                this.waitUntilDisappearByXPath(SPINNER);
                break;
            }

        }
        this.driver.sleep(3);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End delete Microsite method");

    }

    /**
     * Method to clone the Microsite
     * @param micrositeName
     * @author mpapishe
     */

    public void cloneMicrosite(String micrositeName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start Clone Microsite method");

        List<String> micrositeslist = this.getList(MICROSITE_NAMES_LIST);

        for (String microsite : micrositeslist) {

            if (microsite.equalsIgnoreCase(micrositeName)) {

                this.getElementsByXPath(CLONE_BUTTONS).get(micrositeslist.indexOf(microsite)).click();
                this.driver.sleep(2);
                this.getElementByXPath(MODAL_OK).click();
                this.driver.sleep(3);
                break;
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clone Microsite method");

    }

    /**
     * Method to Edit the microsite.
     * @author mpapishe
    */
    public void editMicrosite(String micrositeName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start Edit Microsite method");

        List<String> micrositeslist = this.getList(MICROSITE_NAMES_LIST);
        for (String microsite : micrositeslist) {

            if (microsite.equalsIgnoreCase(micrositeName)) {
                this.getElementsByXPath(EDIT_BUTTONS).get(micrositeslist.indexOf(microsite)).click();
                break;
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End Edit Microsite method");

    }

    /**
     * Method to Delete All microsites.
     * @author mpapishe
    */
    public void deleteAllMicrosite() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteAllMicrosite method");

        List<WebElement> micrositeslist = this.getElementsByXPath(MICROSITE_NAMES_LIST);

        for (WebElement microsites : micrositeslist) {
            int i = micrositeslist.indexOf(microsites);
            if (i >= 1) {
                i = 0;
            }
            this.getElementsByXPath(DELETE_BUTTONS).get(i).click();
            this.driver.sleep(2);
            this.getElementByXPath(MODAL_OK).click();
            this.driver.sleep(3);

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteAllMicrosite method");

    }

    /**
     * Verify if microsite is deleted
     * @param micrositeName
     * @return boolean value to check if microsite is deleted
     * @author mpapishe
     */
    public boolean isMicroSiteDeleted(String micrositeName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isMicrsoSiteDeleted method");

        boolean isShown = true;
        List<WebElement> micrositeNameList = this.getElementsByXPath(MICROSITE_NAMES_LIST);
        for (WebElement micrositenames : micrositeNameList) {

            if (micrositenames.getText().equalsIgnoreCase(micrositeName)) {
                isShown = false;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isMicrsoSiteDeleted method");

        return isShown;

    }

    /**
     * Getting the status of microsite 
     * @param micrositeName
     * @return microsite status if it is Enabled,Expired or Deleted
     * @author mpapishe
     */
    public String getMicrositeStatus(String micrositeName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getMicrositeStatus method");

        Map<String, String> mp = new HashMap<String, String>();
        List<WebElement> key = this.getElementsByXPath(MICROSITE_NAMES_LIST);
        List<WebElement> value = this.getElementsByXPath(STATUS_LIST);
        Iterator<WebElement> keyIterator = key.iterator();
        Iterator<WebElement> valueIterator = value.iterator();
        while (keyIterator.hasNext()) {

            mp.put(keyIterator.next().getText(), valueIterator.next().getText());

        }

        String micrositeStatus = mp.get(micrositeName);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getMicrositeStatus  method");

        return micrositeStatus;

    }

    /**
     * Method to get the browser URL
     * @return Browser URL 
     * @author mpapishe
     */

    public String getBrowserURL() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getBrowserURL method");

        String URL = driver.getCurrentUrl();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getBrowserURL  method");

        return URL;
    }

}
