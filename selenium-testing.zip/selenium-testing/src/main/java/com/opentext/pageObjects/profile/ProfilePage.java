/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.profile;

import static org.testng.AssertJUnit.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.footer.FooterPage;
import com.opentext.pageObjects.header.HeaderPage;
import com.opentext.pageObjects.profile.components.UploadPage;
import com.opentext.pageObjects.search.SearchPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Login page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class ProfilePage extends PCBasePage {

	/**
	 * Logger class initialization.
	 */
	static Logger log = Logger.getLogger(ProfilePage.class);

	/**
	 * Components
	 */
	private static HeaderPage header;
	private static FooterPage footer;

	/**
	 * Items keys selectors.
	 */
	private final static String BACK_BTN = "backToSearchButton";

	private final static String PHOTO = "photo";
	private final static String CHANGE_IMAGE_BTN = "changeImageButton";
	private final static String DELETE_IMAGE_BTN = "deleteImageButton";

	private final static String NAME_TAG = "nameTag";
	private final static String NAME = "name";
	private final static String EMAIL_TAG = "emailTag";
	private final static String EMAIL = "email";

	private final static String ROLE_TAG = "roleTag";
	private final static String NONE_ROLE_TEXT = "noneRoleText";
	private final static String ROLES = "roles";

	private final static String OK_BTN_MODAL = "okModalButton";

	/**
	 * Constructor method
	 * 
	 * @param driver
	 *            selenium webdriver
	 */
	public ProfilePage(EmergyaWebDriver driver) {
		super(driver);
		header = new HeaderPage(driver);
		footer = new FooterPage(driver);
		this.isReady();
	}

	/**
	 * @return boolean about this PO is ready
	 */
	@Override
	public synchronized boolean isReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

		boolean isReady = false;
		if (header.isReady() && footer.isReady() && this.isElementVisibleByXPath(BACK_BTN)
				&& this.isElementVisibleByXPath(PHOTO) && this.isElementVisibleByXPath(CHANGE_IMAGE_BTN)
				&& this.isElementVisibleByXPath(DELETE_IMAGE_BTN) && this.isElementVisibleByXPath(NAME_TAG)
				&& this.isElementVisibleByXPath(NAME) && this.isElementVisibleByXPath(EMAIL_TAG)
				&& this.isElementVisibleByXPath(EMAIL) && this.isElementVisibleByXPath(ROLE_TAG)) {
			isReady = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

		return isReady;
	}

	/**
	 * This method will wait until this PO is ready
	 */
	@Override
	public synchronized void waitForReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

		header.waitForReady();
		footer.waitForReady();
		this.waitForByXPath(BACK_BTN);
		this.waitForByXPath(PHOTO);
		this.waitForByXPath(CHANGE_IMAGE_BTN);
		this.waitForByXPath(DELETE_IMAGE_BTN);
		this.waitForByXPath(NAME_TAG);
		this.waitForByXPath(NAME);
		this.waitForByXPath(EMAIL_TAG);
		this.waitForByXPath(EMAIL);
		this.waitForByXPath(ROLE_TAG);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
	}

	/**
	 * Method to click in the Back button, to go back to search page.
	 * 
	 * @return Search page ready to work with.
	 */
	public synchronized SearchPage clickOnBackButton() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnBackButton method");

		this.getElementByXPath(BACK_BTN).click();
		this.driver.sleep(1);

		SearchPage searchPage = new SearchPage(driver);
		searchPage.waitForReady();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnBackButton method");

		return searchPage;
	}

	/**
	 * Method to click on the Change image button, to go to upload modal.
	 * 
	 * @return Upload page ready to work with.
	 */
	public synchronized UploadPage clickOnChangeButton() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnChangeButton method");

		this.getElementByXPath(CHANGE_IMAGE_BTN).click();
		this.driver.sleep(1);

		UploadPage uploadPage = new UploadPage(driver);
		uploadPage.waitForReady();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnChangeButton method");

		return uploadPage;
	}

	/**
	 * Method to click on the Delete image button, to delete the current profile
	 * picture.
	 */
	public synchronized void clickOnDeleteButton() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnDeleteButton method");

		this.getElementByXPath(DELETE_IMAGE_BTN).click();
		this.driver.sleep(1);

		// Info modal appears
		this.waitForByXPath(OK_BTN_MODAL);
		this.getElementByXPath(OK_BTN_MODAL).click();
		this.waitUntilDisappearByXPath(OK_BTN_MODAL);
		this.driver.sleep(1);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnDeleteButton method");
	}

	/**
	 * @return Src field of the profile image.
	 */
	public String getImageSrc() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getImageSrc method");

		String src = this.getElementByXPath(PHOTO).getAttribute("src").trim();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getImageSrc method");

		return src;
	}

	/**
	 * Method to obtain the roles of the logged user.
	 * 
	 * @return the roles of the logged user.
	 */
	public synchronized List<String> getRoles() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getRoles method");

		assertTrue("Dashboard page is not ready.", this.isElementVisibleByXPath(ROLES));
		List<String> roleNames = new ArrayList<>();

		if (this.retryAndGetElementsByXPath(ROLES)) {
			List<String> roles = this.getList(ROLES);
			for (String role : roles) {
				roleNames.add(role);
			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getRoles method");

		return roleNames;
	}

}
