/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.metadata.metadataList;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.MetadataSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class MetadataConfiguration extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(MetadataConfiguration.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String REFRESH_PROPERTY_FILE_BUTTON = "refreshPropertyFileButton";
    private final static String MAPPING_TAB = "mappingTab";
    private final static String METADATA_LIST_TAB = "metadataListTab";
    private final static String REFRESH_META_BUTTON = "refreshMetaDataButton";
    private final static String INDEX_FILEDS = "indexFields";
    private final static String REPOSITORY = "repository";
    private final static String LABELS = "lables";

    private final static String BACK_BUTTON = "backbutton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public MetadataConfiguration(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new MetadataSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;

        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(MAPPING_TAB) && this.isElementVisibleByXPath(METADATA_LIST_TAB)
                && this.isElementVisibleByXPath(REFRESH_PROPERTY_FILE_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * @return boolean about this PO is ready
     */
    public boolean isMetadataListReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;

        if (this.isElementVisibleByXPath(BACK_BUTTON) && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(METADATA_LIST_TAB)
                && this.isElementVisibleByXPath(REFRESH_META_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(MAPPING_TAB);
        this.waitForByXPath(METADATA_LIST_TAB);

        this.waitForByXPath(REFRESH_PROPERTY_FILE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * This method will wait until this Role PO is ready
     */
    public void waitForMetadataTabReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForRoleEditPageReady method");

        this.waitForByXPath(BACK_BUTTON);
        this.waitForByXPath(REFRESH_META_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForRoleEditPageReady method");
    }

    /**
     * Method to navigate back to dashboard
     * @return dashboard
     */

    public  DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new  DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to RefreshPropertyFile
    */
    public void clickOnRefreshPropertyFile() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnsaveRole method");

        this.getElementByXPath(REFRESH_PROPERTY_FILE_BUTTON).click();
        this.waitForReady();
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnsaveRole method");

    }

    /**
     * Method to uncheck admin Roles Permissions.
    */
    public void clickOnRefreshMetaData() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start uncheckAdminRole method");

        this.getElementByXPath(REFRESH_META_BUTTON).click();
        this.waitForReady();
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End uncheckAdminRole method");

    }

    /**
     * Method to clickOnMappingsTab
    */
    public void clickOnMappingsTab() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnsaveRole method");

        this.getElementByXPath(MAPPING_TAB).click();
        this.waitForReady();
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnsaveRole method");

    }

    /**
     * Method to clickOnMappingsTab
    */
    public void clickOnMetaDataListTab() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnsaveRole method");

        this.getElementByXPath(METADATA_LIST_TAB).click();
        this.waitForMetadataTabReady();
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnsaveRole method");
    }

    /**
     * Method to getMetaDataList
    */
    public List<String> getMetaDataList() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnsaveRole method");

        List<String> list = this.getList(INDEX_FILEDS);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnsaveRole method");
        return list;
    }

    /**
     * Method to Compare list
    */
    public boolean checkMetaDataListBeforeAndAfterRefresh(List<String> list1, List<String> list2) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnsaveRole method");

        boolean isListEqual = false;

        for (String parentloop : list1) {

            for (String child : list2) {

                if (parentloop.contains(child)) {
                    isListEqual = true;
                    break;
                }

            }
            if (isListEqual == false) {
                break;
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnsaveRole method");
        return isListEqual;
    }

}
