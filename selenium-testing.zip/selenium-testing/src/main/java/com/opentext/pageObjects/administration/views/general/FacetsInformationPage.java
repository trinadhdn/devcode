/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.views.general;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;

import com.opentext.dto.Section;
import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.general.library.LibraryServersPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.ViewsSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka
 */
public class FacetsInformationPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(FacetsInformationPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String BACK_BUTTON = "backButton";

    private final static String INFORMATION_DISPLAY_SETTINGS = "informationDislaySettings";
    private final static String TITLE_ATTRIBUTE_SEARCH_RESULTS = "titleAttributeFortheSearchResults";

    private final static String PARAMETRIC_FILTERS_AVAILABLE_OPTIONS = "parametricFiltersAvailableOptions";
    private final static String PARAMETRIC_FILTERS_SELECTED_OPTIONS = "parametricFiltersSelectedOptions";
    private final static String PARAMETRIC_FILTERS_SELECTED_OPTIONS_LIST = "parametricFiltersSelectedOptionsList";
    private final static String SELECT_OPTIONS_FOR_PARAMETRIC_FILTERS = "selectButtonForParametricFilters";
    private final static String DESELECT_OPTIONS_FOR_PARAMETRIC_FILTERS = "deSelectButtonForParametricFilters";

    private final static String ASSET_THUMBNAIL_DISPLAYED_ON_HOVER_AVAILABLE_OPTIONS = "assetThumbnailDisplayedOnHoverAvailableOptions";
    private final static String ASSET_THUMBNAIL_DISPLAYED_ON_HOVER_AVAILABLE_OPTIONS_LIST = "assetThumbnailDisplayedOnHoverAvailableOptionsList";
    private final static String ASSET_THUMBNAIL_DISPLAYED_ON_HOVER_SELECTED_OPTIONS = "assetThumbnailDisplayedOnHoverSelectedOptions";
    private final static String ASSET_THUMBNAIL_DISPLAYED_ON_HOVER_SELECTED_OPTIONS_LIST = "assetThumbnailDisplayedOnHoverSelectedOptionsList";
    private final static String SELECT_OPTIONS_FOR_DISPLAYED_ON_HOVER = "selectButtonForAssetThumbnailDisplayed";
    private final static String DESELECT_OPTIONS_FOR_DISPLAYED_ON_HOVER = "deSelectButtonForAssetThumbnailDisplayed";

    private final static String ASSET_LIST_DISPLAYED_IN_TABLE_AVAILABLE_OPTIONS = "assetListDisplayedInTableColumnsAvailableOptions";
    private final static String ASSET_LIST_DISPLAYED_IN_TABLE_AVAILABLE_OPTIONS_LIST = "assetListDisplayedInTableColumnsAvailableOptionsList";
    private final static String ASSET_LIST_DISPLAYED_IN_TABLE_SELECTED_OPTIONS = "assetListDisplayedInTableColumnsSelectedOptions";
    private final static String ASSET_LIST_DISPLAYED_IN_TABLE_SELECTED_OPTIONS_LIST = "assetListDisplayedInTableColumnsSelectedOptionsList";
    private final static String SELECT_OPTIONS_ASSET_LIST_DISPLAYED_IN_TABLE = "selectButtonForAssetAssetListDisplayedInTableColumns";
    private final static String DESELECT_OPTIONS_ASSET_LIST_DISPLAYED_IN_TABLE = "deSelectButtonForAssetAssetListDisplayedInTableColumns";

    private final static String TITLE_SEARCH_RESULTS_AVAILABLE_OPTIONS = "titleSearchResultsAvailableOptions";
    private final static String TITLE_SEARCH_RESULTS_SELECTED_OPTIONS = "titleSearchResultsSelectedOptions";
    private final static String TITLE_SEARCH_RESULTS_AVAILABLE_OPTIONS_LIST = "titleSearchResultsAvailableOptionsList";
    private final static String TITLE_SEARCH_RESULTS_SELECTED_OPTIONS_LIST = "titleSearchResultsSelectedOptionsList";
    private final static String SELECT_OPTIONS_TITLE_SEARCH_RESULTS = "selectButtonForTitleSearchResults";
    private final static String DESELECT_OPTIONS_TITLE_SEARCH_RESULTS = "deSelectButtonForTitleSearchResults";

    private final static String TITLE_ATTRIBUTE_FOR_DOWNLOADS_AVAILABLE_OPTIONS = "titleAttributeForDownloadsAvailableOptions";
    private final static String TITLE_ATTRIBUTE_FOR_DOWNLOADS_SELECTED_OPTIONS = "titleAttributeForDownloadsSelectedOptions";
    private final static String TITLE_ATTRIBUTE_FOR_DOWNLOADS_AVAILABLE_OPTIONS_LIST = "titleAttributeForDownloadsAvailableOptionsList";
    private final static String TITLE_ATTRIBUTE_FOR_DOWNLOADS_SELECTED_OPTIONS_LIST = "titleAttributeForDownloadsSelectedOptionsList";
    private final static String SELECT_OPTIONS_TITLE_ATTRIBUTE_FOR_DOWNLOADS = "selectButtonForDownloads";
    private final static String DESELECT_OPTIONS_TITLE_ATTRIBUTE_FOR_DOWNLOADS = "deSelectButtonForDownloads";

    private final static String SAVE_BUTTON = "saveButton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public FacetsInformationPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new ViewsSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 5; i++) {

            if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                    && this.isElementVisibleByXPath(INFORMATION_DISPLAY_SETTINGS)
                    && this.isElementVisibleByXPath(TITLE_ATTRIBUTE_SEARCH_RESULTS)
                    && this.isElementVisibleByXPath(PARAMETRIC_FILTERS_AVAILABLE_OPTIONS)
                    && this.isElementVisibleByXPath(SAVE_BUTTON)) {
                isReady = true;
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * @return boolean about this PO is ready
     */
    public boolean isReadyAfterExpandAll() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(INFORMATION_DISPLAY_SETTINGS)
                && this.isElementVisibleByXPath(TITLE_ATTRIBUTE_SEARCH_RESULTS)
                && this.isElementVisibleByXPath(PARAMETRIC_FILTERS_AVAILABLE_OPTIONS)
                && this.isElementVisibleByXPath(ASSET_THUMBNAIL_DISPLAYED_ON_HOVER_SELECTED_OPTIONS)
                && this.isElementVisibleByXPath(SELECT_OPTIONS_FOR_DISPLAYED_ON_HOVER)
                && this.isElementVisibleByXPath(ASSET_LIST_DISPLAYED_IN_TABLE_AVAILABLE_OPTIONS)
                && this.isElementVisibleByXPath(ASSET_LIST_DISPLAYED_IN_TABLE_SELECTED_OPTIONS)
                && this.isElementVisibleByXPath(TITLE_SEARCH_RESULTS_AVAILABLE_OPTIONS)
                && this.isElementVisibleByXPath(TITLE_SEARCH_RESULTS_SELECTED_OPTIONS)
                && this.isElementVisibleByXPath(TITLE_ATTRIBUTE_FOR_DOWNLOADS_AVAILABLE_OPTIONS)
                && this.isElementVisibleByXPath(TITLE_ATTRIBUTE_FOR_DOWNLOADS_SELECTED_OPTIONS)
                && this.isElementVisibleByXPath(SAVE_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(INFORMATION_DISPLAY_SETTINGS);
        this.waitForByXPath(TITLE_ATTRIBUTE_SEARCH_RESULTS);

        this.waitForByXPath(PARAMETRIC_FILTERS_AVAILABLE_OPTIONS);
        this.waitForByXPath(PARAMETRIC_FILTERS_SELECTED_OPTIONS);

        this.waitForByXPath(SAVE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the View General page.
     * @return {@link ViewGeneralPage} ready to work with.
     */
    @Override
    public  DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new  DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to Select options for PARAMETRIC_FILTERS.
     */
    public void selectAllOptionsForParametricFilters() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectParametricFilters method");

        Select se = new Select(this.getElementByXPath(PARAMETRIC_FILTERS_AVAILABLE_OPTIONS));

        if (!(se.getOptions().size() == 0)) {
            for (int i = 0; i < se.getOptions().size(); i++) {

                this.getElementByXPath(PARAMETRIC_FILTERS_AVAILABLE_OPTIONS).sendKeys(Keys.CONTROL);

                se.selectByIndex(i);
            }

            this.getElementByXPath(SELECT_OPTIONS_FOR_PARAMETRIC_FILTERS).click();

            this.waitUntilDisappearByXPath(SPINNER);

            log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToAddServer method");
        }
    }

    /**
     * Method to get options from Selected PARAMETRIC_FILTERS.
     */
    public List<String> getListOfParametricSelectedFilters() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getListOfParametricSelectedFilters method");

        List<String> parametricList = this.getList(PARAMETRIC_FILTERS_SELECTED_OPTIONS_LIST);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getListOfParametricSelectedFilters method");
        return parametricList;
    }

    /**
     * Method to Select options for TitleAttributes
     */
    public void selectAllOptionsForTitleAttributes() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectParametricFilters method");

        Select se = new Select(this.getElementByXPath(TITLE_SEARCH_RESULTS_AVAILABLE_OPTIONS));

        if (!(se.getOptions().size() == 0)) {
            for (int i = 0; i < se.getOptions().size(); i++) {
                this.getElementByXPath(TITLE_SEARCH_RESULTS_AVAILABLE_OPTIONS).sendKeys(Keys.CONTROL);
                se.selectByIndex(i);
            }

            this.getElementByXPath(SELECT_OPTIONS_TITLE_SEARCH_RESULTS).click();
            this.waitUntilDisappearByXPath(SPINNER);
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToAddServer method");

    }

    /**
     * Method to get Options list from selected TitleAttributes.
     */
    public List<String> getListOfTitleAttributes() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getListOfTitleAttributes method");

        List<String> list = this.getList(TITLE_SEARCH_RESULTS_SELECTED_OPTIONS_LIST);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getListOfTitleAttributes method");
        return list;
    }

    /**
     * Method to Select options for TitleAttributesForDownloads
     */
    public void selectAllOptionsForTitleAttributesForDownloads() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectParametricFilters method");

        Select se = new Select(this.getElementByXPath(TITLE_ATTRIBUTE_FOR_DOWNLOADS_AVAILABLE_OPTIONS));

        if (!(se.getOptions().size() == 0)) {
            for (int i = 0; i < se.getOptions().size(); i++) {

                this.getElementByXPath(TITLE_ATTRIBUTE_FOR_DOWNLOADS_AVAILABLE_OPTIONS).sendKeys(Keys.CONTROL);

                se.selectByIndex(i);
            }

            this.getElementByXPath(SELECT_OPTIONS_TITLE_ATTRIBUTE_FOR_DOWNLOADS).click();

            this.waitUntilDisappearByXPath(SPINNER);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToAddServer method");

    }

    /**
     * Method to get Options list from selected in TitleAttributesForDownloads
     */
    public List<String> getListOfTitleAttributesForDownloads() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getListOfTitleAttributes method");

        List<String> list = this.getList(TITLE_ATTRIBUTE_FOR_DOWNLOADS_SELECTED_OPTIONS_LIST);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getListOfTitleAttributes method");
        return list;
    }

    /**
     * Method to Select options for Thumbnails .
     */
    public List<String> getListToBeselectedInAssetThumbnailsInformationDisplayedOnHover() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getListToBeselectedInAssetThumbnailsInformationDisplayedOnHover method");

        List<String> lists = new ArrayList<>();

        lists.add("Asset Type");
        lists.add("Name");

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getListToBeselectedInAssetThumbnailsInformationDisplayedOnHover method");
        return lists;

    }

    /**
     * Method to Select options for Thumbnails .
     */
    public void selectOptionsForAssetThumbnailsInformationDisplayedOnHover() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectOptionsForAssetThumbnailsInformationDisplayedOnHover method");

        this.deselectAllOptions(ASSET_THUMBNAIL_DISPLAYED_ON_HOVER_SELECTED_OPTIONS, DESELECT_OPTIONS_FOR_DISPLAYED_ON_HOVER);
        Select se = new Select(this.getElementByXPath(ASSET_THUMBNAIL_DISPLAYED_ON_HOVER_AVAILABLE_OPTIONS));
        se.deselectAll();
        List<String> lists = this.getListToBeselectedInAssetThumbnailsInformationDisplayedOnHover();

        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, ASSET_THUMBNAIL_DISPLAYED_ON_HOVER_AVAILABLE_OPTIONS, ASSET_THUMBNAIL_DISPLAYED_ON_HOVER_AVAILABLE_OPTIONS_LIST, SELECT_OPTIONS_FOR_DISPLAYED_ON_HOVER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectOptionsForAssetThumbnailsInformationDisplayedOnHover method");

    }

    /**
     * Method to get selected LIST of Asset Thumbnails Information Displayed OnHover
     */
    public List<String> getSelectedListOfAssetThumbnailsInformationDisplayedOnHover() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getSelectedListAssetThumbnailsInformationDisplayedOnHover method");

        List<String> list = this.getList(ASSET_THUMBNAIL_DISPLAYED_ON_HOVER_SELECTED_OPTIONS_LIST);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getSelectedListAssetThumbnailsInformationDisplayedOnHover method");
        return list;
    }

    /**
     * Method to pass the list to be Selected in AssetListInformationDisplayed .
     */
    public List<String> getListToBeselectedInAssetListInformationDisplayedOnTable() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start listToBeselectedInAssetListInformationDisplayedOnTable method");

        List<String> lists = new ArrayList<>();

        lists.add("Asset Type");
        lists.add("Name");
        lists.add("IDOL Summary");

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End listToBeselectedInAssetListInformationDisplayedOnTable method");
        return lists;

    }

    /**
     * Method to Select options for AssetListInformationDisplayed .
     */
    public void selectOptionsForAssetListInformationDisplayedOnTable() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectOptionsForAssetListInformationDisplayed method");

        this.deselectAllOptions(ASSET_LIST_DISPLAYED_IN_TABLE_SELECTED_OPTIONS, DESELECT_OPTIONS_ASSET_LIST_DISPLAYED_IN_TABLE);
        Select se = new Select(this.getElementByXPath(ASSET_LIST_DISPLAYED_IN_TABLE_AVAILABLE_OPTIONS));
        se.deselectAll();
        List<String> lists = this.getListToBeselectedInAssetListInformationDisplayedOnTable();

        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, ASSET_LIST_DISPLAYED_IN_TABLE_AVAILABLE_OPTIONS, ASSET_LIST_DISPLAYED_IN_TABLE_AVAILABLE_OPTIONS_LIST, SELECT_OPTIONS_ASSET_LIST_DISPLAYED_IN_TABLE);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectOptionsForAssetListInformationDisplayed method");

    }

    /**
     * Method to get selected LIST of AssetListInformationDisplayed
     */
    public List<String> getSelectedListAssetListInformationDisplayed() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getSelectedListAssetListInformationDisplayed method");

        List<String> list = this.getList(ASSET_LIST_DISPLAYED_IN_TABLE_SELECTED_OPTIONS_LIST);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getSelectedListAssetListInformationDisplayed method");
        return list;
    }

    /**
     * Method to expand all sections in page
     */
    public void expandAllSections() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start expandAllSections method");

        this.getElementByXPath(INFORMATION_DISPLAY_SETTINGS).click();
        this.driver.sleep(2);
        this.getElementByXPath(TITLE_ATTRIBUTE_SEARCH_RESULTS).click();
        this.driver.sleep(2);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End expandAllSections method");

    }

    /**
     * Method to save the new/edited server.
     */
    public void clickOnSave() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        this.getElementByXPath(SAVE_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);

        this.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSave method");

    }

    /**
     * Method to Select options for TitleAttributesForDownloads
     */
    public void deselectAllOptions(String slectedOptionsxpath, String deslectButtonXpath) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deselectAllOptions method");

        Select se = new Select(this.getElementByXPath(slectedOptionsxpath));

        if (!(se.getOptions().size() == 0)) {
            for (int i = 0; i < se.getOptions().size(); i++) {

                this.getElementByXPath(slectedOptionsxpath).sendKeys(Keys.CONTROL);

                se.selectByIndex(i);
            }

            this.getElementByXPath(deslectButtonXpath).click();

            this.waitUntilDisappearByXPath(SPINNER);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deselectAllOptions method");

    }

}
