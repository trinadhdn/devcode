/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.containerCollections;

import static org.testng.AssertJUnit.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.collection.CollectionPage;
import com.opentext.pageObjects.collectionListArea.CollectionListAreaPage;
import com.opentext.pageObjects.containerCollections.collectionPreview.CollectionPreviewPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Container of assets.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class ContainerCollectionsPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(ContainerCollectionsPage.class);

    /**
     * Components
     */
    private List<CollectionPreviewPage> collectionsPreviews;
    // private boolean myCollectionsView;
    private boolean isExpandedAll;
    private int counterCollections;

    /**
     * Items keys selectors.
     */
    private final static String EXPANDALL_BUTTON = "expandAllButton";
    private final static String EXPANDALL_BUTTON_EXPANDED = "expandAllExpanded";

    private final static String EXPAND_TYPE = "expandType";
    private final static String COUNTER_BY_TYPE = "counterByType";

    private final static String COLLECTIONS = "collections";
    private final static String COLLECTIONS_SELECTED = "collectionsSelected";
    private final static String NOTFOUND_TEXT = "notFoundText";

    /**
     * Constructor method.
     * 
     * @param driver
     *            selenium webdriver.
     * @param number
     *            of assets given by collection button counter of the header.
     */
    public ContainerCollectionsPage(EmergyaWebDriver driver, int counterCollections) {
        super(driver);

        this.counterCollections = counterCollections;
        // this.myCollectionsView = false;
        this.isExpandedAll = this.isExpandedAllButtonExpanded();
        this.initializeList();

        this.isReady();
    }

    /**
     * Method to initialize the list.
     */
    private synchronized void initializeList() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start initializeList method");

        this.waitUntilDisappearByXPath(SPINNER);
        if (counterCollections > 0 && this.isExpandedAll) {
            collectionsPreviews = new ArrayList<CollectionPreviewPage>();
            for (int i = 0; i < this.getNumberOfCollectionsShown(); i++) {
                collectionsPreviews.add(new CollectionPreviewPage(driver, i));
            }
        } else {
            collectionsPreviews = null;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End initializeList method");
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int j = 0; j <= 5; j++) {

            if (this.isElementVisibleByXPath(EXPANDALL_BUTTON)) {
                isReady = true;
                if (counterCollections > 0) {
                    if (this.isElementVisibleByXPath(EXPAND_TYPE) && this.isElementVisibleByXPath(COUNTER_BY_TYPE)) {
                        isReady = true;

                        if (this.isExpandedAll) {
                            for (int i = 0; isReady && i < collectionsPreviews.size(); i++) {
                                if (!collectionsPreviews.get(i).isReady()) {
                                    isReady = false;
                                }
                            }
                        }
                    } else {
                        isReady = false;
                    }
                } else {
                    if (this.isElementVisibleByXPath(NOTFOUND_TEXT)) {
                        isReady = true;
                    } else {
                        isReady = false;
                    }
                }
            }
            if (isReady) {
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(EXPANDALL_BUTTON);
        if (counterCollections > 0) {
            this.waitForByXPath(EXPAND_TYPE);
            this.waitForByXPath(COUNTER_BY_TYPE);
            if (this.isExpandedAll) {
                for (int i = 0; i < collectionsPreviews.size(); i++) {
                    collectionsPreviews.get(i).waitForReady();
                }
            }
        } else { // Wait for NOTFOUND_TEXT if there are not collections.
            this.waitForByXPath(NOTFOUND_TEXT);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @param isExpandedAll
     *            value.
     */
    public void setExpandedAll(boolean isExpandedAll) {
        this.isExpandedAll = isExpandedAll;
    }

    /**
     * @return true if the collection types areas are open, false if they are
     *         collapsed.
     */
    private synchronized boolean isExpandedAllButtonExpanded() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isExpandedAll method");

        boolean isOpen = true;
        try {
            // class = expand: this complement is collapsed yet
            if (this.getElementByXPath(EXPANDALL_BUTTON).getAttribute("class").contains("expand")) {
                isOpen = false;
            }
        } catch (Exception e) {
            isOpen = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isExpandedAll method");

        return isOpen;
    }

    /**
     * Method to perform a click on 'Expand/collapse all' button to see every
     * collection.
     */
    public synchronized void expandAll() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start expandAll method");

        if (!this.isExpandedAll) {
            this.waitUntilDisappearByXPath(EXPANDALL_BUTTON_EXPANDED);
            this.waitForByXPath(EXPANDALL_BUTTON);
            if (this.retryAndGetElementByXPath(EXPANDALL_BUTTON)) {
                this.waitUntilElementClickableByXPath(EXPANDALL_BUTTON);
                this.getElementByXPath(EXPANDALL_BUTTON).click();
            } else {
                assertTrue("Expand Button is NOT loaded.", false);

            }
            this.isExpandedAll = true;
            this.initializeList();
            this.waitForReady();
        }
        assertTrue("The collection types are not expanded.", this.isExpandedAllButtonExpanded());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End expandAll method");
    }

    /**
     * Method to perform a click on 'Expand/collapse all' button to collapse
     * every collection.
     */
    public synchronized void collapseAll() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start collapseAll method");

        if (this.isExpandedAll) {
            this.getElementByXPath(EXPANDALL_BUTTON).click();
            this.isExpandedAll = false;
            this.waitUntilDisappearByXPath(COLLECTIONS);
            this.initializeList();
        }
        assertTrue("The collection types are not collapsed.", !this.isExpandedAllButtonExpanded());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End collapseAll method");
    }

    /**
     * @return number of collections shown.
     */
    public synchronized int getNumberOfCollectionsShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getNumberOfCollectionsShown method");

        int counterAssetsShown = 0;

        if (!(this.isExpandedAll)) {
            this.expandAll();
        }

        if (this.retryAndGetElementsByXPath(COLLECTIONS)) {

            for (int i = 0; i <= 3; i++) {
                if (this.retryAndGetElementsByXPath(COLLECTIONS)) {
                    if (this.getElementsByXPath(COLLECTIONS).size() != 0) {
                        counterAssetsShown = this.getElementsByXPath(COLLECTIONS).size();
                        break;
                    }
                }
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumberOfCollectionsShown method");

        return counterAssetsShown;
    }

    /**
     * Method to select randomly the collections shown, using Ctrl Key.
     * 
     * @param collectionListAreaPage
     *            to use some methods.
     * @return Integer number of selected collections.
     */
    public synchronized Integer selectRandomCollections(CollectionListAreaPage collectionListAreaPage) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectRandomCollections method");

        if (!this.isExpandedAll) {
            this.expandAll();
        }
        int numberOfSelected = 0;
        boolean selected = false;

        action.keyDown(Keys.LEFT_CONTROL).perform();
        collectionListAreaPage.waitForActionArea();

        do {
            numberOfSelected = 0;
            for (int index = 0; index < collectionsPreviews.size(); index++) {
                if ((int) (Math.random() * 2 + 1) == 1) { // If a random number
                                                          // between 1 & 2 is
                                                          // equal to 1
                    collectionsPreviews.get(index).selectCollection(index);
                    numberOfSelected++;
                    selected = true;
                }
            }
        } while (!selected);

        action.keyUp(Keys.LEFT_CONTROL).perform();
        assertTrue("The buttons of the action area aren't shown.", collectionListAreaPage.isActionAreaShown());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectRandomCollections method");

        return numberOfSelected;
    }

    /**
     * @return the counter of selected collections.
     */
    public synchronized int getCountOfSelected() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCountOfSelected method");

        int count = 0;
        if (this.isElementVisibleByXPath(COLLECTIONS_SELECTED, 5)) {
            count = this.getElementsByXPath(COLLECTIONS_SELECTED).size();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCountOfSelected method");

        return count;
    }

    /**
     * Method to select the collection given.
     * 
     * @param collectionListAreaPage
     *            to use some methods.
     * @param Name
     *            of the collection to select.
     */
    public void selectCollection(CollectionListAreaPage collectionListAreaPage, String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectCollection method");

        if (!this.isExpandedAll) {
            this.expandAll();
        }

        action.keyDown(Keys.LEFT_CONTROL).perform();
        collectionListAreaPage.waitForActionArea();

        // Search for the given collection.
        Integer index = this.getIndexofGivenCollection(name);
        if (index != null) {
            collectionsPreviews.get(index).selectCollection(index);
        }

        action.keyUp(Keys.LEFT_CONTROL).perform();
        assertTrue("The buttons of the action area aren't shown.", collectionListAreaPage.isActionAreaShown());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectCollection method");
    }

    /**
     * This method will search for the index position of the collection, given
     * its name.
     * 
     * @param name
     *            of the collection to search.
     * @return index position of the collection.
     */
    public synchronized Integer getIndexofGivenCollection(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getIndexofGivenCollection method");

        Integer index = 0;
        boolean isFound = false;
        while (index < collectionsPreviews.size() && !isFound) {
            if (collectionsPreviews.get(index).getTitleText(index).equalsIgnoreCase(name)) {
                isFound = true;
                break;
            } else {
                index++;
            }
        }
        if (!isFound) {
            index = null;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getIndexofGivenCollection method");

        return index;
    }

    /**
     * This method will navigate into the given collection
     * 
     * @param name
     *            of the collection to navigate.
     * @return CollectionPage ready to work with.
     */
    public synchronized CollectionPage navigateToCollection(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start navigateToCollection method");

        if (!this.isExpandedAll) {
            this.expandAll();
        }
        // Search for the given collection.
        Integer index = 0;
        for (int i = 0; i <= 3; i++) {
            index = this.getIndexofGivenCollection(name);
            if (index == null) {
                this.sleep20andRefresh();
                this.expandAll();
            } else {
                break;
            }

        }

        CollectionPage collection = null;
        assertTrue("The given collection name - " + name + ", does not exist. Please create one.", index != null);
        if (index != null) {
            collection = collectionsPreviews.get(index).enterCollection(index);
        }
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End navigateToCollection method");

        return collection;
    }

    /**
     * Method to return the src attribute of the cover of the given collection.
     * 
     * @param index
     *            of the collection's position.
     * @return src attribute of the cover of this collection.
     */
    private String getImageSrc(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getImageSrc method");

        if (!this.isExpandedAll) {
            this.expandAll();
        }
        String src = collectionsPreviews.get(index).getImageSrc(index);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getImageSrc method");

        return src;
    }

    /**
     * Method to return the src attribute of the cover of the given collection.
     * 
     * @param name
     *            of the collection.
     * @return src attribute of the cover of this collection.
     */
    public String getImageSrc(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getImageSrc method");

        if (!this.isExpandedAll) {
            this.expandAll();
        }
        String src = this.getImageSrc(this.getIndexofGivenCollection(name));

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getImageSrc method");

        return src;
    }

}
