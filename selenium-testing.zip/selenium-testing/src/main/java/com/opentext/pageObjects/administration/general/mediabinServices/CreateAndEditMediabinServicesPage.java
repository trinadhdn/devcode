/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.general.mediabinServices;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.GeneralSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.ConfigFactory;
import com.opentext.utils.ConfigMB;
import com.opentext.utils.ConfigMB.ConfigMBDetails;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class CreateAndEditMediabinServicesPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(CreateAndEditMediabinServicesPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private static final String MEDIABIN_LOCATION = "mediabinlocation";

    private static final String USERNAME_INPUT = "userNameInput";
    private static final String USERPASS_INPUT = "userPassInput";
    private static final String NON_MEDIABIN_USER = "nonmediabinuser";

    private static final String METADATA_CATEGORY = "metadatacategory";
    private static final String REQUIRED_FIELD_MESSAGE = "requiredFieldMessage";

    private static final String BACK_BUTTON = "backbutton";
    private static final String SAVE_BUTTON = "saveButton";
    private static final String SUSSESSFULLY_SAVED_MESSAGE = "successfullySavedMessage";
    private static final String CHECK_SERVICE = "checkservice";
    private static final String CHECK_SERVICE_MESSAGE = "checkservicemessage";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public CreateAndEditMediabinServicesPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new GeneralSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(MEDIABIN_LOCATION) && this.isElementVisibleByXPath(USERNAME_INPUT)
                && this.isElementVisibleByXPath(USERPASS_INPUT) && this.isElementVisibleByXPath(SAVE_BUTTON)
                && this.isElementVisibleByXPath(CHECK_SERVICE)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(MEDIABIN_LOCATION);
        this.waitForByXPath(METADATA_CATEGORY);

        this.waitForByXPath(USERNAME_INPUT);
        this.waitForByXPath(USERPASS_INPUT);
        this.waitForByXPath(NON_MEDIABIN_USER);

        this.waitForByXPath(SAVE_BUTTON);
        this.waitForByXPath(CHECK_SERVICE);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the MediaBin list page.
     * @return dashboard
     */

    public DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to save the new/edited server.
     * @return {@link MediaBinService} ready to work with or null if the form wasn't completed.
     */
    public CreateAndEditMediabinServicesPage clickOnSave() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        this.getElementByXPath(SAVE_BUTTON).click();
        this.driver.sleep(1);

        CreateAndEditMediabinServicesPage mediabinservice = null;

        if (!this.isElementVisibleByXPath(REQUIRED_FIELD_MESSAGE, 3)) {
            // If no error is shown:
            this.waitUntilDisappearByXPath(SAVE_BUTTON);
            this.waitUntilDisappearByXPath(SPINNER);
            mediabinservice = new CreateAndEditMediabinServicesPage(driver, this.getSectionsVisible());
            mediabinservice.waitForReady();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSave method");

        return mediabinservice;
    }

    /**
     * @return boolean about if required field message is shown or not
     */
    public boolean isRequiredFieldMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isRequiredFieldMessageShown method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(REQUIRED_FIELD_MESSAGE, 3)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRequiredFieldMessageShown method");

        return isReady;
    }

    /**
     * Method to Create new Library service.
    */
    public void fillMediabBinServiceDetails(ConfigMBDetails MBLOCATION, ConfigMBDetails MBUSER,
            ConfigMBDetails MBPASSWORD, ConfigMBDetails MBCATEGORY, ConfigMBDetails NONMBUSER) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start fillMediabBinServiceDetails method");

        // Clear exsting data
        this.clearDeatils();

        // Fill details
        ConfigMB Config = ConfigFactory.getMBServiceConfigDetils(MBLOCATION, MBUSER, MBPASSWORD, MBCATEGORY, NONMBUSER);
        this.getElementByXPath(MEDIABIN_LOCATION).sendKeys(Config.getMBlocation());
        this.getElementByXPath(USERNAME_INPUT).sendKeys(Config.getMBuser());
        this.getElementByXPath(USERPASS_INPUT).sendKeys(Config.getMBPassword());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillLibraryServerDetails method");

    }

    /**
     * Method to clear data .
    */
    public void clearDeatils() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clearDeatils method");

        this.getElementByXPath(MEDIABIN_LOCATION).clear();
        this.getElementByXPath(USERNAME_INPUT).clear();
        this.getElementByXPath(USERPASS_INPUT).clear();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clearDeatils method");

    }

    /**
     * Method to check Successfully created message.
     * @return boolean about if server created successfully or not.
    */
    public boolean isSuccessfullyCreatedMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isSuccessfullyCreatedMessageShown method");

        boolean isShown = false;
        String message = this.getElementByXPath(SUSSESSFULLY_SAVED_MESSAGE).getText();
        if (message.equalsIgnoreCase("Configuration successfully saved.")) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isSuccessfullyCreatedMessageShown method");

        return isShown;

    }

    /**
     * Method to check the service.
     * @return boolean about if service is working fine or not
    */
    public boolean checkService() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkService method");

        boolean checkservice = false;
        this.getElementByXPath(CHECK_SERVICE).click();
        this.driver.sleep(3);
        if (!(this.getElementByXPath(CHECK_SERVICE_MESSAGE).getAttribute("style").contains("display: block;"))) {
            this.getElementByXPath(CHECK_SERVICE).click();
            this.driver.sleep(4);
        }
        String message = this.getElementByXPath(CHECK_SERVICE_MESSAGE).getText();
        if (message.contains("Mediabin is working properly.")) {
            checkservice = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkService method");

        return checkservice;

    }

    /**
     * Method to check the InvalidService service.
     * @return boolean about if service is working fine or not
    */
    public boolean checkInvalidService() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkService method");

        boolean checkInvalidservice = false;
        this.getElementByXPath(CHECK_SERVICE).click();
        this.driver.sleep(3);
        if (!(this.getElementByXPath(CHECK_SERVICE_MESSAGE).getAttribute("style").contains("display: block;"))) {
            this.getElementByXPath(CHECK_SERVICE).click();
            this.driver.sleep(4);
        }
        String message = this.getElementByXPath(CHECK_SERVICE_MESSAGE).getText();
        if (message.equalsIgnoreCase("Mediabin is not working. Please, review your configuration.")) {
            checkInvalidservice = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkService method");

        return checkInvalidservice;

    }
}
