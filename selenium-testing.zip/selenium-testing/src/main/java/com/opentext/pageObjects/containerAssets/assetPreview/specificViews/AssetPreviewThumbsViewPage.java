/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.containerAssets.assetPreview.specificViews;

import static org.testng.AssertJUnit.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.assetDetails.AssetDetailsPage;
import com.opentext.pageObjects.containerAssets.assetPreview.AssetPreviewPage;
import com.opentext.pageObjects.containerAssets.assetPreview.specificViews.overlay.OverlayPage;
import com.opentext.pageObjects.singleDownload.specificModal.SingleDownloadPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.AssetCategoryValues.AssetType;

/**
 * This PO contains the methods to interact with the assets' previews in the
 * Thumbs view.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class AssetPreviewThumbsViewPage extends AssetPreviewPage {

	/**
	 * Logger class initialization.
	 */
	static Logger log = Logger.getLogger(AssetPreviewThumbsViewPage.class);

	/**
	 * Components
	 */
	public static OverlayPage overlay;
	protected volatile boolean isSelected;

	/**
	 * Constructor method
	 * 
	 * @param driver
	 *            selenium webdriver
	 */
	public AssetPreviewThumbsViewPage(EmergyaWebDriver driver, int index) {
		super(driver, index);
		this.isSelected = this.isSelected();
		overlay = null;
		this.isReady();
	}

	/**
	 * @return boolean about this PO is ready
	 */
	@Override
	public synchronized boolean isReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

		boolean isReady = false;
		if (super.isReady()) {
			isReady = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

		return isReady;
	}

	/**
	 * This method will wait until this PO is ready
	 */
	@Override
	public synchronized void waitForReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

		super.waitForReady();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
	}

	/**
	 * Method to move the focus of the virtual mouse to the Asset.
	 * 
	 * @return the Overlay object.
	 */
	public OverlayPage moveMouseOverAsset(boolean toSeeOverlay) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start moveMouseOverAsset method");

		action.moveToElement(this.getImage().get(index)).perform();

		if (toSeeOverlay) {
			overlay = new OverlayPage(driver);
			overlay.waitForReady();
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End moveMouseOverAsset method");

		return overlay;
	}

	/**
	 * @return if this asset is selected or not.
	 */
	private synchronized boolean isSelected() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isSelected method");

		List<WebElement> childs = null;
		boolean isSelected = true;

		// Find Selected class sons of this Panel
		try {
			// childs = this.getImage().findElements(By.xpath(".." +
			// this.getXPath(SELECTED_MARK)));
			childs = this.driver.findElements(By.xpath("//div[contains(@class, 'selected')]"));
		} catch (Exception e) {
			log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - the asset (" + getIndex()
					+ ") is not selected");
		}

		// If this Select button contains that children, then is selected
		if (childs == null || childs.isEmpty()) {
			isSelected = false;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isSelected method");

		return isSelected;
	}

	/**
	 * Method to Select this asset.
	 */
	public void selectAsset(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAsset method");

		// If is not selected -> select
		if (!this.isSelected) {
			this.moveMouseOverAsset(false);
			action.moveToElement(this.getTitle().get(index)).click().perform();

			this.driver.sleep(3);
			this.isSelected = true;
			assertTrue("This asset should be selected.", this.isSelected());
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAsset method");
	}

	/**
	 * Method to Select this asset.
	 */
	public void selectAssets(WebElement assetID) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAsset method");

		// If is not selected -> select
		if (!this.isSelected) {
			this.moveMouseOverAsset(false);
			action.moveToElement(assetID).click().perform();
			this.driver.sleep(2);

			this.isSelected = true;
			assertTrue("This asset should be selected.", this.isSelected());
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAsset method");
	}

	/**
	 * Method to navigate to the SingleDownload modal of an asset in Thumbs
	 * view.
	 * 
	 * @return SingleDownload modal ready to work with.
	 */
	@Override
	public SingleDownloadPage goToSingleDownloadModal() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToSingleDownloadModal method");

		if (overlay == null) {
			this.moveMouseOverAsset(true); // Send "true" to initialize the
											// overlay.
		}
		assertTrue("The overlay is not ready.", overlay.isReady());
		SingleDownloadPage singleDownload = overlay.clickOnBlueDownloadButton();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToSingleDownloadModal method");

		return singleDownload;
	}

	/**
	 * Method to navigate to the AssetDetails modal of an asset in Thumbs view.
	 * 
	 * @param The
	 *            category of the asset.
	 * @return AssetDetails modal ready to work with.
	 */
	@Override
	public synchronized AssetDetailsPage goToAssetDetails(AssetType assetType) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToAssetDetails method");

		overlay = null;
		if (overlay == null) {
			this.moveMouseOverAsset(true); // Send "true" to initialize the
											// overlay.
		}
		assertTrue("The overlay is not ready.", overlay.isReady());

		AssetDetailsPage assetDetails = overlay.clickOnTitle(assetType);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToAssetDetails method");

		return assetDetails;
	}

	// /**
	// * Method to Deselect the asset.
	// */
	// public void deselectAsset() {
	// log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " -
	// Start deselectAsset method");
	//
	// // If is selected -> deselect
	// if (this.isSelected()) {
	// this.scrollTo(getSelectButton());
	// this.getSelectButton().click();
	// this.driver.sleep(1);
	// assertTrue("This asset shouldn't be selected.", !this.isSelected());
	// }
	//
	// log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End
	// deselectAsset method");
	// }

}
