/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.sortBy;

import static org.testng.AssertJUnit.assertTrue;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the SortBy component.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class SortByPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(SortByPage.class);

    /**
     * Items keys selectors.
     */
    private final static String CURRENT_SORT = "currentSort"; // Current sort field selected
    private final static String CURRENT_ORDER = "currentOrder"; // Current order selected (Asc/Desc)
    private final static String SORTBY_OPENER = "sortByOpener"; // Drop down opener
    private final static String SORTBY_OPTIONS = "sortByOptions"; // Options

    /**
     * Components
     */
    private volatile boolean isOpen;

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public SortByPage(EmergyaWebDriver driver) {
        super(driver);
        this.isOpen = this.isDropDownOpen();
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        this.waitForReady();

        // this.expandSortOptionsInSearchPage();
        for (int i = 0; i <= 3; i++) {
            if (this.isElementVisibleByXPath(CURRENT_SORT) && this.isElementVisibleByXPath(SORTBY_OPENER)) {
                isReady = true;
                // If the current sort is not Relevance, the current order should be shown.
                if (!getCurrentSort().equalsIgnoreCase("Relevance")) {
                    this.waitUntilDisappearByXPath(SPINNER);
                    if (this.isElementVisibleByXPath(CURRENT_ORDER)) {
                        isReady = true;
                    } else {
                        isReady = false;
                    }
                }
                // If SortBy is opened the options should be shown.
                if (this.isOpen) {
                    if (this.isElementVisibleByXPath(SORTBY_OPTIONS)) {
                        isReady = true;
                        break;
                    } else {
                        isReady = false;
                    }

                }
            }
            if (isReady) {
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(CURRENT_SORT);
        this.waitForByXPath(SORTBY_OPENER);
        // If the current sort is not Relevance, the current order should be waited.
        if (!getCurrentSort().equalsIgnoreCase("Relevance")) {
            this.waitForByXPath(CURRENT_ORDER);
        }
        // If SortBy is opened the options should be waited.
        if (this.isOpen) {
            this.waitForByXPath(SORTBY_OPTIONS);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return Current sort criteria.
     */
    public synchronized String getCurrentSort() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCurrentSort method");

        String currentSort = null;

        if (this.retryAndGetElementByXPath(CURRENT_SORT)) {
            currentSort = this.getElementByXPath(CURRENT_SORT).getText().trim();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCurrentSort method");

        return currentSort;

    }

    /**
     * @return true if the drop-down is open, false if it is collapsed.
     */
    private synchronized boolean isDropDownOpen() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isDropDownOpen method");

        this.expandSortOptionsInSearchPage();
        boolean isOpen = false;
        if (this.retryAndGetElementByXPath(SORTBY_OPENER)) {
            isOpen = this.getElementByXPath(SORTBY_OPENER).getAttribute("class").contains("active");
        } else {
            assertTrue("Sort By Opener is not ready.", false);

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isDropDownOpen method");

        return isOpen;
    }

    /**
     * Method to open the drop-down of the SortBy component.
     */
    public synchronized void open() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start open method");

        this.expandSortOptionsInSearchPage();
        if (!this.isDropDownOpen()) {
            if (this.retryAndGetElementByXPath(SORTBY_OPENER)) {
                this.getElementByXPath(SORTBY_OPENER).click();
                this.isOpen = true;

            }
            this.waitForReady();
        }
        this.driver.sleep(2);
        assertTrue("Sort By component is not ready.", this.isReady());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End open method");
    }

    /**
     * Method to close the drop-down of the SortBy component.
     */
    public synchronized void close() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start close method");

        if (this.isDropDownOpen()) {
            this.getElementByXPath(SORTBY_OPENER).click();
            this.isOpen = false;
            this.waitForReady();
        }
        assertTrue("Sort By component is not ready.", this.isReady());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End close method");
    }

    /**
     * Method to change the SortBy option used.
     * @param index of the SortBy option to select.
     */
    public synchronized void changeSortByOptionSelected(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start changeSortByOptionSelected method");

        // Open SortBy component.
        if (!this.isDropDownOpen()) {
            this.open();
        }
        WebElement sortOption = this.getElementsByXPath(SORTBY_OPTIONS).get(index);
        String sortToSelect = sortOption.getText().trim();
        String orderToSelect = sortOption.getAttribute("data-order").trim();
        // Change SortBy option.
        action.moveToElement(sortOption).click().perform(); // In this special case we can't use: "sortOption.click()"
        this.waitUntilDisappearWebElement(sortOption, 5);
        this.isOpen = false;
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(8);
        // Check the change.
        assertTrue("The current Sort field is not the selected one.", sortToSelect.equalsIgnoreCase(getCurrentSort()));
        assertTrue("The current Order field is not the selected one.", orderToSelect
                .equalsIgnoreCase(getCurrentOrder()));

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End changeSortByOptionSelected method");
    }

    /**
     * @return Current order criteria: asc/desc.
     */
    private synchronized String getCurrentOrder() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCurrentOrder method");

        String currentOrder = this.getElementByXPath(CURRENT_ORDER).getAttribute("class").split(" ")[1].trim();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCurrentOrder method");

        return currentOrder;
    }

    /**
     * @return Number of options in SortBy component.
     */
    public synchronized int getNumberOfOptions() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getNumberOfOptions method");

        // Open SortBy component.
        if (!this.isDropDownOpen()) {
            this.open();
        }
        int numberOfOptions = this.getElementsByXPath(SORTBY_OPTIONS).size();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumberOfOptions method");

        return numberOfOptions;
    }

}
