/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.containerAssets.assetPreview;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.assetDetails.AssetDetailsPage;
import com.opentext.pageObjects.singleDownload.specificModal.SingleDownloadPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.AssetCategoryValues.AssetType;

/**
 * This PO contains the methods to interact with the Commons assets' previews.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public abstract class AssetPreviewPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    Logger log = Logger.getLogger(AssetPreviewPage.class);

    /**
     * Components
     */
    // private int index;

    public volatile int index;

    /**
     * Items keys selectors.
     */
    private static final String IMAGE = "image";
    private static final String TITLE = "title";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public AssetPreviewPage(EmergyaWebDriver driver, int index) {
        super(driver);
        this.index = index;
        // this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        this.waitForReady();
        for (int i = 0; i <= 5; i++) {

            if (this.isElementVisibleByXPath(IMAGE) && this.isElementVisibleByXPath(TITLE)) {
                isReady = true;
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;

    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(IMAGE);
        this.waitForByXPath(TITLE);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return 
     * @return the index of this asset.
     */
    public synchronized int getIndex() {
        return index;
    }

    /**
     * @return Image element in the position index.
     */
    public synchronized List<WebElement> getImage() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getImage method");

        this.waitForByXPath(IMAGE);
        List<WebElement> element = null;
        for (int i = 0; i <= 5; i++) {
            element = this.getElementsByXPath(IMAGE);
            if (element.size() != 0) {
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getImage method");

        return element;

    }

    /**
     * @return Title element in the position index.
     */
    public synchronized List<WebElement> getTitle() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getTitle method");

        this.waitForByXPath(TITLE);
        List<WebElement> element = null;
        for (int i = 0; i <= 5; i++) {
            element = this.getElementsByXPath(TITLE);
            if (element.size() != 0) {
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getTitle method");

        return element;
    }

    /**
     * @return Title text of this collection.
     */
    private String getTitleText(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getTitleText method");

        String title = this.getTitle().get(index).getText().trim();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getTitleText method");

        return title;
    }

    /**
     * Method to navigate to the SingleDownload modal.
     * @return SingleDownload modal ready to work with.
     */
    public abstract SingleDownloadPage goToSingleDownloadModal();

    /**
     * Method to navigate to the AssetDetails modal.
     * @param The category of the asset.
     * @return AssetDetails modal ready to work with.
     */
    public abstract AssetDetailsPage goToAssetDetails(AssetType assetType);

    /**
     * @return Asset ID of this asset preview.
     */
    public String getAssetId(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getAssetId method");

        String assetID = null;
        for (int i = 0; i <= 5; i++) {

            if (this.getImage().size() != 0) {
                assetID = this.getImage().get(index).findElement(By.xpath("./ancestor::div[@data-id]"))
                        .getAttribute("data-id");
                break;
            }

            log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getAssetId method");

        }
        return assetID;

    }

    // /**
    // * Method to enlarge this asset:
    // */
    // public void enlargeAsset() {
    // log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start enlargeAsset method");
    //
    // if (!this.isEnlarged) {
    // // this.moveMouseOverAsset();
    // this.getPanel().click();
    // this.driver.sleep(1);
    // this.waitForByXPath(CLOSE_BUTTON);
    //
    // if (this.getPanel().getAttribute("class").contains("enlarged")) {
    // this.isEnlarged = true;
    // } else {
    // this.isEnlarged = false;
    // }
    // }
    // assertTrue("The asset " + this.getTitle() + "is not enlarged and it should be.", this.isEnlarged);
    //
    // log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End enlargeAsset method");
    // }
    //
    // /**
    // * Method to reduce this asset:
    // */
    // public void reduceAsset() {
    // log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start reduceAsset method");
    //
    // if (this.isEnlarged) {
    // this.getElementByXPath(CLOSE_BUTTON).click();
    // this.driver.sleep(1);
    // this.waitUntilDisappearByXPath(CLOSE_BUTTON);
    //
    // if (this.getPanel().getAttribute("class").contains("enlarged")) {
    // this.isEnlarged = true;
    // } else {
    // this.isEnlarged = false;
    // }
    // }
    // assertTrue("The asset " + this.getTitle() + "is enlarged and it shouldn't be.", !this.isEnlarged);
    //
    // log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End reduceAsset method");
    // }

}
