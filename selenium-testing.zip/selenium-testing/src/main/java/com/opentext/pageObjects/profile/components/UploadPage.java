/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.profile.components;

import java.awt.AWTException;
import java.io.IOException;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.profile.ProfilePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Login page.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class UploadPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(UploadPage.class);

    /**
     * Items keys selectors.
     */
    private final static String PANEL = "panel";

    private final static String UPLOAD_TEXT = "uploadText";
    private final static String BROWSE_BTN = "browseButton";
    private final static String BROWSE_INPUT = "browseInput";

    private final static String CANCEL_BTN = "cancelButton";
    private final static String UPLOAD_BTN = "uploadButton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public UploadPage(EmergyaWebDriver driver) {
        super(driver);
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(PANEL) && this.isElementVisibleByXPath(UPLOAD_TEXT)
                && this.isElementVisibleByXPath(BROWSE_BTN) && this.isElementVisibleByXPath(BROWSE_INPUT)
                && this.isElementVisibleByXPath(CANCEL_BTN) && this.isElementVisibleByXPath(UPLOAD_BTN)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(PANEL);
        this.waitForByXPath(UPLOAD_TEXT);
        this.waitForByXPath(BROWSE_BTN);
        this.waitForByXPath(BROWSE_INPUT);
        this.waitForByXPath(CANCEL_BTN);
        this.waitForByXPath(UPLOAD_BTN);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to click in the Cancel button, to close this modal.
     * @return Profile page ready to work with.
     */
    public ProfilePage clickOnCancelButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnCancelButton method");

        this.getElementByXPath(CANCEL_BTN).click();
        this.waitUntilDisappearByXPath(PANEL);

        ProfilePage profilePage = new ProfilePage(driver);
        profilePage.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnCancelButton method");

        return profilePage;
    }

    /**
     * Method to click in the Upload button, to upload the image.
     * @return Profile page ready to work with.
     */
    private ProfilePage clickOnUploadButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnUploadButton method");

        this.waitUntilElementClickableByXPath(UPLOAD_BTN);
        this.getElementByXPath(UPLOAD_BTN).click();
        this.waitUntilDisappearByXPath(PANEL);

        ProfilePage profilePage = new ProfilePage(driver);
        profilePage.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnUploadButton method");

        return profilePage;
    }

    /**
     * Method to click in the Upload button, to upload the image.
     * @return Profile page ready to work with.
     * @throws AWTException 
     * @throws IOException 
     */
    public ProfilePage uploadImage() throws AWTException, IOException {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start uploadImage method");

        // BROWSE_BTN is the real input camouflaged like a button
        this.getElementByXPath(BROWSE_BTN).click();

        /*// Get and fill file location to upload
        String separate = System.getProperty("file.separator");
        String path = System.getProperty("user.dir") + separate + "src" + separate + "main" + separate + "resources"
                + separate + "files" + separate + "images" + separate + "otmb.png";
        
        Robot robot = new Robot();
        robot.setAutoDelay(2000);
        
        StringSelection selection = new StringSelection(path);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
        
        robot.setAutoDelay(1000);
        
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyRelease(KeyEvent.VK_V);
        
        robot.setAutoDelay(1000);
        
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        */

        this.uploadData("otmb.png");
        // Click on Upload button

        ProfilePage profilePage = this.clickOnUploadButton();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End uploadImage method");

        return profilePage;
    }

}
