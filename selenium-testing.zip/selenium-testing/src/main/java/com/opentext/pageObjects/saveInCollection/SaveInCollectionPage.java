/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.saveInCollection;

import static org.testng.AssertJUnit.assertTrue;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the SaveInCollection component.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class SaveInCollectionPage extends PCBasePage implements SaveInCollectionInterface {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(SaveInCollectionPage.class);

    /**
     * Items keys selectors.
     */
    private final static String SAVE_IN_COLLECTION_BUTTON = "saveInCollectionButton";
    private final static String SAVE_IN_COLLECTION_BUTTON_FOLDER = "saveInCollectionButtonFolder";

    private final static String IN_EXISTING_DROPDOWN = "inExistingDropDown";
    private final static String IN_EXISTING_OPTIONS = "inExistingOptions";

    private final static String CREATE_NEW_INPUT = "createNewInput";
    private final static String CREATE_NEW_BUTTON = "createNewButton";
    private final static String TYPE_COLL_DROPDOWN = "typeCollectionDropDown";
    private final static String TYPE_COLL_OPTIONS = "typeCollectionOptions";

    private final static String TAGS_COLLECTION = "tagCollectionToSaveIn";
    private final static String X_BTN_TAGS_COLLECTION = "xButtonTagCollectionToSaveIn";

    private final static String CANCEL_BUTTON = "cancelButton";
    private final static String OK_BUTTON = "okButton";

    /**
     * Components
     */
    private boolean isOpen;

    /**
     * Constructor method
     * 
     * @param driver
     *            selenium webdriver
     */
    public SaveInCollectionPage(EmergyaWebDriver driver) {
        super(driver);
        this.isOpen = this.isSaveInCollectionOpen();
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 3; i++) {

            if (this.isElementVisibleByXPath(SAVE_IN_COLLECTION_BUTTON)
                    || this.isElementVisibleByXPath(SAVE_IN_COLLECTION_BUTTON_FOLDER)) {
                isReady = true;
                if (this.isOpen) {// If is opened the components should be
                                  // shown.
                    if (this.isElementVisibleByXPath(IN_EXISTING_DROPDOWN)
                            && this.isElementVisibleByXPath(CREATE_NEW_INPUT)
                            && this.isElementVisibleByXPath(CREATE_NEW_BUTTON)
                            && this.isElementVisibleByXPath(TYPE_COLL_DROPDOWN)
                            && this.isElementVisibleByXPath(CANCEL_BUTTON) && this.isElementVisibleByXPath(OK_BUTTON)) {
                        isReady = true;

                    } else {
                        isReady = false;
                    }
                }
            }
            if (isReady) {
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(SAVE_IN_COLLECTION_BUTTON);
        this.waitForByXPath(SAVE_IN_COLLECTION_BUTTON_FOLDER);
        if (this.isOpen) { // If is opened the components should be waited.
            this.waitForByXPath(IN_EXISTING_DROPDOWN);
            this.waitForByXPath(CREATE_NEW_INPUT);
            this.waitForByXPath(CREATE_NEW_BUTTON);
            this.waitForByXPath(TYPE_COLL_DROPDOWN);
            this.waitForByXPath(CANCEL_BUTTON);
            this.waitForByXPath(OK_BUTTON);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return true if the panel is open, false if it is collapsed.
     */
    public synchronized boolean isSaveInCollectionOpen() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isSaveInCollectionOpen method");

        boolean isOpen = false;

        if (this.retryAndGetElementByXPath(SAVE_IN_COLLECTION_BUTTON)) {

            isOpen = this.getElementByXPath(SAVE_IN_COLLECTION_BUTTON).getAttribute("class").contains("active");
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isSaveInCollectionOpen method");

        return isOpen;
    }

    /**
     * @return true if the panel is open, false if it is collapsed in folders page.
     */
    public synchronized boolean isSaveInCollectionOpenInFolders() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isSaveInCollectionOpenInFolders method");

        boolean isFolderOpen;

        if (this.retryAndGetElementByXPath(SAVE_IN_COLLECTION_BUTTON_FOLDER)) {

            isOpen = this.getElementByXPath(SAVE_IN_COLLECTION_BUTTON_FOLDER).getAttribute("class")
                    .contains("collapse");
        }

        if (isOpen == true) {
            isFolderOpen = false;
        } else
            isFolderOpen = true;

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isSaveInCollectionOpenInFolders method");

        return isFolderOpen;
    }

    /**
     * Method to open the panel of the SaveInCollection component.
     */
    public synchronized void open() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start open method");

        if (!this.isSaveInCollectionOpen()) {
            this.getElementByXPath(SAVE_IN_COLLECTION_BUTTON).click();
            this.isOpen = true;
            this.waitForReady();
        }
        assertTrue("SaveInCollection component is not open.", this.isSaveInCollectionOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End open method");
    }

    /**
     * Method to open the panel of the SaveInCollection component in folders page.
     */
    public synchronized void openInFoldersPage() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start openInFoldersPage method");

        if (!this.isSaveInCollectionOpenInFolders()) {
            this.scrollTop();
            this.driver.sleep(2);
            this.getElementByXPath(SAVE_IN_COLLECTION_BUTTON_FOLDER).click();
            this.isOpen = true;
            this.waitForReady();
        }
        assertTrue("SaveInCollection component is not open.", this.isSaveInCollectionOpenInFolders());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End openInFoldersPage method");
    }

    /**
     * Method to close the panel of the SaveInCollection component.
     */
    public synchronized void close() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start close method");

        if (this.isSaveInCollectionOpen()) {
            this.getElementByXPath(SAVE_IN_COLLECTION_BUTTON).click();
            this.isOpen = false;
            this.waitForReady();
        }
        assertTrue("SaveInCollection component is not collapsed.", !this.isSaveInCollectionOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End close method");
    }

    /**
     * Method to add the assets to a new collection:
     * 
     * @param title
     *            of the new collection.
     * @param type
     *            of the new collection.
     */
    public synchronized void addToNewCollection(String title, String type) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addToNewCollection method");

        boolean found = false;
        Select select = new Select(this.getElementByXPath(TYPE_COLL_DROPDOWN));
        select.selectByVisibleText(type);
        /*       System.out.println(select.getOptions().size());
        
        List<WebElement> options = select.getOptions();
        */

        // Select the correct type.
        /*        for (WebElement option : options) {
            System.out.println(option.getText());
            if (option.getText().equals(type)) {
                found = true;
                // option.click();
                // this.scrollTop();
                this.driver.sleep(1);
        
                	// Select the correct type.
                	new Select(this.getElementByXPath(TYPE_COLL_DROPDOWN)).selectByVisibleText(type);
                	this.scrollTop();
                	this.driver.sleep(1);
                
            }
            }*/
        // Type the title of the collection.
        this.retryAndGetElementByXPath(CREATE_NEW_INPUT);
        this.getElementByXPath(CREATE_NEW_INPUT).sendKeys(title);
        this.driver.sleep(2);

        // Add the collection.
        this.retryAndGetElementByXPath(CREATE_NEW_BUTTON);
        this.getElementByXPath(CREATE_NEW_BUTTON).click();
        this.waitForByXPath(TAGS_COLLECTION);
        this.waitForByXPath(X_BTN_TAGS_COLLECTION);
        assertTrue("The titles don't match.", this.getElementByXPath(TAGS_COLLECTION).getText().trim()
                .equalsIgnoreCase(type + ": " + title));

        // Confirm the creation of the new collection and the assets saving in
        // it.
        this.driver.sleep(1);
        this.getElementByXPath(OK_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End addToNewCollection method");

    }

    /**
     * Method to add the assets to a created collection:
     * 
     * @param title
     *            of the created collection.
     */
    public synchronized void addToExistingCollection(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addToCreatedCollection method");

        // Open dropdown of the existing collections.
        this.getElementByXPath(IN_EXISTING_DROPDOWN).click();

        boolean found = false;
        int index = 0;
        // Search for the collection index with the proper name.
        while (!found && index < this.getElementsByXPath(IN_EXISTING_OPTIONS).size()) {
            if (this.getElementsByXPath(IN_EXISTING_OPTIONS).get(index).getAttribute("title").equalsIgnoreCase(name)) {
                // When found, perform a click action on this option.
                found = true;
                WebElement option = this.getElementsByXPath(IN_EXISTING_OPTIONS, 1).get(index);
                if (!option.isDisplayed()) {
                    this.scrollTo(option);
                }
                option.click();
            } else {
                index++;
            }
        }

        // Add the collection.
        this.getElementByXPath(IN_EXISTING_DROPDOWN).click();
        this.driver.sleep(2);
        this.waitForByXPath(TAGS_COLLECTION, 2);
        this.waitForByXPath(X_BTN_TAGS_COLLECTION, 2);
        assertTrue("The titles don't match.", this.getElementByXPath(TAGS_COLLECTION).getText().trim().split(": ")[1]
                .trim().equalsIgnoreCase(name));

        // Confirm the creation of the new collection and the assets saving in
        // it.

        this.getElementByXPath(OK_BUTTON).click();

        this.sleep20andRefresh();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End addToCreatedCollection method");

    }

}
