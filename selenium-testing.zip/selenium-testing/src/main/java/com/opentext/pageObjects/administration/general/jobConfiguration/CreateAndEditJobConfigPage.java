/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.general.jobConfiguration;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.GeneralSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class CreateAndEditJobConfigPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(CreateAndEditJobConfigPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String REFRESH_CONTACT_TIMEOUT = "refreshcontenttimeout";
    private final static String TIMEOUT_FOR_GDRIVE = "timeoutforgdrive";

    private final static String SAVE_BUTTON = "saveButton";
    private final static String SUSSESSFULLY_SAVED_MESSAGE = "successfullySavedMessage";
    private final static String BACK_BUTTON = "backbutton";
    private final static String SCHEDULED_JOBS_TAB = "scheduledjobsTab";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public CreateAndEditJobConfigPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new GeneralSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(REFRESH_CONTACT_TIMEOUT)
                && this.isElementVisibleByXPath(TIMEOUT_FOR_GDRIVE) && this.isElementVisibleByXPath(SAVE_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(REFRESH_CONTACT_TIMEOUT);
        this.waitForByXPath(TIMEOUT_FOR_GDRIVE);
        this.waitForByXPath(SAVE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the Job Config page.
     * @return dashboard
     */

    public  DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new  DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to save the new/edited Job details.
     */
    public void clickOnSave() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        this.getElementByXPath(SAVE_BUTTON).click();
        this.driver.sleep(1);

    }

    /**
     * Method to Create new Library service.
    */
    public void fillJobConfigDetails(String refreshCount, String gdrivetimeout) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillJobConfigDetails method");

        // Clear exsting data
        this.clearDeatils();

        // Fill details
        this.getElementByXPath(REFRESH_CONTACT_TIMEOUT).sendKeys(refreshCount);
        this.getElementByXPath(TIMEOUT_FOR_GDRIVE).sendKeys(gdrivetimeout);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillJobConfigDetails method");

    }

    /**
     * Method to clear data .
    */
    public void clearDeatils() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clearDeatils method");

        this.getElementByXPath(REFRESH_CONTACT_TIMEOUT).clear();
        this.getElementByXPath(TIMEOUT_FOR_GDRIVE).clear();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clearDeatils method");

    }

    /**
     * Method to check Successfully created message.
     * @return boolean about if cloud details SAVED successfully or not.
    */
    public boolean isSuccessfullyCreatedMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isSuccessfullyCreatedMessageShown method");

        boolean isShown = false;
        if (this.getElementByXPath(SUSSESSFULLY_SAVED_MESSAGE).isDisplayed()) {
            String message = this.getElementByXPath(SUSSESSFULLY_SAVED_MESSAGE).getText();
            if (message.equalsIgnoreCase("Configuration successfully saved.")) {
                isShown = true;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isSuccessfullyCreatedMessageShown method");

        return isShown;

    }

    /**
     * Method to check given details are saved
     * @return boolean about if Job details SAVED successfully or not.
    */
    public boolean isGivenJobDetailsSaved(String refreshCount, String gdrivetimeout) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isGivenDetailsSaved method");

        this.getElementByXPath(SCHEDULED_JOBS_TAB).click();
        this.waitForByXPath(REFRESH_CONTACT_TIMEOUT);
        this.waitForByXPath(TIMEOUT_FOR_GDRIVE);

        boolean isShown = false;
        String actualRefreshCount = this.getElementByXPath(REFRESH_CONTACT_TIMEOUT).getAttribute("value");
        String actualgdrivetimeout = this.getElementByXPath(TIMEOUT_FOR_GDRIVE).getAttribute("value");
        System.out.println(actualRefreshCount + "**" + actualgdrivetimeout);

        if (actualRefreshCount.equalsIgnoreCase(refreshCount) && actualgdrivetimeout.equalsIgnoreCase(gdrivetimeout)) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isGivenDetailsSaved method");

        return isShown;

    }

}
