/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.login;

import static org.testng.AssertJUnit.assertTrue;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.search.SearchPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.UserFactory;
import com.opentext.utils.UserTest;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * This PO contains the methods to interact with the Login page.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class LoginPage extends LogInOutAbstractPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(LoginPage.class);

    /**
     * Items keys selectors.
     */
    private final static String TEXT = "text";
    private final static String EMAIL_INPUT = "emaiInput";
    private final static String PASS_INPUT = "passInput";
    private final static String UNSUCCESSFULMSG = "unSuccessfulMsg";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public LoginPage(EmergyaWebDriver driver) {
        super(driver);
        this.isReady();
    }

    public LoginPage(ThreadLocal<EmergyaWebDriver> driver) {
        // TODO Auto-generated constructor stub
        super((EmergyaWebDriver) driver);
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready.
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;

        if (super.isReady() && this.isElementVisibleByXPath(EMAIL_INPUT) && this.isElementVisibleByXPath(PASS_INPUT)) {
            isReady = true;

            // if (isWelcomeMessageShown()) {
            // // Check below elements if the page is Login page
            // if (this.isElementVisibleByXPath(LOGO) && this.isElementVisibleByXPath(EMAIL_INPUT)
            // && this.isElementVisibleByXPath(PASS_INPUT) && this.isElementVisibleByXPath(SIGNIN_BUTTON)) {
            // isReady = true;
            // }
            // } else {
            // // Check below elements if the page is Logout page
            // if (this.isElementVisibleByXPath(LOGO) && this.isElementVisibleByXPath(SIGNIN_BUTTON)) {
            // isReady = true;
            // }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready.
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        this.waitForByXPath(EMAIL_INPUT);
        this.waitForByXPath(PASS_INPUT);

        // if (isInfoMessageShown()) {
        // // If the page is log out page then check for below
        // this.waitForByXPath(LOGO);
        // this.waitForByXPath(SIGNIN_BUTTON);
        // } else {
        // // If the page is login page then check for below
        // this.waitForByXPath(LOGO);
        // this.waitForByXPath(EMAIL_INPUT);
        // this.waitForByXPath(PASS_INPUT);
        // this.waitForByXPath(SIGNIN_BUTTON);
        // }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to perform a Login action:
     * 
     * -# Type the user's email.
     * -# Type the user's password.
     * -# Type Enter key to login.
     * 
     * @param userDomain
     * @param userType
     * @return HomePage
     */
    public synchronized SearchPage login(UserDomain userDomain, UserType userType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start login method");

        UserTest user = UserFactory.getUser(userDomain, userType);

        this.getElementByXPath(EMAIL_INPUT).sendKeys(user.getUsername());
        this.driver.sleep(1);
        this.getElementByXPath(PASS_INPUT).sendKeys(user.getPassword());
        this.driver.sleep(1);

        this.getElementByXPath(SIGNIN_BUTTON).click();

        driver.sleep(3);
        SearchPage searchPage = null;
        // Check if we used a good credentials.

        if ((!userDomain.toString().equals(UserDomain.WRONGCREDENTIALS.toString()))
                && (!userDomain.toString().equals(UserDomain.NON_ADMIN.toString()))) {
            searchPage = new SearchPage(driver);
            searchPage.waitForReady();
        } else if (!userDomain.toString().equals(UserDomain.NON_ADMIN.toString())) {
            // Check the message of wrong login
            this.waitForByXPath(UNSUCCESSFULMSG);
            assertTrue("Error login message is not shown.", this.isInfoMessageShown());

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End login method");

        return searchPage;

    }

    /**
     * @return if the unsuccessful Info message visible.
     */
    public synchronized boolean isInfoMessageShown() {
        boolean shown = false;
        if (this.isElementVisibleByXPath(UNSUCCESSFULMSG)) {
            shown = true;
        }
        return shown;
    }

    /**
     * Method to check whether Welcome message is displayed or not.
     * @return if the Welcome message is visible.
     * @author Sowjanya Lankadasu <slankada@opentext.com>.
     */
    public boolean isWelcomeMessageShown() {
        boolean shown = false;
        if (this.isElementVisibleByXPath(TEXT)) {
            shown = true;
        }

        return shown;
    }

    /**
     * Method to check whether 'signin' button is shown or not
     * @return if the sign in button is visible in Logout page.
     * @author Sowjanya Lankadasu <slankada@opentext.com>.
     */
    public synchronized boolean isSignInShown() {
        boolean shown = false;
        if (this.isElementVisibleByXPath(SIGNIN_BUTTON)) {
            shown = true;
        }

        return shown;
    }

    /**
     * Method to Click on signin button from logout page. 
     * @author Sowjanya Lankadasu <slankada@opentext.com>.
     */
    public synchronized void clickOnSignInButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSignInButton method");

        // wait for signin button to load.
        this.waitForByXPath(SIGNIN_BUTTON);
        assertTrue("Sign In button is not shown.", this.isSignInShown());

        // Click on sign in button if the button is visible.
        this.getElementByXPath(SIGNIN_BUTTON).click();
        this.driver.sleep(1);

        /*       // Wait for home page to load
        this.waitForByXPath(TEXT);
        assertTrue("Error login message is not shown.", this.isWelcomeMessageShown());*/

    }
    // /**
    // * @return Title of the asset by action menu.
    // */
    // public String getTitle() {
    // log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getTitle method");
    //
    // String title = this.getElementByXPath(TITLE).getText();
    //
    // log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getTitle method");
    //
    // return title;
    // }

}
