/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.login.external;

import static org.testng.AssertJUnit.assertTrue;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.createAndEditionCollection.specific.CreateCollectionPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.UserFactory;
import com.opentext.utils.UserTest;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * This PO contains the methods to interact with the Sign in Google page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class GoogleLoginPage extends ExternalLoginPage {

	/**
	 * Logger class initialization.
	 */
	static Logger log = Logger.getLogger(GoogleLoginPage.class);

	/**
	 * Items keys selectors.
	 */
	private static final String EMAIL_INPUT = "emailInput";
	private static final String NEXT_BUTTON = "nextButton";
	private static final String EMAIL_ERROR = "emailError";

	private static final String PASS_INPUT = "passInput";
	private static final String PASS_NEXT = "passNext";
	private static final String PASS_ERROR = "passError";

	protected static final String EMAIL_NOT_FOUND = "Couldn't find your Google Account";
	protected static final String INVALID_EMAIL = "Enter a valid email or phone number";

	/**
	 * Constructor method
	 * 
	 * @param driver
	 *            selenium webdriver
	 */
	public GoogleLoginPage(EmergyaWebDriver driver) {
		super(driver);
	}

	/**
	 * @return boolean about this PO is ready
	 */
	@Override
	public boolean isReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

		boolean isReady = false;
		if (this.isElementVisibleByXPath(EMAIL_INPUT, 1) && this.isElementVisibleByXPath(NEXT_BUTTON, 1)) {
			isReady = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

		return isReady;
	}

	/**
	 * This method will wait until this PO is ready
	 */
	@Override
	public void waitForReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

		this.waitForByXPath(EMAIL_INPUT);
		this.waitForByXPath(NEXT_BUTTON);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
	}

	/**
	 * Method to perform a Sign in action in Google page.
	 * 
	 * @param userType
	 *            to perform the sign in.
	 * @return @see CreateCollectionPage if authorization not needed, @see
	 *         GoogleAuthPage if authorization needed.
	 */
	public PCBasePage gDriveLogin(UserDomain userDomain, UserType userType) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start gDriveLogin method");

		UserTest user = UserFactory.getUser(userDomain, userType);

		// Screen of the email
		log.info(this.getElementByXPath(EMAIL_ERROR).getText());
		this.getElementByXPath(EMAIL_INPUT).sendKeys(user.getUsername());
		this.getElementByXPath(NEXT_BUTTON).click();
		this.driver.sleep(3);
		assertTrue("Email error shouldn't be shown.", !this.isEmailError());
		this.waitForByXPath(PASS_INPUT);
		this.waitForByXPath(PASS_NEXT);

		// Screen of the password
		assertTrue("Password elements should be shown.",
				this.isElementVisibleByXPath(PASS_INPUT, 5) && this.isElementVisibleByXPath(PASS_NEXT, 5));
		this.getElementByXPath(PASS_INPUT).sendKeys(user.getPassword());
		this.getElementByXPath(PASS_NEXT).click();
		this.driver.sleep(5);

		// check if the google authemtication window is closed.
		PCBasePage pagetoReturn = null;
		if (!this.driver.isCurrentWindowOpen()) {

			// if number of windows are decreased.
			this.driver.switchToMainwindow();
			// Switch to create collection page.
			pagetoReturn = new CreateCollectionPage(driver);
			pagetoReturn.waitForReady();
			assertTrue("Create collection page is not ready.", pagetoReturn.isReady());
			// pagetoReturn.getElementByXPath(GDRIVE_PATH).sendKeys(GDRIVE_PATH);
		} else {
			// Check for invalid or incorrect password error message.
			assertTrue("Password should be correct.", !this.isElementVisibleByXPath(PASS_ERROR, 1));
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End gDriveLogin method");

		return pagetoReturn;
	}

	/*
	*//**
		 * @return If the Invalid email error is shown or not.
		 */
	public boolean isEmailError() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isEmailError method");

		boolean isErrorShown = false;
		log.info(this.getElementByXPath(EMAIL_ERROR).getText());
		if (this.getElementByXPath(EMAIL_ERROR).getText().contains(EMAIL_NOT_FOUND)
				| this.getElementByXPath(EMAIL_ERROR).getText().contains("INVALID_EMAIL")) {
			isErrorShown = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isEmailError method");

		return isErrorShown;
	}

}
