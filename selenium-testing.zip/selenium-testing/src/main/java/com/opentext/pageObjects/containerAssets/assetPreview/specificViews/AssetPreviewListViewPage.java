/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.containerAssets.assetPreview.specificViews;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.assetDetails.AssetDetailsPage;
import com.opentext.pageObjects.containerAssets.assetPreview.AssetPreviewPage;
import com.opentext.pageObjects.singleDownload.specificModal.SingleDownloadPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.AssetCategoryValues.AssetType;

/**
 * This PO contains the methods to interact with the assets' previews in the List view.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class AssetPreviewListViewPage extends AssetPreviewPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(AssetPreviewListViewPage.class);

    /**
     * Items keys selectors.
     */
    private final static String DOWNLOAD_BUTTON = "downloadButton";
    private final static String VIEW_BUTTON = "viewButton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public AssetPreviewListViewPage(EmergyaWebDriver driver, int index) {
        super(driver, index);
        // this.isSelected = isSelected;
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 5; i++) {

            if (super.isReady() && exists(getDownloadButton()) && exists(getViewButton())) {
                isReady = true;
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        this.waitForByXPath(DOWNLOAD_BUTTON);
        this.waitForByXPath(VIEW_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return Download button element in the position index.
     */
    public WebElement getDownloadButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getDownloadButton method");

        WebElement element = null;
        if (this.retryAndGetElementsByXPath(DOWNLOAD_BUTTON)) {
            element = this.getElementsByXPath(DOWNLOAD_BUTTON).get(this.getIndex());
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getDownloadButton method");

        return element;
    }

    /**
     * @return View button element in the position index.
     */
    public WebElement getViewButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getViewButton method");

        WebElement element = this.getElementsByXPath(VIEW_BUTTON).get(this.getIndex());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getViewButton method");

        return element;
    }

    /**
     * Method to navigate to the SingleDownload modal of an asset in List view.
     * @return SingleDownload modal ready to work with.
     */
    @Override
    public SingleDownloadPage goToSingleDownloadModal() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToSingleDownloadModal method");

        this.getDownloadButton().click();
        this.waitUntilDisappearByXPath(SPINNER);

        SingleDownloadPage singleDownload = new SingleDownloadPage(driver);
        singleDownload.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToSingleDownloadModal method");

        return singleDownload;
    }

    /**
     * Method to navigate to the AssetDetails modal of an asset in List view.
     * @param The category of the asset.
     * @return AssetDetails modal ready to work with.
     */
    @Override
    public AssetDetailsPage goToAssetDetails(AssetType assetType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToAssetDetails method");

        this.getElementByXPath(VIEW_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);

        AssetDetailsPage assetDetails = new AssetDetailsPage(driver, assetType);
        assetDetails.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToAssetDetails method");

        return assetDetails;
    }

}
