/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.selenium.pageObject.BasePageObject;

/**
 * Page Object interlayer contains the common behavior of the pages in the
 * application.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public abstract class PCBasePage extends BasePageObject {

    // private Logger log = Logger.getLogger(BasePageObject.class);

    /**
     * Items keys selectors.
     */
    public final String TOAST = "toast";
    public final static String SPINNER = "spinner";
    public final String OK_MODAL_BUTTON = "okModalButton";
    public final String GDRIVE_PATH = "PC";
    protected final String COLLECTION_OWNER = "sowjanya";
    protected final String SHARED_USER = "trinadh";

    // Gmail inputs/locators
    protected final static String GMAIL_EMAIL_INPUT = "gmailEmailIDInput";
    protected final static String GMAIL_EMAIL_NEXT_INPUT = "gmailEmailNextButton";
    protected final static String GMAIL_PASSWORD_INPUT = "gmailPasswordIDInput";
    protected final static String GMAIL_PASSWORDL_NEXT_INPUT = "gmailPasswordNextButton";

    protected static final String VALID_GDRIVE_PATH = "drive";
    protected static final String INVALID_GDRIVE_PATH = "Invalid path";
    protected static final String OK_MODAL_TEXT = "okModalText";
    protected static final String HEADER_MOBILE_VIEW = "headerMobileView";
    protected static final String MOBILE_VIEW_MENU = "mobileViewMenu";
    protected static final String ASSET_DETAILS_ACTIONS = "assetDetailsActions";
    protected static final String EXPAND_ASSET_DETAILS_ACTIONS = "expandAssetDetailsActions";

    protected static final String SORT_OPTIONS_IN_HOME_PAGE = "sortOptionsinHomePage";
    protected static final String EXPAND_SORT_OPTIONS_IN_HOME_PAGE = "expandSortOptionsinHomePage";

    protected static final String HOME_EMPTY_SPACE_CLICK = "homeEmptySpaceClick";

    private final static String ASSET_ACTIONS_DROPDOWN = "assetActionDropdown";
    private final static String ASSET_ACTIONS_DROPDOWN_EXPAND = "assetActionDropdownExpand";
    private final static String METADATA_FROM_ACTIONDROPDOWN = "metadataButtonFromAssetAction";
    private final static String VIEW_ACTION_BUTTON = "viewActionButtonInSearchPage";
    private final static String FILTER_BUTTON = "filterButton";

    /**
     * Components
     */
    protected Actions action;

    public PCBasePage(EmergyaWebDriver driver) {
        super(driver);
        action = new Actions(driver);
    }

    /**
     * This method will wait until the Page Object is ready.
     */
    public abstract void waitForReady();

    /**
     * @return if the Ok of the modal is visible.
     */
    public synchronized boolean isOkOfModalShown() {
        boolean IsShown = false;
        if (this.isElementVisibleByXPath(OK_MODAL_BUTTON)) {
            IsShown = true;
        }
        return IsShown;
    }

    /**
     * @return if the Ok of the modal is visible.
     */
    public synchronized void clickOnOkOfModal() {
        if (this.isOkOfModalShown()) {
            this.getElementByXPath(OK_MODAL_BUTTON).click();
            this.waitUntilDisappearByXPath(OK_MODAL_BUTTON);
            this.waitUntilDisappearByXPath(SPINNER);
        }
    }

    /**
     * Method to get time to the collection creation and refresh to get the
     * counter.
     */
    public void sleep20andRefresh() {
        this.driver.sleep(20);
        // action.sendKeys(Keys.F5).perform();
        this.driver.navigate().refresh();
        this.waitUntilDisappearByXPath(SPINNER);
    }

    /**
     * Method to get time to the collection creation and refresh to get the
     * counter.
     */
    public void sleep30andRefresh() {
        this.driver.sleep(30);
        // action.sendKeys(Keys.F5).perform();
        this.driver.navigate().refresh();
        this.waitUntilDisappearByXPath(SPINNER);
    }

    /**
     * Method to get list for given xpath
     * 
     * @param Xpath
     * @return list of server names
     * @author tnakka
     */
    public synchronized List<String> getList(String xpath) {

        List<WebElement> list = this.getElementsByXPath(xpath);
        List<String> lists = new ArrayList<>();

        for (WebElement lst : list) {
            lists.add(lst.getText());

        }
        return lists;

    }

    /**
     * Method to get list for given attribute
     * 
     * @param Xpath
     * @param attribute
     * @return list for given attribute
     * @author tnakka
     */
    public synchronized List<String> getListForAttribute(String xpath, String attribute) {

        List<WebElement> list = this.getElementsByXPath(xpath);
        List<String> lists = new ArrayList<>();

        for (WebElement lst : list) {
            lists.add(lst.getAttribute(attribute));

        }
        return lists;

    }

    /**
     * Method to compare 2 List<String> no mattering order.
     * 
     * @param listA
     * @param listB
     * @return if are equal or not.
     * 
     */
    public synchronized boolean compareLists(List<String> listA, List<String> listB) {
        boolean areEquals = true;

        Collections.sort(listA);

        Collections.sort(listB);
        areEquals = listA.equals(listB);

        return areEquals;
    }

    /**
     * This method to select file and handle windows popup dialog to upload data
     * 
     * @throws IOException
     * @param FileName
     * @author tnakka
     */

    public synchronized void uploadData(String fileName) throws IOException {

        String separate = System.getProperty("file.separator");

        String path = System.getProperty("user.dir") + separate + "src" + separate + "main" + separate + "resources"
                + separate + "files" + separate + "images" + separate + fileName;

        String autoITExecutable = System.getProperty("user.dir") + separate + "src" + separate + "main" + separate
                + "resources" + separate + "files" + separate + "software" + separate + "UploadFile.exe" + " " + path;

        Runtime.getRuntime().exec(autoITExecutable);

    }

    /**
     * This method to get Browser name
     * 
     * @author tnakka
     */

    public synchronized String getBroswerName() {

        Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
        String browserName = caps.getBrowserName();
        return browserName;

    }

    /**
     * Method to Select All options for MultiSelectBox
     * 
     * @param Avalible
     *            BOX Xpath
     * @param Select
     *            button Xpath
     * @author tnakka
     */
    public synchronized void selectAllAvalibleOptionsFromMultiSelectBox(String availableBoxXpath,
            String selectButtonXpath) {

        Select se = new Select(this.getElementByXPath(availableBoxXpath));

        for (int i = 0; i < se.getOptions().size(); i++) {
            this.getElementByXPath(availableBoxXpath).sendKeys(Keys.CONTROL);
            se.selectByIndex(i);
        }
        this.getElementByXPath(selectButtonXpath).click();
        this.waitUntilDisappearByXPath(SPINNER);

    }

    /**
     * Method to Select All options for MultiSelectBox
     * 
     * @param Lits
     *            of Options to be selected
     * @param Avalible
     *            BOX Xpath
     * @param Avalible
     *            BOX Options Xpath
     * @param Select
     *            button Xpath
     * @author tnakka
     */
    public synchronized void selectGivenAvalibleOptionsFromMultiSelectBox(List<String> listOfOptions,
            String availableBoxXpath, String availableBoxOptionsXpath, String selectButton) {

        Select se = new Select(this.getElementByXPath(availableBoxXpath));

        List<String> eachOptions = this.getList(availableBoxOptionsXpath);

        if (this.checkList1keysExistsInList2(eachOptions, listOfOptions)) {

            for (String option : listOfOptions) {
                this.getElementByXPath(availableBoxXpath).sendKeys(Keys.CONTROL);

                se.selectByVisibleText(option);
            }

        } else {
            for (String eachoption : eachOptions) {

                for (String option : listOfOptions) {
                    if (option.equalsIgnoreCase(eachoption)) {
                        this.getElementByXPath(availableBoxXpath).sendKeys(Keys.CONTROL);

                        se.selectByVisibleText(eachoption);
                    }
                }

            }

        }
        this.getElementByXPath(selectButton).click();

        this.waitUntilDisappearByXPath(SPINNER);

    }

    /**
     * Method to Compare list
     * 
     * @param List1
     *            to compared
     * @param List2
     *            to be compared
     * @author tnakka
     */
    public synchronized boolean compareTwoLists(List<String> list1, List<String> list2) {

        boolean isListEqual = false;

        for (String parent : list1) {

            for (String child : list2) {

                if (parent.contains(child)) {
                    isListEqual = true;
                    break;
                }

            }
            if (isListEqual == false) {
                break;
            }

        }

        return isListEqual;
    }

    /**
     * Method to check of set of list1 keys exists in List2
     * 
     * @param List1
     *            which has list of few keys to find in large list
     * @param List2
     *            which has all keys
     * @author tnakka
     */
    public synchronized boolean checkList1keysExistsInList2(List<String> list1, List<String> list2) {

        boolean isListEqual = false;

        for (String child : list2) {

            for (String parent : list1) {

                if (parent.contains(child)) {
                    isListEqual = true;
                    break;
                }

            }
            if (isListEqual == false) {
                break;
            }

        }

        return isListEqual;
    }

    /**
     * Method to select options from dropdown ByVisibleText
     * 
     * @param Xpath
     *            of the picklist/DropDown field
     * @param PickList
     *            name
     * @author tnakka
     */
    public synchronized void selecPickListByVisibleText(String xpathOfPickList, String visibleText) {

        Select se = new Select(this.getElementByXPath(xpathOfPickList));

        se.selectByVisibleText(visibleText);

    }

    /**
     * Method to select options from dropdown ByValue
     * 
     * @param Xpath
     *            of the picklist/DropDown field
     * @param PickList
     *            value
     * @author tnakka
     */
    public synchronized void selecPickListByValue(String xpathOfPickList, String byvalue) {

        Select se = new Select(this.getElementByXPath(xpathOfPickList));

        se.selectByValue(byvalue);

    }

    /**
     * Method to swith to window
     * 
     * @param WindowName
     * @author tnakka
     */
    public synchronized void switchToWindow(String windowName) {

        this.driver.switchTo().window(windowName);

    }

    /**
     * Method to switch to window
     * 
     * @param Parent
     *            Window Name
     * @author tnakka
     */
    public synchronized void switchToChildWindows(String parentWindow) {

        Set<String> windows = this.driver.getWindowHandles();
        for (String childWindow : windows) {
            if (childWindow != parentWindow)
                this.switchToWindow(childWindow);
            break;
        }
    }

    /**
     * Method to get current window
     * 
     * @author tnakka
     */
    public synchronized String getCurrentWindow() {
        String window = this.driver.getWindowHandle();
        return window;
    }

    /**
     * Method to switch to window by window Title
     * 
     * @param WindowTitle
     *            Name
     * @author tnakka
     */
    public synchronized void switchToWindowsByWindowTitle(String windowTitleTextName) {

        Set<String> windows = this.driver.getWindowHandles();

        for (String childWindow : windows) {

            this.switchToWindow(childWindow);

            String windowTitle = this.driver.getTitle();

            if (windowTitleTextName.toLowerCase().contains(windowTitle)) {

                break;
            }

        }
    }

    /**
     * Method to switch to google drive
     * 
     * @author tnakka
     */
    public synchronized void switchToGoogleDriveWindowAndInputUserNameAndPassword() {

        this.switchToWindowsByWindowTitle("Google");
        if (this.retryAndGetElementByXPath(GMAIL_EMAIL_INPUT)) {
            this.getElementByXPath(GMAIL_EMAIL_INPUT).sendKeys("otmediabin@gmail.com");
            this.waitForByXPath(GMAIL_EMAIL_NEXT_INPUT);
            this.getElementByXPath(GMAIL_EMAIL_NEXT_INPUT).click();
        }
        this.driver.sleep(5);
        this.waitForByXPath(GMAIL_PASSWORD_INPUT);
        this.getElementByXPath(GMAIL_PASSWORD_INPUT).sendKeys("welcome2017");
        this.waitForByXPath(GMAIL_PASSWORDL_NEXT_INPUT);
        this.getElementByXPath(GMAIL_PASSWORDL_NEXT_INPUT).click();
        this.driver.sleep(2);

    }

    /**
     * Method to retry and wait if elements are null
     * 
     * @return boolean
     * @author tnakka
     */
    public synchronized boolean retryAndGetElementsByXPath(String xpath) {
        boolean isShowed = false;
        for (int i = 0; i <= 3; i++) {
            if (this.getElementsByXPath(xpath) != null && this.isElementVisibleByXPath(xpath)) {
                isShowed = true;
                break;

            }
        }

        return isShowed;
    }

    /**
     * Method to retry and wait if element are null
     * 
     * @author tnakka
     */
    public synchronized boolean retryAndGetElementByXPath(String xpath) {
        boolean isShowed = false;
        for (int i = 0; i <= 3; i++) {
            if (this.getElementByXPath(xpath) != null && this.isElementVisibleByXPath(xpath)) {
                isShowed = true;
                break;
            }
        }
        return isShowed;

    }

    /**
     * Method to get time to the collection creation and refresh to get the
     * counter.
     */
    public void sleep20() {
        this.driver.sleep(20);
        // action.sendKeys(Keys.F5).perform();
        // this.driver.navigate().refresh();
        // this.waitUntilDisappearByXPath(SPINNER);
    }

    /**
     * Method to return the text present in the dialog message.
     * 
     * @return returns the visible text.
     */
    public String textShownInModalS() {
        String modalMessage = null;
        if (this.isElementVisibleByXPath(OK_MODAL_TEXT)) {
            modalMessage = this.getElementByXPath(OK_MODAL_TEXT).getText();
        }
        return modalMessage;
    }

    /**
     * Method to expand sort options in mobile view 
     * 
    
     */
    public void expandSortOptionsInSearchPage() {

        if (this.isElementVisibleByXPath(SORT_OPTIONS_IN_HOME_PAGE)) {

            if (!this.getElementByXPath(SORT_OPTIONS_IN_HOME_PAGE).isDisplayed()) {
                this.waitUntilDisappearByXPath(SPINNER);
                this.scrollTo(this.getElementByXPath(EXPAND_SORT_OPTIONS_IN_HOME_PAGE));
                this.getElementByXPath(EXPAND_SORT_OPTIONS_IN_HOME_PAGE).click();
            }
        }
    }

    /**
     * Method to open header options in mobile view   
         */
    public void expandHeaderInMobileView() {

        if (!this.getElementByXPath(MOBILE_VIEW_MENU).isDisplayed()) {
            this.waitUntilDisappearByXPath(SPINNER);
            this.scrollTo(this.getElementByXPath(HEADER_MOBILE_VIEW));

            this.getElementByXPath(HEADER_MOBILE_VIEW).click();

        }

    }

    /**
     * Method to expand the Asset actions in asset details.
     */
    public void clickOnAssetActionsDropdownInMobile() {

        // click open the drop down
        if (this.isElementVisibleByXPath(ASSET_ACTIONS_DROPDOWN)) {
            this.getElementByXPath(ASSET_ACTIONS_DROPDOWN).click();
            this.waitForByXPath(ASSET_ACTIONS_DROPDOWN_EXPAND);
        }

    }

    /**
     * Method to Click on metadata button ofasset actions
     */
    public void clickonMetadatabutton() {

        if (this.isElementVisibleByXPath(ASSET_ACTIONS_DROPDOWN_EXPAND)) {
            this.waitUntilDisappearByXPath(SPINNER);
            this.getElementByXPath(METADATA_FROM_ACTIONDROPDOWN).click();
            this.waitUntilDisappearByXPath(SPINNER);
        }

    }

    /**
     * Method to expand vie option button
     */
    public void expandViewActionsButton() {

        this.waitForByXPath(EXPAND_ASSET_DETAILS_ACTIONS);
        if (!this.getElementByXPath(ASSET_DETAILS_ACTIONS).isDisplayed()) {
            this.waitUntilDisappearByXPath(SPINNER);
            this.scrollTo(this.getElementByXPath(EXPAND_ASSET_DETAILS_ACTIONS));

            this.getElementByXPath(EXPAND_ASSET_DETAILS_ACTIONS).click();
        }
    }

    /**
     * Method to expand the Asset actions in asset details.
     */
    public void expandAssetActionsInMobileView() {

        // click open the drop down
        if (this.isElementVisibleByXPath(ASSET_ACTIONS_DROPDOWN)) {
            this.getElementByXPath(ASSET_ACTIONS_DROPDOWN).click();
            this.waitForByXPath(ASSET_ACTIONS_DROPDOWN_EXPAND);
        }
    }

}
