/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.general.checkall;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.GeneralSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class CheckAllServicesPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(CheckAllServicesPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String SERVER_NAMES_LIST = "serverNamesList";
    private final static String INDIVIDUAL_CHECK = "individualcheck";
    private final static String LIBRARYSERVICE_EDIT = "libraryserviceEdit";
    private final static String MEDIABIN_EDIT = "mediabinEdit";
    private final static String GDRIVE_EDIT = "gDriveEdit";

    private final static String AD_EDIT = "adEdit";
    private final static String LDAP_EDIT = "ldapEdit";
    private final static String OTDS_EDIT = "otdsEdit";
    private final static String LIBRARYSERVICE_EDIT_RESULT = "libraryserviceEditResult";
    private final static String MEDIABIN_EDIT_RESULT = "mediabinEditResult";
    private final static String GDRIVE_EDIT_RESULT = "gDriveEditResult";
    private final static String AD_EDIT_RESULT = "adEditResult";
    private final static String LDAP_EDIT_RESULT = "ldapEditResult";
    private final static String OTDS_EDIT_RESULT = "otdsEditResult";

    private final static String LIBRARYSERVICE_STATUS_RESULT = "libraryserviceCheckStatus";
    private final static String MEDIABIN_STATUS_RESULT = "mediabinCheckStatus";
    private final static String GDRIVE_STATUS_RESULT = "gDriveCheckStatus";
    private final static String AD_STATUS_RESULT = "adCheckStatus";
    private final static String LDAP_STATUS_RESULT = "ldapCheckStatus";
    private final static String OTDS_STATUS_RESULT = "otdsCheckStatus";

    private final static String BACK_BUTTON = "backbutton";
    private final static String CHECK_ALL_BUTTON = "checkAll";

    private final static String CHECK_ALL_BUTTON_DISABLED = "checkAllDisabled";
    private final static String PRESS_BUTTON_TEXT = "pressButtonText";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public CheckAllServicesPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new GeneralSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        this.waitForReady();
        for (int i = 0; i <= 5; i++) {
            if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                    && this.isElementVisibleByXPath(INDIVIDUAL_CHECK)
                    && this.isElementVisibleByXPath(LIBRARYSERVICE_EDIT) && this.isElementVisibleByXPath(MEDIABIN_EDIT)
                    && this.isElementVisibleByXPath(GDRIVE_EDIT) && this.isElementVisibleByXPath(AD_EDIT)
                    && this.isElementVisibleByXPath(LDAP_EDIT) && this.isElementVisibleByXPath(CHECK_ALL_BUTTON)
                    && this.isElementVisibleByXPath(OTDS_EDIT)) {
                isReady = true;
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(INDIVIDUAL_CHECK);
        this.waitForByXPath(LIBRARYSERVICE_EDIT);

        this.waitForByXPath(MEDIABIN_EDIT);
        this.waitForByXPath(GDRIVE_EDIT);
        this.waitForByXPath(AD_EDIT);

        this.waitForByXPath(LDAP_EDIT);
        this.waitForByXPath(OTDS_EDIT);
        this.waitForByXPath(CHECK_ALL_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the MediaBin list page.
     * @return dashboard
     */

    public  DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new  DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to Click on Check All service
     */
    public void clickOnCheckAll() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnCheckAll method");
        this.waitForByXPath(CHECK_ALL_BUTTON);
        String parentWindow = this.getCurrentWindow();

        this.getElementByXPath(CHECK_ALL_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(4);
        // Switching from parent window to child window
        this.switchToGoogleDriveWindowAndInputUserNameAndPassword();
        driver.sleep(4);
        this.switchToWindow(parentWindow);
        this.waitUntilDisappearByXPath(PRESS_BUTTON_TEXT);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnCheckAll method");

    }

    /**
     * Click on MediaBin service edit button 
     */
    public void clickOnMediaBinServiceEdit() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnMediaBinServiceEdit method");

        this.waitForByXPath(MEDIABIN_EDIT);

        this.getElementByXPath(MEDIABIN_EDIT).click();
        this.driver.sleep(5);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnMediaBinServiceEdit method");

    }

    /**
     * Click on Gdrive edit button 
     */
    public void clickOnGdriveEdit() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnLibraryServiceEdit method");

        this.waitForByXPath(GDRIVE_EDIT);

        this.getElementByXPath(GDRIVE_EDIT).click();
        this.driver.sleep(5);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnLibraryServiceEdit method");

    }

    /**
     * Click on Library service edit button 
     */
    public void clickOnLibraryServiceEdit() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnLibraryServiceEdit method");

        this.waitForByXPath(LIBRARYSERVICE_EDIT);

        this.getElementByXPath(LIBRARYSERVICE_EDIT).click();
        this.driver.sleep(5);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnLibraryServiceEdit method");

    }

    /**
     * Click on AD service edit button 
     */
    public void clickOnADEdit() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnADEdit method");

        this.waitForByXPath(AD_EDIT);

        this.getElementByXPath(AD_EDIT).click();
        this.driver.sleep(5);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnADEdit method");

    }

    /**
     * Click on LDAP edit button 
     */
    public void clickOnLDAPEdit() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnLDAPEdit method");

        this.waitForByXPath(LDAP_EDIT);

        this.getElementByXPath(LDAP_EDIT).click();
        this.driver.sleep(5);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnLDAPEdit method");

    }

    /**
     * Click on OTDS edit button 
     */
    public void clickOnOTDSEdit() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnOTDSEdit method");

        this.waitForByXPath(OTDS_EDIT);

        this.getElementByXPath(OTDS_EDIT).click();
        this.driver.sleep(5);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnOTDSEdit method");

    }

    /**
     * Check Library Service edit event result
     * @return boolean if MEDIABIN page is navigated or Not
     */
    public boolean checkLibraryServiceEditResult() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start CheckLibraryServiceEditResult method");

        this.waitForByXPath(LIBRARYSERVICE_EDIT_RESULT);

        boolean isShown = false;

        if (this.getElementByXPath(LIBRARYSERVICE_EDIT_RESULT).getAttribute("class").contains("tab active")) {

            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End CheckLibraryServiceEditResult method");

        return isShown;

    }

    /**
     * Check MEDIABIN edit event result
     * @return boolean if MEDIABIN page is navigated or Not
     */
    public boolean checkMBEditResult() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start CheckMBEditResult method");

        this.waitForByXPath(MEDIABIN_EDIT_RESULT);

        boolean isShown = false;

        if (this.getElementByXPath(MEDIABIN_EDIT_RESULT).getAttribute("class").contains("tab active")) {

            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End CheckMBEditResult method");

        return isShown;

    }

    /**
     * Check Gdrive edit event result
     * @return boolean if Gdrive page is navigated or Not
     */
    public boolean checkGDriveEditResult() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start CheckGDriveEditResult method");

        this.waitForByXPath(GDRIVE_EDIT_RESULT);

        boolean isShown = false;

        if (this.getElementByXPath(GDRIVE_EDIT_RESULT).getAttribute("class").contains("tab active")) {

            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End CheckGDriveEditResult method");

        return isShown;

    }

    /**
     * Check AD edit event result
     * @return boolean if AD page is navigated or Not
     */
    public boolean checkADEditResult() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start CheckADEditResult method");

        this.waitForByXPath(AD_EDIT_RESULT);

        boolean isShown = false;

        if (this.getElementByXPath(AD_EDIT_RESULT).getAttribute("class").contains("tab active")) {

            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End CheckADEditResult method");

        return isShown;

    }

    /**
     * Check LDAP edit event result
     * @return boolean if LDAP page is navigated or Not
     */
    public boolean checkLDAPEditResult() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start CheckLDAPEditResult method");

        this.waitForByXPath(LDAP_EDIT_RESULT);

        boolean isShown = false;

        if (this.getElementByXPath(LDAP_EDIT_RESULT).getAttribute("class").contains("tab active")) {

            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End CheckLDAPEditResult method");

        return isShown;

    }

    /**
     * Check OTDS edit event result
     * @return boolean if OTDS page is navigated or Not
     */
    public boolean checkOTDSEditResult() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start CheckOTDSEditResult method");

        this.waitForByXPath(OTDS_EDIT_RESULT);

        boolean isShown = false;

        if (this.getElementByXPath(OTDS_EDIT_RESULT).getAttribute("class").contains("tab active")) {

            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End CheckOTDSEditResult method");

        return isShown;

    }

    /**
     * Check Library status result
     * @return boolean if MB check result is pass
     */
    public boolean checkLibraryCheckResult() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkLibraryCheckResult method");

        this.waitForByXPath(LIBRARYSERVICE_STATUS_RESULT);

        boolean isShown = false;

        if (this.getElementByXPath(LIBRARYSERVICE_STATUS_RESULT).getText().contains("Library is working properly.")) {

            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkLibraryCheckResult method");

        return isShown;

    }

    /**
     * Check MB status result
     * @return boolean if MB check result is pass
     */
    public boolean checkMBCheckResult() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkMBCheckResult method");

        this.waitForByXPath(MEDIABIN_STATUS_RESULT);

        boolean isShown = false;

        if (this.getElementByXPath(MEDIABIN_STATUS_RESULT).getText().contains("Mediabin is working properly.")) {

            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkMBCheckResult method");

        return isShown;

    }

    /**
     * Check GDrive status result
     * @return boolean if GDrive check result is pass
     */
    public boolean checkGDriveCheckResult() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkGDriveCheckResult method");

        this.waitForByXPath(GDRIVE_STATUS_RESULT);

        boolean isShown = false;

        if (this.getElementByXPath(GDRIVE_STATUS_RESULT).getText().contains("Google Drive is working properly.")) {

            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkGDriveCheckResult method");

        return isShown;

    }

    /**
     * Check AD status result
     * @return boolean if AD check result is pass
     */
    public boolean checkADCheckResult() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkADCheckResult method");

        this.waitForByXPath(AD_STATUS_RESULT);

        boolean isShown = false;

        if (this.getElementByXPath(AD_STATUS_RESULT).getText()
                .contains("Active Directory server is working properly.")) {

            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkADCheckResult method");

        return isShown;

    }

    /**
     * Check LDAP status result
     * @return boolean if LDAP check result is pass
     */
    public boolean checkLDAPCheckResult() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkLDAPCheckResult method");

        this.waitForByXPath(LDAP_STATUS_RESULT);

        boolean isShown = false;

        if (this.getElementByXPath(LDAP_STATUS_RESULT).getText().contains("LDAP server is working properly.")) {

            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkLDAPCheckResult method");

        return isShown;

    }

    /**
     * Check OTDS status result
     * @return boolean if OTDS check result is pass
     */
    public boolean checkOTDSCheckResult() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkOTDSCheckResult method");

        this.waitForByXPath(OTDS_EDIT_RESULT);

        boolean isShown = false;

        if (this.getElementByXPath(OTDS_STATUS_RESULT).getText().contains("OTDS server is working properly.")) {

            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkOTDSCheckResult method");

        return isShown;

    }

    /**
     * Click on individual check buttons 
     */
    public void clickOnIndividualCheckLinks() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnCheckLinks method");

        List<WebElement> checklist = this.getElementsByXPath(INDIVIDUAL_CHECK);
        String parentWindow = this.getCurrentWindow();

        for (WebElement list : checklist) {
            list.click();
            this.waitUntilDisappearByXPath(SPINNER);
            this.driver.sleep(2);
        }

        this.switchToGoogleDriveWindowAndInputUserNameAndPassword();
        this.driver.sleep(2);
        this.switchToWindow(parentWindow);
        this.driver.sleep(2);
        this.waitUntilDisappearByXPath(PRESS_BUTTON_TEXT);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnCheckLinks method");

    }

    /**
     * Navigate back to the page
     */
    public void navigateBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start CheckOTDSEditResult method");

        this.driver.navigate().back();
        this.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End CheckOTDSEditResult method");

    }

}
