/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.opentext.dto.Section;
import com.opentext.dto.Subsection;
import com.opentext.pageObjects.administration.factories.SubsectionPagesFactory;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.SectionType;

/**
 * This PO contains the commons methods to interact with the Sections page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public class SectionResumePage extends GeneralResumePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(SectionResumePage.class);

    /**
     * Components
     */
    private Section section;
    private List<SubSectionResumePage> SubSectionResumeList;

    /**
     * Items keys selectors.
     */
    // Nothing in special

    /**
     * Constructor method.
     * @param driver selenium webdriver.
     * @param section of the resume page.
     */
    public SectionResumePage(EmergyaWebDriver driver, Section section) {
        super(driver);
        this.section = section;
        SubSectionResumeList = new ArrayList<>();
        for (Subsection subsection : this.section.getSubsections()) {
            SubSectionResumeList.add(new SubSectionResumePage(driver, subsection));
        }
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        WebElement sectionElement = this.getSectionElement();

        if (sectionElement != null && sectionElement.isDisplayed()) {
            isReady = true;
            for (SubSectionResumePage subsectionResume : SubSectionResumeList) {
                isReady = subsectionResume.isReady() && isReady;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        WebElement sectionElement = this.getSectionElement();
        this.waitForByElement(sectionElement);

        for (SubSectionResumePage subsectionResume : SubSectionResumeList) {
            subsectionResume.waitForReady();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return the WebElement represented by this section.
     */
    protected synchronized WebElement getSectionElement() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getSectionElement method");

        String sectionXpath = this.getXPath(SECTION_DYNAMIC);
        sectionXpath = sectionXpath.replace("%pc-id%", this.section.getSectionPcId());
        WebElement sectionElement = this.driver.findElement(By.xpath(sectionXpath));

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getSectionElement method");

        return sectionElement;
    }

    /**
     * Method to navigate to the proper section main page.
     * @param list of {@link Section} visible.
     * @return specific {@link SectionPage} ready to work with.
     */
    public SectionPage goToSection(List<Section> sectionsVisible) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToSection method");

        this.getSectionElement().click();

        SectionPage sectionPage = SubsectionPagesFactory
                .buildScreenOfSectionPage(driver, this.getSectionType(), sectionsVisible);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToSection method");

        return sectionPage;
    }

    /**
     * @return SectionType of the {@link Section} contained here.
     */
    public synchronized SectionType getSectionType() {
        return this.section.getType();
    }

    /**
     * @return the subSectionResumeList
     */
    public synchronized List<SubSectionResumePage> getSubSectionResumeList() {
        return SubSectionResumeList;
    }

}
