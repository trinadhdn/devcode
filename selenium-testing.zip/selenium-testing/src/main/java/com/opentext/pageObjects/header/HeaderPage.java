/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.header;

import static org.testng.AssertJUnit.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.collectionListArea.CollectionListAreaPage;
import com.opentext.pageObjects.inbox.InboxPage;
import com.opentext.pageObjects.login.LogoutPage;
import com.opentext.pageObjects.profile.ProfilePage;
import com.opentext.pageObjects.search.SearchPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Header page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class HeaderPage extends PCBasePage {

    /**
     * Items keys selectors.
     */
    private final static String LOGO = "logo";
    private final static String COLLECTION_BUTTON = "collectionButton";
    private final static String COLL_BTN_COUNTER = "collectionButtonCounter";
    private final static String ADMIN_BUTTON = "adminButton";
    // private static final static String HELP_BUTTON = "helpButton";
    private final static String PROFILE_BUTTON = "profileButton";
    private final static String INBOX_BUTTON = "inboxButton";
    private final static String INB_BTN_COUNTER = "inboxButtonCounter";
    private final static String LOGOUT_BUTTON = "logoutButton";

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(HeaderPage.class);

    /**
     * Constructor method
     * 
     * @param driver
     *            selenium webdriver
     */
    public HeaderPage(EmergyaWebDriver driver) {
        super(driver);
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        this.waitForReady();
        for (int i = 0; i <= 3; i++) {

            if (this.isElementVisibleByXPath(LOGO) && this.isElementVisibleByXPath(COLLECTION_BUTTON)
                    && this.isElementVisibleByXPath(ADMIN_BUTTON) && this.isElementVisibleByXPath(PROFILE_BUTTON)
                    && this.isElementVisibleByXPath(INBOX_BUTTON) && this.isElementVisibleByXPath(LOGOUT_BUTTON)) {
                isReady = true;
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(LOGO);
        this.waitForByXPath(COLLECTION_BUTTON);
        this.waitForByXPath(ADMIN_BUTTON);
        // this.waitForByXPath(HELP_BUTTON);
        this.waitForByXPath(PROFILE_BUTTON);
        this.waitForByXPath(INBOX_BUTTON);
        this.waitForByXPath(LOGOUT_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to change the focus to the Logo of the header.
     */
    public synchronized void getFocusOnLogo() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getFocusOnLogo method");

        action.moveToElement(this.getElementByXPath(LOGO)).perform();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getFocusOnLogo method");
    }

    /**
     * Method to click on logout button.
     * 
     * @return Logout page ready to work with.
     */
    public synchronized LogoutPage clickOnLogoutButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnLogoutButton method");
        this.expandHeaderInMobileView();

        this.scrollTo(this.getElementByXPath(LOGOUT_BUTTON));
        this.waitUntilElementVisibileByXPath(LOGOUT_BUTTON);
        this.waitUntilElementClickableByXPath(LOGOUT_BUTTON);
        this.getElementByXPath(LOGOUT_BUTTON).click();

        LogoutPage logoutPage = new LogoutPage(driver);
        logoutPage.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnLogoutButton method");

        return logoutPage;
    }

    /**
     * Method to click on profile button.
     * 
     * @return Profile page ready to work with.
     */
    public synchronized ProfilePage clickOnProfileButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnProfileButton method");

        this.expandHeaderInMobileView();
        this.getElementByXPath(PROFILE_BUTTON).click();
        this.driver.sleep(1);

        ProfilePage profilePage = new ProfilePage(driver);
        profilePage.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnProfileButton method");

        return profilePage;
    }

    /**
     * @return The counter of the collections in the header button.
     */
    public synchronized Integer getCollectionCounter() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCollectionCounter method");

        Integer counterCollection = 0;
        this.waitForByXPath(COLL_BTN_COUNTER);
        this.expandHeaderInMobileView();
        this.waitUntilDisappearByXPath(SPINNER);

        counterCollection = Integer.parseInt(this.getElementByXPath(COLL_BTN_COUNTER).getText().trim());
        if (this.getElementByXPath(HEADER_MOBILE_VIEW).getAttribute("aria-expanded").contains("true")) {
            this.getElementByXPath(HOME_EMPTY_SPACE_CLICK).click();

        } else

        {
            assertTrue("Collection button counter is not ready.", false);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCollectionCounter method");

        return counterCollection;

    }

    /**
     * Method to click on collections button.
     * 
     * @return CollectionListArea page ready to work with.
     */
    public synchronized CollectionListAreaPage clickOnCollectionsButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnCollectionsButton method");

        this.expandHeaderInMobileView();

        this.waitUntilElementVisibileByXPath(COLLECTION_BUTTON);
        this.waitUntilElementClickableByXPath(COLLECTION_BUTTON);
        this.getElementByXPath(COLLECTION_BUTTON).click();
        CollectionListAreaPage collectionListAreaPage = new CollectionListAreaPage(driver);
        collectionListAreaPage.waitForReady();
        this.driver.sleep(2);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnCollectionsButton method");

        return collectionListAreaPage;
    }

    /**
     * Method to click on Logo for search page.
     * 
     * @return Search page ready to work with.
     */
    public synchronized SearchPage clickOnLogo() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnLogo method");
        this.scrollTop();
        this.getElementByXPath(LOGO).click();
        this.driver.sleep(1);
        SearchPage searchPage = new SearchPage(driver);
        searchPage.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnLogo method");

        return searchPage;
    }

    /**
     * @return The counter of the Inbox in the header button.
     */
    public synchronized Integer getInboxCounter() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getInboxCounter method");

        Integer counterInbox = null;
        this.driver.sleep(10);
        try {
            if (this.isElementVisibleByXPath(INB_BTN_COUNTER)) {
                counterInbox = Integer
                        .parseInt(this.getElementByXPath(INB_BTN_COUNTER).getText().replaceAll("[^0-9]", "").trim());
            }
        } catch (Exception e) {
            counterInbox = 0;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getInboxCounter method");

        return counterInbox;
    }

    /**
     * Method to click on Inbox button.
     * 
     * @return InboxPage ready to work with.
     */
    public synchronized InboxPage clickOnInboxButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnInboxButton method");

        this.getElementByXPath(INBOX_BUTTON).click();
        this.driver.sleep(1);
        this.waitUntilDisappearByXPath(SPINNER);

        InboxPage inbox = new InboxPage(driver);
        inbox.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnInboxButton method");

        return inbox;
    }

    /**
     * Method to click on Administration button.
     * 
     * @param sections
     *            to be used to build the dashboard.
     * @return DashboardPage ready to work with.
     */
    public synchronized DashboardPage clickOnAdministrationButton(List<Section> sections) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start clickOnAdministrationButton method");

        this.expandHeaderInMobileView();
        this.getElementByXPath(ADMIN_BUTTON).click();
        this.driver.sleep(1);
        this.waitUntilDisappearByXPath(SPINNER);

        if (this.isElementVisibleByXPath(OK_MODAL_BUTTON, 5)) {

            this.clickOnOkOfModal();
        }

        DashboardPage dashboard = new DashboardPage(driver, sections);
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnAdministrationButton method");

        return dashboard;
    }

    /**
     * @return boolean about Admin
     */

    public boolean isAdminButtonShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isAdminButtonShown method");

        boolean isReady = false;

        if (this.isElementVisibleByXPath(ADMIN_BUTTON)) {
            isReady = true;

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isAdminButtonShown method");

        return isReady;
    }

}
