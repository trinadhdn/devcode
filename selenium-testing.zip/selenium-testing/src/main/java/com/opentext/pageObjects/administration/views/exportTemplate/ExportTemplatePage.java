/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.views.exportTemplate;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.ViewsSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class ExportTemplatePage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(ExportTemplatePage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String BACK_BUTTON = "backButton";

    private final static String TEMPLATE_NAME_INPUT = "templateNameInput";
    private final static String LIST_VIEW_TEMPLATE = "listViewTemplate";

    private final static String DETAIL_VIEW_TEMPLATE = "detailViewTemplate";
    private final static String GRID_VIEW_WITH_2COLOUMNS_TEMPLATE = "gridViewWith2coloumsTemplate";
    private final static String GRID_VIEW_WITH_4COLOUMNS_TEMPLATE = "gridViewWith4coloumsTemplate";

    private final static String TEMPLATES_NAME_COLOUMN_IN_LIST = "templatesNameColoumnInList";
    private final static String LAYOUT_COLOUMN_IN_LIST = "layoutColoumnInList";
    private final static String COLOUMN_NUMBERS_COLOUMN_IN_LIST = "coloumnNumbersColoumnInList";
    private final static String ADD_TEMPLATE_BUTTON = "addtemplateButton";
    private final static String METADATA_COLOUMN_IN_LIST = "metadataColoumnInList";
    private final static String EDIT_BUTTON_COLOUMN_IN_LIST = "metadataColoumnInList";
    private final static String DELETE_BUTTON_COLOUMN_IN_LIST = "deleteButtonInList";
    private final static String MODAL_OK_BUTTON = "modalOkButton";

    private final static String SAVE_BUTTON = "saveButton";

    private final static String TEMPLATE_METADATA_COFIG_AVAILABLE_OPTIONS = "templateMetadataConfigurationAvailableOptions";
    private final static String TEMPLATE_METADATA_COFIG_AVAILABLE_OPTIONS_LIST = "templateMetadataConfigurationAvailableOptionsList";
    private final static String TEMPLATE_METADATA_COFIG_SELECTED_OPTIONS = "templateMetadataConfigurationSelectedOptions";
    private final static String TEMPLATE_METADATA_COFIG_SELECTED_OPTIONS_LIST = "templateMetadataConfigurationSelectedOptionsList";

    private final static String SELECT_OPTIONS_FOR_TEMPLATE_METADATA_COFIG = "selectButtonForTemplateMetadataConfiguration";
    private final static String DESELECT_OPTIONS_TEMPLATE_METADATA_COFIG = "deSelectButtonTemplateMetadataConfiguration";

    private final static String TEMPLATE_NAME_IS_REQUIRED_MESSAGE = "templateNameIsRequiredMessage";

    private final static String ADD_TEMPLATE_MESSAGE_WHEN_NO_EXISTING_TEMPLATES = "addTemplateMessage";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public ExportTemplatePage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new ViewsSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(LAYOUT_COLOUMN_IN_LIST)
                && this.isElementVisibleByXPath(TEMPLATES_NAME_COLOUMN_IN_LIST)
                && this.isElementVisibleByXPath(COLOUMN_NUMBERS_COLOUMN_IN_LIST)
                && this.isElementVisibleByXPath(METADATA_COLOUMN_IN_LIST)
                && this.isElementVisibleByXPath(EDIT_BUTTON_COLOUMN_IN_LIST)
                && this.isElementVisibleByXPath(DELETE_BUTTON_COLOUMN_IN_LIST)
                && this.isElementVisibleByXPath(ADD_TEMPLATE_BUTTON)) {
            isReady = true;
        } else if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(ADD_TEMPLATE_BUTTON)
                && this.isElementVisibleByXPath(ADD_TEMPLATE_MESSAGE_WHEN_NO_EXISTING_TEMPLATES)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * @return boolean about this PO is ready
     */
    public boolean isCreateAndEditPageReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isCreateAndEditPageReady method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(BACK_BUTTON) && this.isElementVisibleByXPath(TEMPLATE_NAME_INPUT)
                && this.isElementVisibleByXPath(LIST_VIEW_TEMPLATE)
                && this.isElementVisibleByXPath(DETAIL_VIEW_TEMPLATE)
                && this.isElementVisibleByXPath(GRID_VIEW_WITH_2COLOUMNS_TEMPLATE)
                && this.isElementVisibleByXPath(GRID_VIEW_WITH_4COLOUMNS_TEMPLATE)
                && this.isElementVisibleByXPath(TEMPLATE_METADATA_COFIG_AVAILABLE_OPTIONS)
                && this.isElementVisibleByXPath(TEMPLATE_METADATA_COFIG_SELECTED_OPTIONS)
                && this.isElementVisibleByXPath(SELECT_OPTIONS_FOR_TEMPLATE_METADATA_COFIG)
                && this.isElementVisibleByXPath(DESELECT_OPTIONS_TEMPLATE_METADATA_COFIG)
                && this.isElementVisibleByXPath(SAVE_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isCreateAndEditPageReady method");

        return isReady;
    }

    /**
     * Method to navigate back to the View General page.
     * @return {@link ExportTemplate} ready to work with.
     */
    @Override
    public  DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new  DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * This method will wait until this PO is ready
     */
    public void waitForCreateAndEditPageReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);
        this.waitForByXPath(TEMPLATE_NAME_INPUT);
        this.waitForByXPath(LIST_VIEW_TEMPLATE);
        this.waitForByXPath(DETAIL_VIEW_TEMPLATE);
        this.waitForByXPath(GRID_VIEW_WITH_2COLOUMNS_TEMPLATE);
        this.waitForByXPath(GRID_VIEW_WITH_4COLOUMNS_TEMPLATE);
        this.waitForByXPath(TEMPLATE_METADATA_COFIG_AVAILABLE_OPTIONS);
        this.waitForByXPath(TEMPLATE_METADATA_COFIG_SELECTED_OPTIONS);
        this.waitForByXPath(SELECT_OPTIONS_FOR_TEMPLATE_METADATA_COFIG);
        this.waitForByXPath(DESELECT_OPTIONS_TEMPLATE_METADATA_COFIG);
        this.waitForByXPath(SAVE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(TEMPLATES_NAME_COLOUMN_IN_LIST);
        this.waitForByXPath(LAYOUT_COLOUMN_IN_LIST);
        this.waitForByXPath(COLOUMN_NUMBERS_COLOUMN_IN_LIST);
        this.waitForByXPath(ADD_TEMPLATE_BUTTON);
        this.waitForByXPath(METADATA_COLOUMN_IN_LIST);
        this.waitForByXPath(EDIT_BUTTON_COLOUMN_IN_LIST);
        this.waitForByXPath(DELETE_BUTTON_COLOUMN_IN_LIST);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to click on Add template 
     */
    public void clickOnAddTemplate() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnAddTemplate method");

        this.waitForByXPath(ADD_TEMPLATE_BUTTON);

        this.getElementByXPath(ADD_TEMPLATE_BUTTON).click();

        this.waitForCreateAndEditPageReady();

        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deselectAllOptions method");

    }

    /**
     * Method to fill the data
     */
    public void fillAndSelectTemplateType(String templateName, String templateType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillAllDetails method");

        this.getElementByXPath(TEMPLATE_NAME_INPUT).sendKeys(templateName);

        if (templateType.toLowerCase().contains("list")) {

            this.getElementByXPath(LIST_VIEW_TEMPLATE).click();

        } else if (templateType.toLowerCase().contains("detail")) {

            this.getElementByXPath(DETAIL_VIEW_TEMPLATE).click();

        } else if (templateType.toLowerCase().contains("grid view with 2 columns")) {

            this.getElementByXPath(GRID_VIEW_WITH_2COLOUMNS_TEMPLATE).click();

        } else if (templateType.toLowerCase().contains("grid view with 4 columns")) {

            this.getElementByXPath(GRID_VIEW_WITH_4COLOUMNS_TEMPLATE).click();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillAllDetails method");

    }

    /**
     * Method to Select options for Template metadata configuration
     */
    public void selectAllOptionsForTemplateMetadataConfiguration() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectOptionsForTemplateMetadataConfiguration method");

        this.selectAllAvalibleOptionsFromMultiSelectBox(TEMPLATE_METADATA_COFIG_AVAILABLE_OPTIONS, SELECT_OPTIONS_FOR_TEMPLATE_METADATA_COFIG);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectOptionsForTemplateMetadataConfiguration method");
    }

    /**
     * Method to check if name exists in list 
     * @return boolean
    */
    public boolean isTemplateNameExistsInList(String templateName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isTemplateNameExistsInList method");

        boolean isMatched = false;

        List<String> templateNamesLists = this.getList(TEMPLATES_NAME_COLOUMN_IN_LIST);

        for (String eachTemplateName : templateNamesLists) {

            if (eachTemplateName.equalsIgnoreCase(templateName)) {
                isMatched = true;
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isTemplateNameExistsInList method");

        return isMatched;
    }

    /**
     * Method to check if is require message shown
     * @return boolean
    */
    public boolean isRequireMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isRequireMessageShown method");

        boolean isShown = false;

        isShown = this.isElementVisibleByXPath(TEMPLATE_NAME_IS_REQUIRED_MESSAGE);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRequireMessageShown method");

        return isShown;
    }

    /**
     * Method to save the details
     */
    public void clickOnSave() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        this.getElementByXPath(SAVE_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);


        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSave method");

    }

    /**
     * Method to delete all templates 
    */
    public void deleteAllTemplates() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteAllTemplates method");

        List<String> templateNamesLists = this.getList(TEMPLATES_NAME_COLOUMN_IN_LIST);

        for (String eachTemplateName : templateNamesLists) {
            this.getElementsByXPath(DELETE_BUTTON_COLOUMN_IN_LIST).get(0).click();
            this.driver.sleep(3);
            this.getElementByXPath(MODAL_OK_BUTTON).click();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteAllTemplates method");

    }
}
