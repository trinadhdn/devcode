/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.security.otds;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.SecuritySubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.ConfigFactory;
import com.opentext.utils.ConfigOTDS;
import com.opentext.utils.ConfigOTDS.ConfigOTDSDetails;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class OTDSSettingsPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(OTDSSettingsPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String SERVER_NAME_INPUT = "serverInput";
    private final static String PORT_NUMBER_INPUT = "portNumberInput";

    private final static String DN_FOR_NON_ANONYMOUS_SEARCH = "dnForNonAnonymousSearch";
    private final static String PASSWORD_DN_FOR_NON_ANONYMOUS_SEARCH = "passwordDNForNonAnonymousSearch";
    private final static String OTDS_RESOURCE_IDENTIFIER_INPUT = "otdsResourceIdentifierInput";
    private final static String DOMAIN_NAME_ATTRIBUTE = "domainNameAttribute";

    private final static String FIRST_NAME = "firstName";
    private final static String LAST_NAME = "lastName";
    private final static String EMAIL_ATTRIBUTE = "emailAttribute";
    private final static String SEARCH_GROUP_FIELD_NAME = "searchGroupFieldNameInput";

    private final static String USE_HTTPS = "usehttps";

    private final static String SERVERNAME_REQUIRED_FIELD_MESSAGE = "serverNameRequiredFieldMessage";
    private final static String OTDS_PORT_REQUIRED_FIELD_MESSAGE = "otdsPortNumberRequiredFieldMessage";

    private final static String DN_FOR_NON_ANONYMOUS_SEARCH_REQUIRED_FIELD_MESSAGE = "dnForNonAnonymousSearchRequiredFieldMessage";
    private final static String OTDS_RESOURCE_IDENTIFIER_REQUIRED_FIELD_MESSAGE = "otdsResourceIdentifierRequiredFieldMessage";
    private final static String FIRST_NAME_REQUIRED_FIELD_MESSAGE = "firstNameRequiredFieldMessage";
    private final static String LAST_NAME_REQUIRED_FIELD_MESSAGE = "lastNameRequiredFieldMessage";
    private final static String EMAIL_ATTRIBUTE_REQUIRED_FIELD_MESSAGE = "emailAttributeRequiredFieldMessage";

    protected final String SAVE_BUTTON = "saveButton";
    private final static String BACK_BUTTON = "backbutton";
    private final static String CHECK_SERVICE = "checkservice";
    private final static String CHECK_SERVICE_MESSAGE = "checkservicemessage";
    private final static String SUSSESSFULLY_SAVED_MESSAGE = "successfullySavedMessage";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public OTDSSettingsPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new SecuritySubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(SERVER_NAME_INPUT) && this.isElementVisibleByXPath(PORT_NUMBER_INPUT)
                && this.isElementVisibleByXPath(DN_FOR_NON_ANONYMOUS_SEARCH)
                && this.isElementVisibleByXPath(PASSWORD_DN_FOR_NON_ANONYMOUS_SEARCH)
                && this.isElementVisibleByXPath(FIRST_NAME) && this.isElementVisibleByXPath(LAST_NAME)
                && this.isElementVisibleByXPath(EMAIL_ATTRIBUTE)
                && this.isElementVisibleByXPath(SEARCH_GROUP_FIELD_NAME) && this.isElementVisibleByXPath(USE_HTTPS)
                && this.isElementVisibleByXPath(OTDS_RESOURCE_IDENTIFIER_INPUT)
                && this.isElementVisibleByXPath(DOMAIN_NAME_ATTRIBUTE) && this.isElementVisibleByXPath(SAVE_BUTTON)
                && this.isElementVisibleByXPath(CHECK_SERVICE)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(SERVER_NAME_INPUT);
        this.waitForByXPath(PORT_NUMBER_INPUT);

        this.waitForByXPath(DN_FOR_NON_ANONYMOUS_SEARCH);
        this.waitForByXPath(PASSWORD_DN_FOR_NON_ANONYMOUS_SEARCH);
        this.waitForByXPath(FIRST_NAME);
        this.waitForByXPath(LAST_NAME);
        this.waitForByXPath(EMAIL_ATTRIBUTE);
        this.waitForByXPath(SEARCH_GROUP_FIELD_NAME);
        this.waitForByXPath(USE_HTTPS);
        this.waitForByXPath(OTDS_RESOURCE_IDENTIFIER_INPUT);
        this.waitForByXPath(DOMAIN_NAME_ATTRIBUTE);

        this.waitForByXPath(SAVE_BUTTON);
        this.waitForByXPath(CHECK_SERVICE);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the MediaBin list page.
     * @return dashboard
     */

    public DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to save the new/edited server.
     * @return {@link ADSettingPage} ready to work with or null if the form wasn't completed.
     */
    public OTDSSettingsPage clickOnSave() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        this.getElementByXPath(SAVE_BUTTON).click();
        this.driver.sleep(1);

        OTDSSettingsPage adSettings = null;

        if (!this.isElementVisibleByXPath(SERVERNAME_REQUIRED_FIELD_MESSAGE, 1)
                && !this.isElementVisibleByXPath(DN_FOR_NON_ANONYMOUS_SEARCH_REQUIRED_FIELD_MESSAGE, 1)
                && !this.isElementVisibleByXPath(FIRST_NAME_REQUIRED_FIELD_MESSAGE, 1)
                && !this.isElementVisibleByXPath(LAST_NAME_REQUIRED_FIELD_MESSAGE, 1)
                && !this.isElementVisibleByXPath(EMAIL_ATTRIBUTE_REQUIRED_FIELD_MESSAGE, 1)
                && !this.isElementVisibleByXPath(OTDS_RESOURCE_IDENTIFIER_REQUIRED_FIELD_MESSAGE, 1)) {
            // If no error is shown:
            this.waitUntilDisappearByXPath(SPINNER);
            adSettings = new OTDSSettingsPage(driver, this.getSectionsVisible());
            adSettings.waitForReady();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSave method");

        return adSettings;
    }

    /**
     * @return boolean about if required field message is shown or not
     */
    public boolean isRequiredFieldMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isRequiredFieldMessageShown method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(SERVERNAME_REQUIRED_FIELD_MESSAGE, 1)
                && this.isElementVisibleByXPath(DN_FOR_NON_ANONYMOUS_SEARCH_REQUIRED_FIELD_MESSAGE, 1)
                && this.isElementVisibleByXPath(FIRST_NAME_REQUIRED_FIELD_MESSAGE, 1)
                && this.isElementVisibleByXPath(LAST_NAME_REQUIRED_FIELD_MESSAGE, 1)
                && this.isElementVisibleByXPath(EMAIL_ATTRIBUTE_REQUIRED_FIELD_MESSAGE, 1)
                && this.isElementVisibleByXPath(OTDS_RESOURCE_IDENTIFIER_REQUIRED_FIELD_MESSAGE, 1)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRequiredFieldMessageShown method");

        return isReady;
    }

    /**
     * Method to fill ADSettings 
    */
    public void fillOTDSSettingsDetails(ConfigOTDSDetails OTDSSERVERNAME, ConfigOTDSDetails OTDSPORT,
            ConfigOTDSDetails OTDSDN, ConfigOTDSDetails OTDSDNPASSWORD, ConfigOTDSDetails OTDSRESOURCEIDENTIFIER,
            ConfigOTDSDetails OTDSDOMAINNAME, ConfigOTDSDetails OTDSFIRSTNAME, ConfigOTDSDetails OTDSLASTNAME,
            ConfigOTDSDetails OTDSEMAIL, ConfigOTDSDetails OTDSSEARCHGROUPFIELDNAME) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillLDAPSettingsDetails method");

        // Clear exsting data
        this.clearDeatils();

        // Fill details
        ConfigOTDS Config = ConfigFactory
                .getOTDSConfigDetils(OTDSSERVERNAME, OTDSPORT, OTDSDN, OTDSDNPASSWORD, OTDSRESOURCEIDENTIFIER, OTDSDOMAINNAME, OTDSFIRSTNAME, OTDSLASTNAME, OTDSEMAIL, OTDSSEARCHGROUPFIELDNAME);

        this.getElementByXPath(SERVER_NAME_INPUT).sendKeys(Config.getOTDSServerName());
        this.getElementByXPath(PORT_NUMBER_INPUT).sendKeys(Config.getOTDSPortNumberInput());
        this.getElementByXPath(DN_FOR_NON_ANONYMOUS_SEARCH).sendKeys(Config.getOTDSdn());
        this.getElementByXPath(PASSWORD_DN_FOR_NON_ANONYMOUS_SEARCH).sendKeys(Config.getOTDSDNPassword());
        this.getElementByXPath(OTDS_RESOURCE_IDENTIFIER_INPUT).sendKeys(Config.getOTDSResourceIdentifier());
        this.getElementByXPath(DOMAIN_NAME_ATTRIBUTE).sendKeys(Config.getOTDSDomainName());
        this.getElementByXPath(FIRST_NAME).sendKeys(Config.getOTDSFirstName());
        this.getElementByXPath(LAST_NAME).sendKeys(Config.getOTDSLastName());
        this.getElementByXPath(EMAIL_ATTRIBUTE).sendKeys(Config.getOTDSEmail());
        this.getElementByXPath(SEARCH_GROUP_FIELD_NAME).sendKeys(Config.getOTDSSearchGroupFieldName());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillLDAPSettingsDetails method");

    }

    /**
     * Method to clear data .
    */
    public void clearDeatils() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clearDeatils method");

        this.getElementByXPath(SERVER_NAME_INPUT).clear();
        this.getElementByXPath(PORT_NUMBER_INPUT).clear();
        this.getElementByXPath(DN_FOR_NON_ANONYMOUS_SEARCH).clear();
        this.getElementByXPath(PASSWORD_DN_FOR_NON_ANONYMOUS_SEARCH).clear();
        this.getElementByXPath(OTDS_RESOURCE_IDENTIFIER_INPUT).clear();
        this.getElementByXPath(DOMAIN_NAME_ATTRIBUTE).clear();
        this.getElementByXPath(FIRST_NAME).clear();
        this.getElementByXPath(LAST_NAME).clear();
        this.getElementByXPath(EMAIL_ATTRIBUTE).clear();
        this.getElementByXPath(SEARCH_GROUP_FIELD_NAME).clear();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clearDeatils method");

    }

    /**
     * Method to check Successfully created message.
     * @return boolean about if server created successfully or not.
    */
    public boolean isSuccessfullyCreatedMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isSuccessfullyCreatedMessageShown method");

        boolean isShown = false;
        String message = this.getElementByXPath(SUSSESSFULLY_SAVED_MESSAGE).getText();
        if (message.equalsIgnoreCase("Configuration successfully saved.")) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isSuccessfullyCreatedMessageShown method");

        return isShown;

    }

    /**
     * Method to check the settings.
     * @return boolean about if setting is working fine or not
    */
    public boolean checkService() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkService method");

        boolean checkservice = false;
        this.getElementByXPath(CHECK_SERVICE).click();
        this.waitForByXPath(CHECK_SERVICE_MESSAGE, 10);
        String message = this.getElementByXPath(CHECK_SERVICE_MESSAGE).getText();
        if (message.equalsIgnoreCase("OTDS server is working properly.")) {
            checkservice = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkService method");

        return checkservice;

    }

    /**
     * Method to check the Invalid settings
     * @return boolean about if settings is working fine or not
    */
    public boolean checkInvalidService() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkService method");

        boolean checkInvalidservice = false;
        this.getElementByXPath(CHECK_SERVICE).click();
        driver.sleep(2);
        if (!(this.getElementByXPath(CHECK_SERVICE_MESSAGE)).getAttribute("style").contains("display: block;")) {
            this.getElementByXPath(CHECK_SERVICE).click();
            this.waitForByXPath(CHECK_SERVICE_MESSAGE);
        }
        if (this.getElementByXPath(CHECK_SERVICE_MESSAGE).getText()
                .contains("OTDS server is not working. Please, review your configuration.")) {
            checkInvalidservice = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkService method");

        return checkInvalidservice;

    }
}
