/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText Technologies.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.testusers.microsite;

import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.MicrositeSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Microsite subsections.
 * 
 * @author MavyaPapishetty <mpapishe@opentext.com>
 */
public class MicrositeTestUsersPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(MicrositeTestUsersPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private static final String BACK_BUTTON = "backButton";
    private static final String SEARCH_INPUT = "searchInput";
    private static final String MICROSITE_TESTUER_NAME = "micrositeTestuserUserName";
    private static final String MICROSITE_TESTUSER_NAMES_LIST = "micrositeTestuserUserNameList";
    private static final String TESTUSER_GROUP = "micrositeTestusersUserGroups";
    private static final String TESTUSER_GROUP_LIST = "micrositeTestusersUsergroupList";
    private static final String TESTUSERS_OPERATIONS = "micrositeTestUSersOperations";
    private static final String EDIT_OPERATIONS = "micrositeTestUsersEditOperations";
    private static final String DELETE_OPERATION = "micrositeTestuserDeleteOperation";

    private static final String ADD_TESTUSER_BUTTON = "micrositeTestuserAddButton";

    private static final String USERNAME_TEXTBOX = "usernameTextbox";
    private static final String PASSWORD_TEXTBOX = "passwordTextbox";
    private static final String CONFIRM_PASSWORD_TEXTBOX = "confirmpasswordTextbox";
    private static final String ROLES_TAB = "rolesTab";
    private static final String AVAILABLE_ROLES_TAB = "rolesAvailable";
    private static final String AVAILABLE_ROLES_LIST = "rolesAvailableOptions";

    private static final String ADD_ROLES_TO_SELECTEDLIST = "addRolesToSelectedList";
    private static final String REMOVE_ROLES_FROM_SELECTEDLIST = "removerRolesFromSelectedList";
    private static final String SELECTED_ROLES_TAB = "rolesSelected";
    private static final String SELECTED_ROLES_LIST = "selectedRolesList";

    private static final String LINKS_TAB = "linksTab";
    private static final String SECURITY_TAB = "securityTab";
    private static final String TESTUSERS_TAB = "testUsersTab";
    private static final String GENERAL_TAB = "generalTab";

    private static final String REQUIRED_FIELD_MESSAGE = "requiredFieldMessage";
    private static final String SAVE_BUTTON = "saveButton";

    private static final String DELETE_ALERT_BOX = "deleteBannerAlertBox";
    private static final String ALERT_MESSAGE = "aleartMessage";
    private static final String ALERT_BOX_MODEL_OK = "confirmDeleteBannerButton";
    private static final String ALERT_BOX_CANCEL_BUTTON = "cancelDeleteBannerButton";
    private static final String INVALID_PASSWORD_MESSAGE = "invalidpasswordMessage";
    private static final String MODAL_OK = "modelOkButton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     * @author mpapishe
     */
    public MicrositeTestUsersPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new MicrositeSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     * @author mpapishe
     */
    @Override
    public boolean isReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;

        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(MICROSITE_TESTUER_NAME) && this.isElementVisibleByXPath(SEARCH_INPUT)
                && this.isElementVisibleByXPath(TESTUSER_GROUP) && this.isElementVisibleByXPath(TESTUSERS_OPERATIONS)
                && this.isElementVisibleByXPath(ADD_TESTUSER_BUTTON) && this.isElementVisibleByXPath(LINKS_TAB)
                && this.isElementVisibleByXPath(SECURITY_TAB) && this.isElementVisibleByXPath(TESTUSERS_TAB)
                && this.isElementVisibleByXPath(GENERAL_TAB)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     * @author mpapishe
     */

    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);
        this.waitForByXPath(MICROSITE_TESTUER_NAME);
        this.waitForByXPath(SEARCH_INPUT);
        this.waitForByXPath(TESTUSER_GROUP);
        this.waitForByXPath(TESTUSERS_OPERATIONS);
        this.waitForByXPath(ADD_TESTUSER_BUTTON);
        this.waitForByXPath(LINKS_TAB);
        this.waitForByXPath(SECURITY_TAB);
        this.waitForByXPath(TESTUSERS_TAB);
        this.waitForByXPath(GENERAL_TAB);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the Dashboard
     * @return {@link DashboardPage} ready to work with.
     * @author mpapishe
     */
    @Override
    public DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(BACK_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");

        return dashboard;
    }

    /**
     * Method to check the invalid Passwprd Message
     * @author mpapishe
     * @return isShown boolean value
     */

    public boolean isInvalidPasswordMessageshown() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isInvalidPasswordMessageshown method");

        boolean isShown = false;
        this.waitForByXPath(INVALID_PASSWORD_MESSAGE);
        if (this.isElementVisibleByXPath(INVALID_PASSWORD_MESSAGE, 1)) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isInvalidPasswordMessageshown method");

        return isShown;

    }

    /**
     * Method to Check the Required Message
     * @return isShown boolean value
     * @author mpapishe
     */
    public boolean isRequiredMessageshown() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isRequiredMessageshown method");

        boolean isShown = false;
        this.waitForByXPath(REQUIRED_FIELD_MESSAGE);
        if (this.isElementVisibleByXPath(REQUIRED_FIELD_MESSAGE, 1)) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRequiredMessageshown method");

        return isShown;

    }

    /**
     * Method to go back to testusers tab
     * @author mpapishe
     */
    public void goBackToTestUSersTab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBackToTestUSersTab method");

        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(BACK_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBackToTestUSersTab method");

    }

    /**
     * Method to click on OK button for the warning message
     * @author mpapishe
     */
    public void selectOKButton() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectOKButton method");

        this.getElementByXPath(MODAL_OK).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectOKButton  method");
    }

    /**
     * Method to check TestUSers List has newly created testuser.
     * @return boolean about if Testuser created successfully or not.
     * @author mpapishe
    */
    public boolean isNewlyCreatedTestUsereShownInList(String Testusername) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isNewlyCreatedTestUsereShownInList method");

        boolean isShown = false;
        this.waitForByXPath(MICROSITE_TESTUSER_NAMES_LIST);
        List<String> testuserNamesList = this.getList(MICROSITE_TESTUSER_NAMES_LIST);
        for (String testusernames : testuserNamesList) {
            if (testusernames.equalsIgnoreCase(Testusername)) {
                isShown = true;
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isNewlyCreatedTestUsereShownInList method");

        return isShown;

    }

    /**
     * Method to Edit a test user
     * @param testusername
     * @return testusername
     * @author mpapishe
     */
    public String editTestUser(String testusername, String password, String ConfirmPassword) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start editTestUser method");

        List<String> testusersList = this.getList(MICROSITE_TESTUSER_NAMES_LIST);
        for (String testuser : testusersList) {
            if (testuser.equalsIgnoreCase(testusername)) {

                this.getElementsByXPath(EDIT_OPERATIONS).get(testusersList.indexOf(testuser)).click();
                this.waitUntilDisappearByXPath(SPINNER);
                this.waitForByXPath(USERNAME_TEXTBOX);
                this.getElementByXPath(USERNAME_TEXTBOX).clear();
                testusername = "Edited" + testusername;
                this.getElementByXPath(USERNAME_TEXTBOX).sendKeys(testusername);
                this.waitUntilDisappearByXPath(SPINNER);
                this.waitForByXPath(PASSWORD_TEXTBOX);
                this.getElementByXPath(PASSWORD_TEXTBOX).sendKeys(password);
                this.waitForByXPath(CONFIRM_PASSWORD_TEXTBOX);
                this.getElementByXPath(CONFIRM_PASSWORD_TEXTBOX).sendKeys(ConfirmPassword);

                List<String> lists = new ArrayList<>();
                lists.add("SEC-MBLabAdmins");
                this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, SELECTED_ROLES_TAB, SELECTED_ROLES_LIST, REMOVE_ROLES_FROM_SELECTEDLIST);
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End editTestUser method");

        return testusername;
    }

    /** 
     * Method to check if selected tab is empty
     * @return isShown boolean value
     * @author mpapishe
     */
    public boolean isSelectedTabisEmpty() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isSelectedTabisEmpty method");

        boolean isShown = false;
        List<WebElement> rows = this.getElementsByXPath(SELECTED_ROLES_LIST);
        if (rows.size() == 0) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isSelectedTabisEmpty method");

        return isShown;

    }

    /**
     * Method to cancel deleting the testuser
     * @param testusername
     * @author mpapishe
     */

    public void cancelDeleteTestuserr(String testusername) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start cancelDeleteTestuserr method");

        List<String> testuserList = this.getList(MICROSITE_TESTUSER_NAMES_LIST);

        for (String testuser : testuserList) {
            if (testuser.equalsIgnoreCase(testusername)) {
                this.getElementsByXPath(DELETE_OPERATION).get(testuserList.indexOf(testuser)).click();
                this.waitForByXPath(DELETE_ALERT_BOX);
                this.waitForByXPath(ALERT_MESSAGE);
                this.waitForByXPath(ALERT_BOX_CANCEL_BUTTON, 2);
                this.driver.sleep(2);
                this.getElementByXPath(ALERT_BOX_CANCEL_BUTTON).click();
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End cancelDeleteTestuserr method");

    }

    /**
     * Method to Delete the test User
     * @param testusername
     * @author mpapishe
     */
    public void deleteTestUser(String testusername) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteTestUser method");

        List<String> testusersList = this.getList(MICROSITE_TESTUSER_NAMES_LIST);
        for (String testuser : testusersList) {
            if (testuser.equalsIgnoreCase(testusername)) {
                this.driver.sleep(2);
                this.getElementsByXPath(DELETE_OPERATION).get(testusersList.indexOf(testuser)).click();
                this.waitForByXPath(DELETE_ALERT_BOX);
                this.waitForByXPath(ALERT_MESSAGE);
                this.waitForByXPath(ALERT_BOX_MODEL_OK, 2);
                this.driver.sleep(2);
                this.getElementByXPath(ALERT_BOX_MODEL_OK).click();
                this.waitUntilDisappearByXPath(DELETE_ALERT_BOX);
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteTestUser method");

    }

    /**
     * Method to search for Testuser
     * @param testUserName
     * @author mpapishe
     */
    public void searchforTestuser(String testUserName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start searchforTestuser method");

        this.getElementByXPath(SEARCH_INPUT).sendKeys(testUserName);
        if (this.getList(MICROSITE_TESTUSER_NAMES_LIST).size() == 1) {
            List<String> testusersList = this.getList(MICROSITE_TESTUSER_NAMES_LIST);
            assertTrue(testusersList.toString().contains(testUserName), "The Microsite link name is not matching");
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End searchforTestuser method");
    }

    /**
     * Method to empty a search tab
     * @author mpapishe
     */
    public void emptySearchTab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start emptySearchTab method");

        this.getElementByXPath(SEARCH_INPUT).clear();
        this.getElementByXPath(SEARCH_INPUT).sendKeys(Keys.BACK_SPACE);
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End emptySearchTab method");
    }

    /**
     * Method to Fill test user Datials 
     * @param testusername
     * @param password
     * @param confirmpass
     * @author mpapishe
     */
    public void fillTestUserDetails(String testusername, String password, String confirmpass) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillTestUserDetails method");

        this.waitForByXPath(ADD_TESTUSER_BUTTON);
        this.getElementByXPath(ADD_TESTUSER_BUTTON).click();
        this.waitForByXPath(USERNAME_TEXTBOX);
        this.getElementByXPath(USERNAME_TEXTBOX).sendKeys(testusername);
        this.waitForByXPath(PASSWORD_TEXTBOX);
        this.getElementByXPath(PASSWORD_TEXTBOX).sendKeys(password);
        this.waitForByXPath(CONFIRM_PASSWORD_TEXTBOX);
        this.getElementByXPath(CONFIRM_PASSWORD_TEXTBOX).sendKeys(confirmpass);
        this.getElementByXPath(ROLES_TAB).isDisplayed();

        // Selecting the Role for test user
        List<String> lists = new ArrayList<>();
        lists.add("SEC-MBLabAdmins");
        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, AVAILABLE_ROLES_TAB, AVAILABLE_ROLES_LIST, ADD_ROLES_TO_SELECTEDLIST);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillTestUserDetails method");

    }

    /**
     * Method to save a testUser
     * @author mpapishe
     */
    public void saveTestuser() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start saveTestuser method");

        this.waitForByXPath(SAVE_BUTTON);
        this.getElementByXPath(SAVE_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End saveTestuser method");

    }

}
