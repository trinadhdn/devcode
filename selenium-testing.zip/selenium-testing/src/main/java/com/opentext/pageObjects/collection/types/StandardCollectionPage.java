/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.collection.types;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.collection.CollectionPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Standard collection pages.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class StandardCollectionPage extends CollectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(StandardCollectionPage.class);

    /**
     * Components
     */
    // Take them from the parent.

    /**
     * Items keys selectors.
     */
    // Take them from the parent.

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public StandardCollectionPage(EmergyaWebDriver driver) {
        super(driver);
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady()) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method for delete the selected assets from a standard collection. 
     */
    public void deleteSelectedAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteSelectedAssets method");

        super.deleteSelectedAssets();

        this.rechargeContainerAssets();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteSelectedAssets method");

    }

    /**
     * @return If the Sync icon is shown or not.
     */
    @Override
    public boolean isSyncIconShown() {
        return false; // this type of collection will never return Sync Icon as shown.
    }

}
