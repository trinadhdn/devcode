/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.subsectionTabs;

import static org.testng.AssertJUnit.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.administration.SectionPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the commons methods to interact with the Subsections tabs.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public abstract class SubsectionsTabsPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(SubsectionsTabsPage.class);

    /**
     * Components
     */
    List<String> allPcidsOfSectionsVisible;

    /**
     * Items keys selectors.
     */
    // Not necessary

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of visible {@link SectionPage} to obtain the pc-ids.
     */
    public SubsectionsTabsPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver);
        this.allPcidsOfSectionsVisible = this.getAllPcIdsVisible(sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public abstract boolean isReady();

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public abstract void waitForReady();

    /**
     * Method to obtain all the pc-ids visible.
     * @param list of visible {@link SectionPage} to obtain the pc-ids.
     * @return list of all the pc-ids visible.
     */
    private List<String> getAllPcIdsVisible(List<Section> sectionsVisible) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getAllPcIdsVisible method");

        List<String> allPcidsOfSectionsVisible = new ArrayList<>();

        for (int indexSection = 0; indexSection < sectionsVisible.size(); indexSection++) {
            allPcidsOfSectionsVisible.add(sectionsVisible.get(indexSection).getSectionPcId());
            for (int indexSubsection = 0; indexSubsection < sectionsVisible.get(indexSection).getSubsections()
                    .size(); indexSubsection++) {
                allPcidsOfSectionsVisible.add(sectionsVisible.get(indexSection).getSubsections().get(indexSubsection)
                        .getSubsectionPcId());
                for (int indexTab = 0; indexTab < sectionsVisible.get(indexSection).getSubsections()
                        .get(indexSubsection).getSubsectionTabs().size(); indexTab++) {
                    allPcidsOfSectionsVisible.add(sectionsVisible.get(indexSection).getSubsections()
                            .get(indexSubsection).getSubsectionTabs().get(indexTab).getSubsectionPcId());

                }
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getAllPcIdsVisible method");

        return allPcidsOfSectionsVisible;
    }

    /**
     * Method to obtain the pc-id of the key selector by its xpath.
     * @param key selector to get the pc-id.
     * @return the pc-id of the given selector.
     */
    private String getPcIdOfAKeySelector(String key) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getPcIdOfAKeySelector method");

        String pcid = null;
        for (int i = 0; i <= 10; i++) {
            if (this.getXPath(key).split("pc-id = '")[1].split("'")[0].trim() != null) {
                pcid = this.getXPath(key).split("pc-id = '")[1].split("'")[0].trim();
                break;
            } else {
                assertTrue(key + " is not loaded.", false);

            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getPcIdOfAKeySelector method");

        return pcid;
    }

    /**
     * Method to check if the key selector matches with the visible subsections or tabs.
     * @param key selector to check.
     * @return if the key selector matches with the visible or not.
     */
    protected synchronized Boolean isKeyShown(String key) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isKeyShown method");

        Boolean isMatch = false;

        for (String pcidVisible : this.allPcidsOfSectionsVisible) {
            if (this.getPcIdOfAKeySelector(key).trim().equalsIgnoreCase(pcidVisible.trim())) {
                isMatch = true;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isKeyShown method");

        return isMatch;
    }

    /**
     * Method to check if the pc-id matches with the visible section.
     * @param pc-id of the element to check
     * @return if the pc-id matches with the visible or not.
     */
    public Boolean isPcIdShown(String pcid) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isPcIdShown method");

        Boolean isMatch = false;

        for (String pcidVisible : this.allPcidsOfSectionsVisible) {
            if (pcid.trim().equalsIgnoreCase(pcidVisible.trim())) {
                isMatch = true;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isPcIdShown method");

        return isMatch;
    }

}
