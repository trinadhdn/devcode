/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.header.HeaderPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.SectionType;

/**
 * This PO contains the methods to interact with the dashboard of the Administration page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public class DashboardPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(DashboardPage.class);

    /**
     * Components
     */
    private HeaderPage header;
    private List<Section> sections;
    private List<SectionResumePage> sectionResumeList;

    /**
     * Items keys selectors.
     */
    private static final String TITLE = "title";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param sections List of sections configured.
     */
    public DashboardPage(EmergyaWebDriver driver, List<Section> sections) {
        super(driver);

        header = new HeaderPage(driver);
        this.sections = sections;
        // Initialize and charge the sectionResumeList.
        sectionResumeList = new ArrayList<>();
        for (Section section : this.sections) {
            this.sectionResumeList.add(new SectionResumePage(driver, section));
        }

        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = true;
        if (header.isReady() && this.isElementVisibleByXPath(TITLE)) {
            for (SectionResumePage sectionResume : this.sectionResumeList) {
                isReady = sectionResume.isReady() && isReady;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        header.waitForReady();
        this.waitForByXPath(TITLE);
        for (SectionResumePage sectionResume : this.sectionResumeList) {
            sectionResume.waitForReady();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    public HeaderPage getHeader() {
        return header;
    }

    /**
     * Method to navigate to the proper page in the administration dashboard.
     * @param SectionType of the page we want to navigate in.
     * @return specific {@link SectionPage} or {@link SubsectionPage} ready to work with.
     */
    public synchronized SectionPage goToSpecificSectionOrSubSectionPage(SectionType type) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start goToSpecificSectionOrSubSectionPage method");

        SectionPage sectionSpecificPage = getSectionByType(type).goToSection(sections);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End goToSpecificSectionOrSubSectionPage method");

        return sectionSpecificPage;
    }

    /**
     * Method to obtain the proper GeneralResumePage.
     * @param type of the section.
     * @return {@link GeneralResumePage} appropriate.
     */
    private synchronized GeneralResumePage getSectionByType(SectionType type) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getSectionByType method");

        GeneralResumePage resumePage = null;

        boolean isFound = false;
        int indexSection = 0;
        int indexSubsection = 0;
        int indexTab = 0;

        while (indexSection < sectionResumeList.size() && !isFound) {
            // Search in every Section.
            if (sectionResumeList.get(indexSection).getSectionType() == type) {
                isFound = true;
                // if found here: initialize to this SectionResumePage.
                resumePage = sectionResumeList.get(indexSection);
            } else {
                // Search in every Subsection.
                for (indexSubsection = 0; indexSubsection < sectionResumeList.get(indexSection)
                        .getSubSectionResumeList().size() && !isFound;) {

                    if (sectionResumeList.get(indexSection).getSubSectionResumeList().get(indexSubsection)
                            .getSubsectionType() == type) {
                        isFound = true;
                        // if found here: initialize to this SubsectionResumePage.
                        resumePage = sectionResumeList.get(indexSection).getSubSectionResumeList().get(indexSubsection);
                    } else {
                        // Search in every SubsectionTab.
                        for (indexTab = 0; indexTab < sectionResumeList.get(indexSection).getSubSectionResumeList()
                                .get(indexSubsection).getSubsectionTabResumeList().size() && !isFound;) {
                            if (sectionResumeList.get(indexSection).getSubSectionResumeList().get(indexSubsection)
                                    .getSubsectionTabResumeList().get(indexTab).getSubsectionType() == type) {
                                isFound = true;
                                // if found here: initialize to this SubsectionResumePage (is the proper ResumePage for
                                // a tab).
                                resumePage = sectionResumeList.get(indexSection).getSubSectionResumeList()
                                        .get(indexSubsection).getSubsectionTabResumeList().get(indexTab);
                            } else {
                                indexTab++;
                            }
                        }
                        indexSubsection++;
                    }
                }
                indexSection++;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getSectionByType method");

        return resumePage;
    }

}
