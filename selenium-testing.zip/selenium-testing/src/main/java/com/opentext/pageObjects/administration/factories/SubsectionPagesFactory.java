/**
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.factories;

import java.util.List;


import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.SectionPage;
import com.opentext.pageObjects.administration.general.library.LibraryServersPage;
import com.opentext.pageObjects.administration.general.microsite.MicrositeGeneralPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.SectionType;

/**
 * Factory to build @see SubSectionPage.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public abstract class SubsectionPagesFactory {

    /**
     * This method builds the proper @see SubSectionPage
     * @param driver selenium webdriver.
     * @param type of the Section, Subsection, SubsectionTab.
     * @param list of {@link Section} visible.
     * @return specific {@link SectionPage} or {@link SubsectionPage} ready to work with.
     */
    public static SectionPage buildScreenOfSectionPage(EmergyaWebDriver driver, SectionType type,
            List<Section> sectionsVisible) {

        SectionPage screenSpecific = null;
        driver.sleep(1);

        switch (type) {
        case GENERAL:
        case LIBRARY:
        case LIBRARY_SERVERS:
            screenSpecific = new LibraryServersPage(driver, sectionsVisible);
            screenSpecific.waitForReady();
            break;
        case LIBRARY_SERVICES:

            break;
        case MEDIABIN:

            break;
        case EMAIL:

            break;
        case CLOUD:

            break;
        case SCHEDULED:

            break;
        case CHECK:

            break;

        case METADATA:
        case MAPPINGS:

            break;
        case LIST:

            break;

        case VIEWS:
        case GENERAL_VIEWS:

            break;
        case TEXTS:

            break;
        case LANDING:

            break;
        case DETAILS:

            break;

        case EXPORT:

            break;

        case SECURITY:
        case CONTENT_PERMISSION:

            break;
        case ACTIVE_DIRECTORY:

            break;
        case OTDS:

            break;
        case LDAP:

            break;
        case ROLE:

            break;
        case MANAGE_PERMISSIONS:

            break;

        case MICROSITES:
        case GENERAL_MICROSITES:
            screenSpecific = new MicrositeGeneralPage(driver, sectionsVisible);
            screenSpecific.waitForReady();

            break;
        case LINKS:

            break;
        case BANNERS:

            break;
        case TEST_USERS:

            break;

        default:
            screenSpecific = null;
            break;
        }

        return screenSpecific;
    }

}
