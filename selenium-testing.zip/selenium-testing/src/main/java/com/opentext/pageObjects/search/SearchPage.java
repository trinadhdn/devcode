/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.search;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.advanceSearch.AdvanceSearchPage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.footer.FooterPage;
import com.opentext.pageObjects.header.HeaderPage;
import com.opentext.pageObjects.login.LogoutPage;
import com.opentext.pageObjects.profile.ProfilePage;
import com.opentext.pageObjects.saveInCollection.SaveInCollectionPage;
import com.opentext.pageObjects.singleDownload.specificModal.MultiDownloadPage;
import com.opentext.pageObjects.sortBy.SortByPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Search page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class SearchPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(SearchPage.class);

    /**
     * Components
     */
    private HeaderPage header;
    private SaveInCollectionPage saveInCollection;
    private AdvanceSearchPage advanceSearch;
    private SortByPage sortBy;
    private ContainerAssetsPage containerAssets;
    private FooterPage footer;

    /**
     * Items keys selectors.
     */
    private final static String SEARCH_BAR = "searchBar";
    private final static String SEARCH_COUNTER = "searchCounter";
    private final static String SEARCH_BUTTON = "searchButton";

    private final static String FOLDER_BUTTON = "folderButton";

    private final static String HISTORY_OPTIONS = "historyOptions";

    private final static String DOWNLOAD_BUTTON = "downloadButton";

    private final static String THUMBSVIEW_BUTTON = "thumbsViewButton";
    private final static String LISTVIEW_BUTTON = "listViewButton";

    private final static String POP_UP_NOT_SAVING_MORE_THAN_THREE_ASSETS = "modelAlertForSavingMoreAssetsInACollection";

    /**
     * Constructor method
     * 
     * @param driver
     * selenium webdriver
     */
    public SearchPage(EmergyaWebDriver driver) {
        super(driver);
        header = new HeaderPage(driver);
        saveInCollection = new SaveInCollectionPage(driver);
        advanceSearch = new AdvanceSearchPage(driver);
        sortBy = new SortByPage(driver);
        this.rechargeContainerAssets();
        footer = new FooterPage(driver);
        this.isReady();
    }

    /**
     * Constructor method
     * 
     * @param driver
     *            selenium webdriver
     */
    public SearchPage(EmergyaWebDriver driver, String clientName) {
        super(driver);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        this.expandSortOptionsInSearchPage();

        boolean isReady = false;
        for (int i = 0; i <= 3; i++) {
            if (header.isReady() && saveInCollection.isReady() && advanceSearch.isReady() && sortBy.isReady()
                    && containerAssets.isReady() && footer.isReady() && this.isElementVisibleByXPath(SEARCH_BAR)
                    && this.isElementVisibleByXPath(SEARCH_COUNTER) && this.isElementVisibleByXPath(SEARCH_BUTTON)

                    && this.isElementVisibleByXPath(THUMBSVIEW_BUTTON)

                    && this.isElementVisibleByXPath(THUMBSVIEW_BUTTON) && this.isElementVisibleByXPath(FOLDER_BUTTON)
                    && this.isElementVisibleByXPath(THUMBSVIEW_BUTTON)

                    && this.isElementVisibleByXPath(THUMBSVIEW_BUTTON) && this.isElementVisibleByXPath(FOLDER_BUTTON)

                    && this.isElementVisibleByXPath(THUMBSVIEW_BUTTON)

                    && this.isElementVisibleByXPath(LISTVIEW_BUTTON)) {
                isReady = true;
                break;
            }
            this.driver.navigate().refresh();

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        header.waitForReady();
        saveInCollection.waitForReady();
        advanceSearch.waitForReady();
        sortBy.waitForReady();
        containerAssets.waitForReady();
        footer.waitForReady();
        this.waitForByXPath(SEARCH_BAR);
        this.waitForByXPath(SEARCH_COUNTER);
        this.waitForByXPath(SEARCH_BUTTON);
        this.waitForByXPath(THUMBSVIEW_BUTTON);
        this.waitForByXPath(LISTVIEW_BUTTON);

        this.waitForByXPath(FOLDER_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * This method for NON-ADMIN will wait until this PO is ready
     */
    public synchronized void waitForReadyNONAdmin() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReadyNONAdmin method");

        this.waitForByXPath(SEARCH_BAR);
        this.waitForByXPath(SEARCH_COUNTER);
        this.waitForByXPath(SEARCH_BUTTON);
        this.waitForByXPath(THUMBSVIEW_BUTTON);
        this.waitForByXPath(LISTVIEW_BUTTON);

        this.waitForByXPath(FOLDER_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReadyNONAdmin method");
    }

    /**
     * Method to re-charge the container of the assets.
     */
    public synchronized void rechargeContainerAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start rechargeContainerAssets method");

        this.waitUntilDisappearByXPath(SPINNER);
        containerAssets = new ContainerAssetsPage(driver, this.isThumbsViewActive(), this.getCounterAssets());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End rechargeContainerAssets method");
    }

    /**
     * @return True if is ThumbsView active, false if is ListView active
     */
    public boolean isThumbsViewActive() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isThumbsViewActive method");

        String thumbButtonClass = null;
        boolean thumbsViewActive = false;
        if (this.retryAndGetElementByXPath(THUMBSVIEW_BUTTON)) {
            thumbButtonClass = this.getElementByXPath(THUMBSVIEW_BUTTON).getAttribute("class").trim();
            thumbsViewActive = thumbButtonClass.contains("active");
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isThumbsViewActive method");

        return thumbsViewActive;
    }

    /**
     * @return number of assets given by search bar counter.
     */
    public synchronized int getCounterAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCounterAssets method");

        String counterText = null;
        this.waitUntilDisappearByXPath(SPINNER);

        if (this.retryAndGetElementByXPath(SEARCH_COUNTER)) {
            counterText = this.getElementByXPath(SEARCH_COUNTER).getText().trim();
        }
        int counterAssets = 0;
        if (!counterText.isEmpty() && counterText != null) {
            counterAssets = Integer.parseInt(counterText);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCounterAssets method");

        return counterAssets;
    }

    /**
     * @return number of assets shown.
     */
    public int getNumberOfAssetsShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getNumberOfAssetsShown method");

        containerAssets = new ContainerAssetsPage(driver, this.isThumbsViewActive(), this.getCounterAssets());
        int counterAssetsShown = containerAssets.getNumberOfAssetsShown();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumberOfAssetsShown method");

        return counterAssetsShown;
    }

    /**
     * @return Header page.
     */
    public synchronized HeaderPage getHeader() {
        return header;
    }

    /**
     * @return ContainerAssets page.
     */
    public synchronized ContainerAssetsPage getContainerAssets() {
        return containerAssets;
    }

    /**
     * Method to perform the logout action.
     * 
     * @return Logout page ready to work with.
     */
    public synchronized LogoutPage logout() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start logout method");

        LogoutPage logoutPage = header.clickOnLogoutButton();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End logout method");

        return logoutPage;
    }

    /**
     * Method to go to profile page.
     * 
     * @return Profile page ready to work with.
     */
    public ProfilePage goToProfile() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToProfile method");

        ProfilePage profilePage = header.clickOnProfileButton();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToProfile method");

        return profilePage;
    }

    /**
     * Method to change the view to Thumbs view.
     */
    public synchronized void changeToThumbsView() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start changeToThumbsView method");

        if (!this.isThumbsViewActive()) {
            if (!this.getElementByXPath(THUMBSVIEW_BUTTON).isDisplayed()) {
                this.scrollTop();
                this.waitForByXPath(THUMBSVIEW_BUTTON);
                this.expandHeaderInMobileView();
                this.getElementByXPath(THUMBSVIEW_BUTTON).click();
                this.driver.sleep(1);
                this.rechargeContainerAssets();
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End changeToThumbsView method");

    }

    /**
     * Method to change the view to List view.
     */
    public synchronized void changeToListView() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start changeToListView method");

        if (this.isThumbsViewActive()) {
            if (!this.getElementByXPath(LISTVIEW_BUTTON).isDisplayed()) {
                this.scrollTop();
            }
            this.expandSortOptionsInSearchPage();
            this.waitUntilDisappearByXPath(SPINNER);
            this.waitUntilElementClickableByXPath(LISTVIEW_BUTTON);
            this.getElementByXPath(LISTVIEW_BUTTON).click();
            this.waitUntilDisappearByXPath(SPINNER);
            this.driver.sleep(1);
            this.rechargeContainerAssets();

        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End changeToListView method");
    }

    /**
     * Method to charge more assets using Scroll.
     */
    public synchronized void scrollToChargeMoreAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start scrollToChargeMoreAssets method");

        containerAssets.scrollToChargeMoreAssets();
        this.rechargeContainerAssets();
        this.scrollTop();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End scrollToChargeMoreAssets method");
    }

    /**
     * Method to change the SortBy option used.
     * 
     * @param index
     *            of the SortBy option to select.
     */
    public synchronized void changeSortByOptionSelected(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start changeSortByOptionSelected method");

        this.expandSortOptionsInSearchPage();
        sortBy.changeSortByOptionSelected(index);
        // move focus to the header
        header.getFocusOnLogo();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End changeSortByOptionSelected method");
    }

    /**
     * @return Number of options in SortBy component.
     */
    public synchronized int getNumberOfOptionsInSortBy() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getNumberOfOptionsInSortBy method");
        this.expandSortOptionsInSearchPage();

        int numberOfOptionsInSortBy = sortBy.getNumberOfOptions();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumberOfOptionsInSortBy method");

        return numberOfOptionsInSortBy;
    }

    /**
     * Method to clean the Search input bar.
     */
    private synchronized void cleanSearchInput() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start cleanSearchInput method");

        while (!this.getElementByXPath(SEARCH_BAR).getAttribute("value").isEmpty()) {
            this.getElementByXPath(SEARCH_BAR).sendKeys(Keys.BACK_SPACE);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End cleanSearchInput method");
    }

    /**
     * Method to type a clean text in the search bar.
     * 
     * @param Text
     *            to type.
     */
    public synchronized void typeCleanSearchText(String textToSearch) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start typeCleanSearchText method");

        // Clean the Search input.
        this.cleanSearchInput();
        // Type the text to search for.
        this.getElementByXPath(SEARCH_BAR).sendKeys(textToSearch);
        this.driver.sleep(2);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End typeCleanSearchText method");
    }

    /**
     * Method to search assets.
     * 
     * @param Text
     *            to search.
     */
    public synchronized void search(String textToSearch) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start search method");

        // Type a clean text in the search bar.
        this.typeCleanSearchText(textToSearch);
        // Click on search button to start the search.
        this.getElementByXPath(SEARCH_BUTTON).click();
        // this.getElementByXPath(SEARCH_BAR).sendKeys(Keys.ENTER);
        this.driver.sleep(5);

        // Recharges the container of assets
        this.rechargeContainerAssets();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End search method");
    }

    /**
     * @return If the History is shown or not.
     */
    public synchronized boolean isHistoryShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isHistoryShown method");

        boolean isShown = false;
        if (this.retryAndGetElementByXPath(HISTORY_OPTIONS)) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isHistoryShown method");

        return isShown;
    }

    /**
     * Method to select an history option.
     * 
     * @param index
     *            of the option.
     */
    public synchronized void selectAnHistoryOptionAndSearch(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAnHistoryOption method");

        if (this.isHistoryShown()) {
            if (index >= 0 && index < this.getElementsByXPath(HISTORY_OPTIONS).size()) {

                // Click on the option.
                this.getElementsByXPath(HISTORY_OPTIONS).get(index).click();
                this.driver.sleep(1);

                // Click on search button to start the search.
                this.getElementByXPath(SEARCH_BUTTON).click();
                this.driver.sleep(1);

                // Recharges the container of assets
                this.rechargeContainerAssets();
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAnHistoryOption method");
    }

    /**
     * Method to open the panel of the SaveInCollection component.
     * 
     * @return SaveInCollection ready to work with.
     */
    public synchronized SaveInCollectionPage openSaveInCollection() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start openSaveInCollection method");

        saveInCollection.open();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End openSaveInCollection method");

        return saveInCollection;
    }

    /**
     * Method to open the panel of the AdvanceSearch component.
     * 
     * @return AdvanceSearch ready to work with.
     */
    public synchronized AdvanceSearchPage openAdvanceSearch() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start openAdvanceSearch method");

        advanceSearch.open();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End openAdvanceSearch method");

        return advanceSearch;
    }

    /**
     * @return boolean about Download button is shown.
     */
    public synchronized boolean isDownloadButtonShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isDownloadButtonShown method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(DOWNLOAD_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isDownloadButtonShown method");

        return isReady;
    }

    /**
     * This method will wait until Download button is ready
     */
    public synchronized void waitForDownloadButtonReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForDownloadButtonReady method");

        this.waitForByXPath(DOWNLOAD_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForDownloadButtonReady method");
    }

    /**
     * Method to navigate to the MultiDownload modal of the selected assets.
     * 
     * @param counter
     *            of the selected.
     * @return MultiDownloadPage ready to work with, or null if there was no
     *         selected assets.
     */
    public synchronized MultiDownloadPage goToMultiDownloadOfTheAssets(int counterSelected) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start goToMultiDownloadOfTheAssets method");

        MultiDownloadPage multiDownload = null;

        if (containerAssets.getCountOfSelected() > 0 && this.isDownloadButtonShown()) {

            this.getElementByXPath(DOWNLOAD_BUTTON).click();

            multiDownload = new MultiDownloadPage(driver);
            multiDownload.waitForReady();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToMultiDownloadOfTheAssets method");

        return multiDownload;
    }

    /**
     * Method to navigate to the MultiDownload modal of the selected assets.
     * 
     * @param counter
     *            of the selected.
     * @return MultiDownloadPage ready to work with, or null if there was no
     *         selected assets.
     */
    public boolean assetsCountsForDateFilter(int prevCounterAssets) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start assetsCountsForDateFilter method");

        boolean isMatched = false;

        if (this.getCounterAssets() != 0) {
            if (prevCounterAssets >= this.getCounterAssets()) {

                isMatched = true;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End assetsCountsForDateFilter method");

        return isMatched;
    }

    /**
     * Method to verify tif pop of window shown when user tries to save more number of assets in a collection 
     * @return isAlertShown
     */

    public boolean isMaximunCountAlreartShown() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isMaximunCountAlreartShown method");

        boolean isAlertShown = false;

        if (this.isElementVisibleByXPath(POP_UP_NOT_SAVING_MORE_THAN_THREE_ASSETS)) {

            isAlertShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isMaximunCountAlreartShown method");
        return isAlertShown;
    }

}
