/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.collectionListArea;

import static org.testng.AssertJUnit.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.containerCollections.ContainerCollectionsPage;
import com.opentext.pageObjects.createAndEditionCollection.specific.CreateCollectionPage;
import com.opentext.pageObjects.footer.FooterPage;
import com.opentext.pageObjects.header.HeaderPage;
import com.opentext.pageObjects.search.SearchPage;
import com.opentext.pageObjects.sortBy.SortByPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Collection List Area page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class CollectionListAreaPage extends PCBasePage {

	/**
	 * Logger class initialization.
	 */
	static Logger log = Logger.getLogger(CollectionListAreaPage.class);

	/**
	 * Components
	 */
	private static HeaderPage header;
	private static SortByPage sortBy;
	private static ContainerCollectionsPage containerCollections;
	private static FooterPage footer;

	/**
	 * Items keys selectors.
	 */
	private final static String BACKTO_SEARCH_BTN = "backToSearchButton";

	private final static String ACTION_BUTTON = "actionButton";
	private final static String REMOVE_BUTTON = "removeButton";
	private final static String DONE_OPTIONS = "doneButton";
	private final static String NEW_BUTTON = "newButton";

	private final static String MYCOLLECTIONS_BUTTON = "myCollectionsButton";
	private final static String SHARED_BUTTON = "sharedButton";
	private final static String ALL_COLLECTIONS_IMAGES = "allCollectionsImages";
	private final static String MODAL_CONFIRM_BUTTON = "modalConfirmButton";

	/**
	 * Constructor method
	 * 
	 * @param driver
	 *            selenium webdriver
	 */
	public CollectionListAreaPage(EmergyaWebDriver driver) {
		super(driver);

		header = new HeaderPage(driver);
		sortBy = new SortByPage(driver);
		this.rechargeContainerCollections();
		footer = new FooterPage(driver);

		this.isReady();
	}

	/**
	 * @return boolean about this PO is ready
	 */
	@Override
	public boolean isReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

		boolean isReady = false;
		for (int i = 0; i <= 5; i++) {
			if (header.isReady() && sortBy.isReady() && containerCollections.isReady() && footer.isReady()
					&& this.isElementVisibleByXPath(BACKTO_SEARCH_BTN) && this.isElementVisibleByXPath(ACTION_BUTTON)
					&& this.isElementVisibleByXPath(NEW_BUTTON) && this.isElementVisibleByXPath(MYCOLLECTIONS_BUTTON)
					&& this.isElementVisibleByXPath(SHARED_BUTTON)) {
				isReady = true;
				break;
			}

			this.driver.navigate().refresh();
			this.driver.sleep(4);

		}
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

		return isReady;
	}

	/**
	 * This method will wait until this PO is ready
	 */
	@Override
	public void waitForReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

		header.waitForReady();
		sortBy.waitForReady();
		containerCollections.waitForReady();
		footer.waitForReady();
		this.waitForByXPath(BACKTO_SEARCH_BTN);
		this.waitForByXPath(ACTION_BUTTON);
		this.waitForByXPath(NEW_BUTTON);
		this.waitForByXPath(MYCOLLECTIONS_BUTTON);
		this.waitForByXPath(SHARED_BUTTON);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
	}

	/**
	 * Method to re-charge the container of the collections.
	 */
	public void rechargeContainerCollections() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start rechargeContainerAssets method");

		this.waitUntilDisappearByXPath(SPINNER);
		containerCollections = new ContainerCollectionsPage(driver, header.getCollectionCounter());

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End rechargeContainerAssets method");
	}

	/**
	 * @return Header page.
	 */
	public HeaderPage getHeader() {
		return header;
	}

	/**
	 * @return ContainerCollections page.
	 */
	public ContainerCollectionsPage getContainerCollections() {
		return containerCollections;
	}

	/**
	 * Method to go back to search page.
	 * 
	 * @return Search page ready to work with.
	 */
	public SearchPage goBackToSearch() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBackToSearch method");

		this.getElementByXPath(BACKTO_SEARCH_BTN).click();
		this.driver.sleep(1);

		SearchPage searchPage = new SearchPage(driver);
		searchPage.waitForReady();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBackToSearch method");

		return searchPage;
	}

	/**
	 * Method to perform a click on 'Expand/collapse all' button to see every
	 * collection.
	 */
	public void expandAll() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start expandAll method");

		containerCollections.expandAll();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End expandAll method");
	}

	/**
	 * Method to perform a click on 'Expand/collapse all' button to collapse
	 * every collection.
	 */
	public void collapseAll() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start collapseAll method");

		containerCollections.collapseAll();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End collapseAll method");
	}

	/**
	 * @return if the buttons of the action area are shown or not.
	 */
	public boolean isActionAreaShown() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isActionAreaShown method");

		boolean isShown = false;
		this.scrollTop();
		for (int i = 0; i <= 5; i++) {
			if (this.isElementVisibleByXPath(REMOVE_BUTTON) && this.isElementVisibleByXPath(DONE_OPTIONS)) {
				isShown = true;
				break;
			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isActionAreaShown method");

		return isShown;
	}

	/**
	 * This method will wait until action area is ready.
	 */
	public void waitForActionArea() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForActionArea method");

		this.waitUntilDisappearByXPath(ACTION_BUTTON);
		this.waitForByXPath(REMOVE_BUTTON);
		this.waitForByXPath(DONE_OPTIONS);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForActionArea method");
	}

	/**
	 * Method to change the SortBy option used.
	 * 
	 * @param index
	 *            of the SortBy option to select.
	 */
	public void changeSortByOptionSelected(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start changeSortByOptionSelected method");

		sortBy.changeSortByOptionSelected(index);
		containerCollections.setExpandedAll(false);
		// move focus to the header
		header.getFocusOnLogo();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End changeSortByOptionSelected method");
	}

	/**
	 * @return Number of options in SortBy component.
	 */
	public int getNumberOfOptionsInSortBy() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getNumberOfOptionsInSortBy method");

		int numberOfOptionsInSortBy = sortBy.getNumberOfOptions();
		sortBy.close();
		// move focus to the header
		header.getFocusOnLogo();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumberOfOptionsInSortBy method");

		return numberOfOptionsInSortBy;
	}

	public CreateCollectionPage goToCreateCollection() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToCreateCollection method");

		if (this.retryAndGetElementByXPath(NEW_BUTTON)) {
			this.waitUntilElementVisibileByXPath(NEW_BUTTON);
			this.getElementByXPath(NEW_BUTTON).click();
			this.driver.sleep(1);
		}
		CreateCollectionPage createCollectionPage = new CreateCollectionPage(driver);
		createCollectionPage.waitForReady();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToCreateCollection method");

		return createCollectionPage;
	}

	/**
	 * Method to perform a click on the Delete button.
	 */
	public void clickOnRemove() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnRemove method");

		if (this.retryAndGetElementByXPath(REMOVE_BUTTON)) {
			WebElement removeBtn = this.getElementByXPath(REMOVE_BUTTON);
			this.scrollTop();
			// Click on Remove button
			removeBtn.click();
		} else {
			assertTrue("Remove Button is NOT ready.", false);

		}
		this.getContainerCollections();

		this.waitForByXPath(OK_MODAL_BUTTON);

		// Click on OK modal button
		this.getElementByXPath(OK_MODAL_BUTTON).click();
		this.waitForByXPath(SPINNER);
		this.driver.sleep(2);
		this.waitUntilDisappearByXPath(OK_MODAL_BUTTON);
		this.waitUntilDisappearByXPath(SPINNER);
		/*
		 * containerCollections.setExpandedAll(false);
		 * 
		 * // Recharge the list of collections. this.expandAll();
		 * this.rechargeContainerCollections();
		 */

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnRemove method");
	}

	/**
	 * Method to perform a click on the Share button.
	 * 
	 * @author Sowjanya Lankadasu <slankada@opentext.com>
	 */
	public void clickOnShareButton() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnShareButton method");

		log.info("[log-PageObjects-info] " + this.getClass().getSimpleName()
				+ " - Clicking on Share button in collections page");

		// Click on Share button
		this.getElementByXPath(SHARED_BUTTON).click();
		this.driver.sleep(1);

		this.waitUntilDisappearByXPath(SPINNER);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnShareButton method");
	}

	/**
	 * Method to Delete All collections
	 * 
	 * @author Trinadh Nakka(tnakka@opentext.com)
	 */
	public void deleteAllCollections() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteAllCollections method");

		log.info("[log-PageObjects-info] " + this.getClass().getSimpleName() + " - Delete collections");

		Integer containerCollections = header.getCollectionCounter();

		if (containerCollections != 0) {

			// Expand all collections
			this.waitUntilDisappearByXPath(SPINNER);

			// Click on Actions button
			this.getElementByXPath(ACTION_BUTTON).click();
			this.driver.sleep(1);
			this.waitUntilDisappearByXPath(SPINNER);

			// Select all collections in list
			this.waitForByXPath(ALL_COLLECTIONS_IMAGES);
			List<WebElement> listofcollections = this.getElementsByXPath(ALL_COLLECTIONS_IMAGES);

			for (int i = 1; i <= listofcollections.size() - 1; i++) {
				this.scrollBottom();
				listofcollections.get(i).click();

			}

			// Click on remove button
			this.getElementByXPath(REMOVE_BUTTON).click();
			this.driver.sleep(1);
			this.waitUntilDisappearByXPath(SPINNER);

			// Accept modal with ok
			this.getElementByXPath(MODAL_CONFIRM_BUTTON).click();
			this.waitUntilDisappearByXPath(SPINNER);
			this.driver.sleep(4);

		}
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteAllCollections method");

	}

	/**
	 * @return True if is ThumbsView active, false if is ListView active
	 */
	// public boolean isThumbsViewActive() { // TODO: cambiar para
	// MyCollections/Shared options actives
	// log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " -
	// Start isThumbsViewActive method");
	//
	// this.waitForByXPath(THUMBSVIEW_BUTTON);
	// String thumbButtonClass =
	// this.getElementByXPath(THUMBSVIEW_BUTTON).getAttribute("class").trim();
	// boolean thumbsViewActive = thumbButtonClass.contains("active");
	//
	// log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End
	// isThumbsViewActive method");
	//
	// return thumbsViewActive;
	// }

	/**
	 * Method to change the view to Thumbs view.
	 */
	// public void changeToThumbsView() { // TODO: cambiar a
	// changeToMyCollectionsView
	// log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " -
	// Start changeToThumbsView method");
	//
	// this.waitForByXPath(THUMBSVIEW_BUTTON);
	// if (!this.isThumbsViewActive()) {
	// if (!this.getElementByXPath(THUMBSVIEW_BUTTON).isDisplayed()) {
	// this.scrollTop();
	// }
	// this.getElementByXPath(THUMBSVIEW_BUTTON).click();
	// this.driver.sleep(1);
	// this.rechargeContainerAssets();
	// }
	//
	// log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End
	// changeToThumbsView method");
	// }

	/**
	 * Method to change the view to List view.
	 */
	// public void changeToListView() { // TODO: cambiar a changeToSharedView
	// log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " -
	// Start changeToListView method");
	//
	// this.waitForByXPath(LISTVIEW_BUTTON);
	// if (this.isThumbsViewActive()) {
	// if (!this.getElementByXPath(LISTVIEW_BUTTON).isDisplayed()) {
	// this.scrollTop();
	// }
	// this.getElementByXPath(LISTVIEW_BUTTON).click();
	// this.driver.sleep(1);
	// this.rechargeContainerAssets();
	// }
	//
	// log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End
	// changeToListView method");
	// }

}
