/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.assetDetails.components;

import static org.testng.AssertJUnit.assertTrue;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.singleDownload.DownloadModalPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Download component of the AssetDetails modal.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class AssetDetailsDownloadPage extends DownloadModalPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(AssetDetailsDownloadPage.class);

    /**
     * Components
     */
    private volatile boolean isOpen;

    /**
     * Items keys selectors.
     */
    private final static String EXPAND_BUTTON = "expandDownloadButton";
    private final static String PREVIEW = "preview";
    private final static String DOWNLOAD_LINK = "downloadLink";
    private final static String ASSET_ACTIONS_DROPDOWN = "assetActionDropdown";
    private final static String DOWNLOAD_MOBILE_LINK = "downloadMobileLink";
    private final static String SAVEINCOLL_MOBILE_LINK = "saveInCollMobileLink";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public AssetDetailsDownloadPage(EmergyaWebDriver driver) {
        super(driver);
        this.isOpen = this.isAssetDetailsDownloadComponentOpen();
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 5; i++) {
            if (this.isElementVisibleByXPath(EXPAND_BUTTON)) {
                isReady = true;
                if (this.isOpen) {
                    if (this.isElementVisibleByXPath(PREVIEW) && super.isReady()) {
                        isReady = true;
                    } else {
                        isReady = false;
                    }
                }
            }
            if (isReady) {
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(EXPAND_BUTTON);
        if (this.isOpen) {
            super.waitForReady();
            this.waitForByXPath(PREVIEW);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return true if the Download complement is open, false if it is collapsed.
     */
    private synchronized boolean isAssetDetailsDownloadComponentOpen() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isAssetDetailsDownloadComponentOpen method");

        boolean isOpen = false;
        try {
            // aria-expanded = true: Download complement is expanded
            if (this.getElementByXPath(EXPAND_BUTTON, 5).getAttribute("aria-expanded").contains("true")) {
                isOpen = true;
            }
        } catch (Exception e) {
            isOpen = false;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isAssetDetailsDownloadComponentOpen method");

        return isOpen;
    }

    /**
     * Method to collapse the Download complement.
     */
    @Override
    public synchronized void close() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start close method");
        this.expandAssetActionsInMobileView();

        if (this.isOpen) {
            this.getElementByXPath(EXPAND_BUTTON).click();
            this.isOpen = false;
            this.waitUntilDisappearByXPath(PREVIEW);
        }
        assertTrue("The single download modal is not collapsed.", !this.isAssetDetailsDownloadComponentOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End close method");
    }

    /**
     * Method to expand the Download complement.
     */
    public synchronized void open() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start open method");
        if (!this.isOpen) {
            this.expandAssetActionsInMobileView();
            this.getElementByXPath(EXPAND_BUTTON).click();
            this.isOpen = true;
            this.waitForByXPath(PREVIEW);
        }
        assertTrue("The single download modal is collapsed.", this.isAssetDetailsDownloadComponentOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End open method");
    }

    /**
     * Method to perform a click on Download button.
     */
    public synchronized void clickOnDownloadButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnDownloadButton method");

        super.getElementByXPath(DOWNLOAD_BUTTON).click();
        super.waitForByXPath(DOWNLOAD_MESSAGE);

        if (this.isDrmAccepted) {
            this.waitForByXPath(DOWNLOAD_LINK);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnDownloadButton method");
    }

    /**
     * @return if the after download message & link is shown or not.
     */
    public synchronized boolean isAfterDownloadMessageAndLinkShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isAfterDownloadMessageShown method");

        boolean isShown = false;
        if (this.isElementVisibleByXPath(DOWNLOAD_MESSAGE, 5) && this.isElementVisibleByXPath(DOWNLOAD_LINK, 5)) {
            if (this.getElementByXPath(DOWNLOAD_MESSAGE).getAttribute("class").contains("text-primary")) {
                isShown = true;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isAfterDownloadMessageShown method");

        return isShown;
    }

    /**
     * Method to perform a click on Download button.
     */
    public synchronized void clickOnDownloadLink() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnDownloadLink method");

        if (this.isAfterDownloadMessageAndLinkShown()) {
            this.getElementByXPath(DOWNLOAD_LINK).click();
            super.waitUntilDisappearByXPath(DOWNLOAD_BUTTON);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnDownloadLink method");
    }

    /**
     * Method to click on downlaod link in Asset actions dropdown in asset details.
     */
    public synchronized void clickDownlaodLinkInAssetActionsDropdown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start clickDownlaodLinkInAssetActionsDropdown method");

        // verify the droo down is expanded.
        if (this.isAssetActionsDropDownOpen()) {
            // click on download asset
            this.getElementByXPath(DOWNLOAD_MOBILE_LINK).click();
            this.waitUntilDisappearByXPath(DOWNLOAD_MOBILE_LINK);
            this.waitForByXPath(DOWNLOAD_BUTTON);
        }
    }

    /**
     * @return whether the asset actions dropdown is open or not.
     */
    public synchronized boolean isAssetActionsDropDownOpen() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isAssetActionsDropDownOpen method");

        boolean isShown = false;
        if (this.isElementVisibleByXPath(ASSET_ACTIONS_DROPDOWN, 5)) {
            if (this.getElementByXPath(ASSET_ACTIONS_DROPDOWN).getAttribute("aria-expanded").contains("true")) {
                isShown = true;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isAssetActionsDropDownOpen method");

        return isShown;
    }

    /**
     * @return if the after download button shown.
     */
    public synchronized boolean isAfterDownloadButtonShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isAfterDownloadButtonShown method");

        boolean isShown = false;
        if (this.isElementVisibleByXPath(DOWNLOAD_BUTTON, 5)) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isAfterDownloadButtonShown method");

        return isShown;
    }
}
