/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.opentext.dto.Section;
import com.opentext.dto.Subsection;
import com.opentext.pageObjects.administration.factories.SubsectionPagesFactory;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.SectionType;

/**
 * This PO contains the commons methods to interact with the Subsections page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public class SubSectionResumePage extends GeneralResumePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(SubSectionResumePage.class);

    /**
     * Components
     */
    protected Subsection subsection;
    protected CopyOnWriteArrayList<SubSectionResumePage> subsectionTabResumeList;

    /**
     * Items keys selectors.
     */
    // Nothing in special

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @subsection to be used.
     */
    public SubSectionResumePage(EmergyaWebDriver driver, Subsection subsection) {
        super(driver);
        this.subsection = subsection;
        subsectionTabResumeList = new CopyOnWriteArrayList<>();
        for (Subsection subsectionTab : this.subsection.getSubsectionTabs()) {
            SubSectionResumePage cosa = new SubSectionResumePage(driver, subsectionTab);
            System.out.println(cosa);
            subsectionTabResumeList.add(cosa);

        }
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        WebElement subsectionElement = this.getSubsectionElement();

        if (subsectionElement != null && subsectionElement.isDisplayed()) {
            isReady = true;
            if (!subsectionTabResumeList.isEmpty()) {
                for (SubSectionResumePage subsectionTabResume : subsectionTabResumeList) {
                    isReady = subsectionTabResume.isReady() && isReady;
                }
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        WebElement subsectionElement = this.getSubsectionElement();
        this.waitForByElement(subsectionElement);

        if (!subsectionTabResumeList.isEmpty()) {
            for (SubSectionResumePage subsectionTabResume : subsectionTabResumeList) {
                subsectionTabResume.waitForReady();
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return the WebElement represented by this subsection.
     */
    public synchronized WebElement getSubsectionElement() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getSubsectionElement method");

        WebElement subsectionElement = null;
        String sectionXpath = this.getXPath(SECTION_DYNAMIC);
        for (int i = 0; i <= 3; i++) {
            if (this.subsection.getSubsectionPcId() != null) {
                sectionXpath = sectionXpath.replace("%pc-id%", this.subsection.getSubsectionPcId());
                subsectionElement = this.driver.findElement(By.xpath(sectionXpath));
                break;
            }

        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getSubsectionElement method");

        return subsectionElement;
    }

    /**
     * Method to navigate to the proper subsection page.
     * @param list of {@link Section} visible.
     * @return specific {@link SubSectionPage} ready to work with.
     */
    public synchronized SubSectionPage goToSection(List<Section> sectionsVisible) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToSubsection method");

        if (!(this.getSubsectionElement().isEnabled())) {

            this.driver.sleep(5);
        }
        this.driver.sleep(3);

        this.getSubsectionElement().click();

        SubSectionPage subsectionPage = (SubSectionPage) SubsectionPagesFactory
                .buildScreenOfSectionPage(driver, this.getSubsectionType(), sectionsVisible);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToSubsection method");

        return subsectionPage;
    }

    /**
     * @return SectionType of the {@link Subsection} contained here.
     */
    public synchronized SectionType getSubsectionType() {
        return this.subsection.getType();
    }

    /**
     * @return the subsectionTabResumeList.
     */
    public synchronized List<SubSectionResumePage> getSubsectionTabResumeList() {
        return subsectionTabResumeList;
    }

}
