/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.collectionInfo;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.createAndEditionCollection.specific.EditionCollectionPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Collection Info modal page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class CollectionInfoPage extends PCBasePage {

	/**
	 * Logger class initialization.
	 */
	static Logger log = Logger.getLogger(CollectionInfoPage.class);

	/**
	 * Components
	 */
	private volatile int numerAssets;

	/**
	 * Items keys selectors.
	 */
	private final static String X_BUTTON = "xButton";
	private final static String TITLE = "title";

	private final static String COVER = "cover";

	private final static String LAST_UPDATE = "lastUpdate";
	private final static String EXPIRATION = "expiration";
	private final static String OWNER_USERS = "ownerUsers";
	private final static String SHARED_USERS = "sharedUsers";
	private final static String COMMENT = "comment";

	private final static String EDIT_BUTTON = "editButton";

	/**
	 * Constructor method
	 * 
	 * @param driver
	 *            selenium webdriver
	 */
	public CollectionInfoPage(EmergyaWebDriver driver, int numerAssets) {
		super(driver);

		this.numerAssets = numerAssets;

		this.isReady();
	}

	/**
	 * @return boolean about this PO is ready
	 */
	@Override
	public boolean isReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

		boolean isReady = false;
		for (int i = 0; i <= 5; i++) {

			if (this.isElementVisibleByXPath(X_BUTTON) && this.isElementVisibleByXPath(TITLE)
					&& this.isElementVisibleByXPath(LAST_UPDATE) && this.isElementVisibleByXPath(EXPIRATION)
					&& this.isElementVisibleByXPath(EDIT_BUTTON)) {
				isReady = true;
				if (this.numerAssets > 0) { // Any asset
					if (this.isElementVisibleByXPath(COVER)) {
						isReady = true;
						break;
					} else {
						isReady = false;
						break;
					}
				}
			}
			if (isReady) {
				break;
			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

		return isReady;
	}

	/**
	 * This method will wait until this PO is ready
	 */
	@Override
	public void waitForReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

		this.waitForByXPath(X_BUTTON);
		this.waitForByXPath(TITLE);
		this.waitForByXPath(LAST_UPDATE);
		this.waitForByXPath(EXPIRATION);
		this.waitForByXPath(EDIT_BUTTON);
		if (this.numerAssets > 0) { // Any asset
			this.waitForByXPath(COVER);
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
	}

	/**
	 * Method to click on the X button, to close this modal.
	 */
	public void close() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start close method");

		WebElement xButton = this.getElementByXPath(X_BUTTON);
		if (!xButton.isDisplayed()) {
			this.scrollTo(xButton);
		}
		xButton.click();
		this.waitUntilDisappearWebElement(xButton);
		this.waitUntilDisappearByXPath(SPINNER);
		this.driver.sleep(1);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End close method");
	}

	/**
	 * Method to navigate to the Edit modal.
	 * 
	 * @return CreateCollectionPage ready to work with.
	 */
	public EditionCollectionPage goToEditModal() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToEditModal method");

		this.getElementByXPath(EDIT_BUTTON).click();
		this.driver.sleep(1);

		EditionCollectionPage editPage = new EditionCollectionPage(driver);
		editPage.waitForReady();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToEditModal method");

		return editPage;
	}

	/**
	 * Method to get the expiry date from collection information page.
	 * 
	 * @return Expiry date of the collection.
	 * @author Sowjanya Lankadasu <slankada@opentext.com>
	 */
	public String getExpiryDate() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getExpiryDate method");

		this.waitUntilDisappearByXPath(SPINNER);
		this.waitForByXPath(EXPIRATION);
		String collName = this.getElementByXPath(EXPIRATION).getText().trim();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getExpiryDate method");

		return collName;
	}

}
