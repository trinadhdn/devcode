/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.assetDetails;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsDownloadPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsMetadatasPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsSaveInCollectionPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.AssetCategoryValues.AssetType;

/**
 * This PO contains the methods to interact with the AssetDetails modal.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public class AssetDetailsPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(AssetDetailsPage.class);

    /**
     * Components
     */
    private AssetType assetType;

    private static AssetDetailsDownloadPage downloadComplement;
    private static AssetDetailsSaveInCollectionPage saveInComplement;
    private static AssetDetailsMetadatasPage metadataComplement;

    /**
     * Items keys selectors.
     */
    private final static String X_BUTTON = "xButton";
    private final static String FILENAME = "filename";

    private final static String PREVIEW = "preview";
    private final static String PREVIOUS_PAGE_BUTTON = "previousPageButton";
    private final static String NEXT_PAGE_BUTTON = "nextPageButton";
    private final static String PAGINATION = "pagination";
    private final static String PAGES = "pages";

    private final static String DESCRIPTION = "description";
    private final static String VIEWS_COUNTER = "viewsCounter";
    private final static String DOWNLOADS_COUNTER = "downloadsCounter";
    private final static String MODIFICATION_DATE = "modificationDate";

    // private final String SIMILAR_ASSETS = "similarAssets";
    private final static String CLOSE_BUTTON = "closeButton";

    /**
     * Constructor method
     * 
     * @param driver
     *            selenium webdriver
     */
    public AssetDetailsPage(EmergyaWebDriver driver, AssetType assetType) {
        super(driver);

        this.assetType = assetType;
        downloadComplement = new AssetDetailsDownloadPage(driver);
        saveInComplement = new AssetDetailsSaveInCollectionPage(driver);
        metadataComplement = new AssetDetailsMetadatasPage(driver);

        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 5; i++) {
            if (downloadComplement.isReady() && saveInComplement.isReady() && metadataComplement.isReady()
                    && this.isElementVisibleByXPath(X_BUTTON) && this.isElementVisibleByXPath(FILENAME)
                    && this.isElementVisibleByXPath(PREVIEW) && this.isElementVisibleByXPath(DESCRIPTION)
                    && this.isElementVisibleByXPath(VIEWS_COUNTER) && this.isElementVisibleByXPath(DOWNLOADS_COUNTER)
                    && this.isElementVisibleByXPath(MODIFICATION_DATE) && this.isElementVisibleByXPath(CLOSE_BUTTON)) {

                /* switch (assetType) {
                case DOCUMENT:
                    if (this.isElementVisibleByXPath(PREVIOUS_PAGE_BUTTON)
                            && this.isElementVisibleByXPath(NEXT_PAGE_BUTTON)
                            && this.isElementVisibleByXPath(PAGINATION)) {
                        isReady = true;
                    }
                    break;
                // case VIDEO: // Video files have not any particular element
                // capturable.
                default: // IMAGES AND OTHERS
                    isReady = true;
                    break;
                }*/

                isReady = true;

            }
            if (isReady) {
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        downloadComplement.waitForReady();
        saveInComplement.waitForReady();
        metadataComplement.waitForReady();
        this.waitForByXPath(X_BUTTON);
        this.waitForByXPath(FILENAME);
        this.waitForByXPath(PREVIEW);
        this.waitForByXPath(DESCRIPTION);
        this.waitForByXPath(VIEWS_COUNTER);
        this.waitForByXPath(DOWNLOADS_COUNTER);
        this.waitForByXPath(MODIFICATION_DATE);
        this.waitForByXPath(CLOSE_BUTTON);

        switch (assetType) {
        /* case DOCUMENT:
            this.waitForByXPath(PREVIOUS_PAGE_BUTTON);
            this.waitForByXPath(NEXT_PAGE_BUTTON);
            this.waitForByXPath(PAGINATION);
            break;*/
        // case VIDEO: // Video files have not any particular element
        // capturable.
        default: // IMAGES AND OTHERS
            break;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to close the panel of the AssetDetails modal.
     */
    public synchronized void close() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start close method");

        WebElement closeButton = this.getElementByXPath(CLOSE_BUTTON);
        if (!closeButton.isDisplayed()) {
            this.scrollTo(closeButton);
        }
        this.driver.sleep(2);
        closeButton.click();
        this.waitUntilDisappearWebElement(closeButton);
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End close method");
    }

    /**
     * @return the 'src' field of the current active page.
     */
    public synchronized String getCurrentSrc() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCurrentSrc method");

        // http://ec2-52-207-254-89.compute-1.amazonaws.com:8000/library/sms/cache/cacheFile?cacheType=previewCache&expires=1484564136477&cacheKey=7862de83d905eec29b1c66b2e59226290e3688bf
        String src = this.getElementByXPath(PREVIEW).getAttribute("src").split("cacheKey=")[1].trim();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCurrentSrc method");

        return src;
    }

    /**
     * @return the current page given by the pagination.
     */
    public synchronized int getCurrentPage() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCurrentSrc method");

        int currentPage = 0;
        for (int i = 0; i <= 10; i++) {
            if (this.getElementByXPath(PAGINATION).getText().split("/")[0].trim() != "") {
                currentPage = Integer.parseInt(this.getElementByXPath(PAGINATION).getText().split("/")[0].trim());
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCurrentSrc method");

        return currentPage;
    }

    /**
     * @return the quantity of pages charged.
     */
    public synchronized int getNumberOfPages() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getNumberOfPages method");

        this.waitForByXPath(PAGES);
        int pages = this.getElementsByXPath(PAGES).size();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumberOfPages method");

        return pages;
    }

    /**
     * Method to navigate to the next page using arrow button.
     */
    public synchronized void goToNextPage() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start gotoNextPage method");

        WebElement nextPageBtn = this.getElementByXPath(NEXT_PAGE_BUTTON);
        if (!nextPageBtn.isDisplayed()) {
            this.scrollTo(nextPageBtn);
        }
        nextPageBtn.click();
        waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End gotoNextPage method");
    }

    /**
     * Method to navigate to the previous page using arrow button.
     */
    public synchronized void goToPreviousPage() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start gotoPreviousPage method");

        WebElement previousPageBtn = this.getElementByXPath(PREVIOUS_PAGE_BUTTON);
        if (!previousPageBtn.isDisplayed()) {
            this.scrollTo(previousPageBtn);
        }
        previousPageBtn.click();
        waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End gotoPreviousPage method");
    }

    /**
     * Method to navigate to video.
     */
    public synchronized void goPlayVideo() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goPlayVideo method");

        WebElement video = this.getElementByXPath(PREVIEW);
        if (!video.isDisplayed()) {
            this.scrollTo(video);
        }
        video.click();
        this.driver.sleep(3);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goPlayVideo method");
    }

    /**
     * Method to navigate to video.
     */
    public synchronized int getDownloadCount() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goPlayVideo method");

        this.retryAndGetElementByXPath(DOWNLOADS_COUNTER);

        int count = Integer.parseInt(this.getElementByXPath(DOWNLOADS_COUNTER).getText());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goPlayVideo method");
        return count;
    }

    /**
     * Method to navigate to video.
     */
    public synchronized int getViewCount() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goPlayVideo method");

        this.retryAndGetElementByXPath(VIEWS_COUNTER);

        int count = Integer.parseInt(this.getElementByXPath(VIEWS_COUNTER).getText());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goPlayVideo method");
        return count;
    }

    /**
     * @return the Download complement of the asset details.
     */
    public synchronized static AssetDetailsDownloadPage getDownloadComplement() {
        return downloadComplement;
    }

    /**
     * @return the SaveInCollection complement of the asset details.
     */
    public synchronized static AssetDetailsSaveInCollectionPage getSaveInComplement() {
        return saveInComplement;
    }

    /**
     * @return the Metadata complement of the asset details.
     */
    public synchronized static AssetDetailsMetadatasPage getMetadataComplement() {
        return metadataComplement;
    }

}
