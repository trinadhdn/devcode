/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.login.external;

import java.util.Iterator;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * Abstract class to abstract all the needed actions to switch the window.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public abstract class ExternalLoginPage extends PCBasePage {

    /**
     * @see {@link PCBasePage}.
     */
    protected ExternalLoginPage(EmergyaWebDriver driver) {
        super(driver);
        // To have time to create the other window
        boolean handlerReady = false;
        String currentWindow = this.driver.getWindowHandle();
        String handler = "";
        // We check if it's ready (maybe the window was switched before)
        if (this.isReady()) {
            handlerReady = true;
        } else {
            do {
                this.driver.sleep(1);
                Iterator<String> iterator = this.driver.getWindowHandles().iterator();
                // If there is only one, we will do nothing
                if (this.driver.getWindowHandles().size() > 1) {
                    while (iterator.hasNext() && !handlerReady) {
                        handler = iterator.next();
                        if (!handler.equals(currentWindow)) {
                            // Switching to the external window
                            this.driver.switchTo().window(handler);
                            this.driver.sleep(1);
                        }
                        if (this.isReady()) {
                            handlerReady = true;
                        }
                    }
                } else {
                    if (this.isReady()) {
                        handlerReady = true;
                    }
                }
            } while (!handlerReady);
        }
    }

}
