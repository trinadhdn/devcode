/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText Technologies.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.banners.microsite;

import static org.testng.AssertJUnit.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.dto.Section;
import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Microsite subsections.
 * 
 * @author MavyaPapishetty <mpapishe@opentext.com>
 */
public class MicrositeBannersFromCollections extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(MicrositeBannersFromCollections.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private static final String SELECT_COLLECTION_CONTENT = "selectFromCollectionContent";
    private static final String SELCT_IMAGE_TEXT = "selectImageFromCollectionText";
    private static final String CLOSE_BUTTON = "closeButtonSelectCollection";
    private static final String COLLECTION_SELECTOR_LABEL = "collectionSelectorLabel";
    private static final String SELECT_COLLECTION_DROPDOWN = "collectionSelectDropdown";
    private static final String WRAPPER_AREA = "collectionWrapperArea";
    private static final String CANCEL_BUTTON = "cancelButtonCollectionSelector";
    private static final String SELECT_BUTTON = "selectButtonCollectionSelector";
    private static final String ASSETS_IN_COLLECTION_WRAPPER = "assetsInCollectionWrapper";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public MicrositeBannersFromCollections(EmergyaWebDriver driver) {
        super(driver);

    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;

        if (this.isElementVisibleByXPath(SELECT_COLLECTION_CONTENT) && this.isElementVisibleByXPath(SELCT_IMAGE_TEXT)
                && this.isElementVisibleByXPath(CLOSE_BUTTON) && this.isElementVisibleByXPath(COLLECTION_SELECTOR_LABEL)
                && this.isElementVisibleByXPath(SELECT_COLLECTION_DROPDOWN)
                && this.isElementVisibleByXPath(WRAPPER_AREA) && this.isElementVisibleByXPath(CANCEL_BUTTON)
                && this.isElementVisibleByXPath(SELECT_BUTTON)
                && this.isElementVisibleByXPath(ASSETS_IN_COLLECTION_WRAPPER)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(SELECT_COLLECTION_CONTENT);

        this.waitForByXPath(SELCT_IMAGE_TEXT);
        this.waitForByXPath(CLOSE_BUTTON);

        this.waitForByXPath(COLLECTION_SELECTOR_LABEL);
        this.waitForByXPath(SELECT_COLLECTION_DROPDOWN);
        this.waitForByXPath(WRAPPER_AREA);
        this.waitForByXPath(CANCEL_BUTTON);
        this.waitForByXPath(SELECT_BUTTON);
        this.waitForByXPath(ASSETS_IN_COLLECTION_WRAPPER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    public void selectImage(String collectionName) {

        this.waitForReady();
        assertTrue("The collection page is not ready", this.isReady());

        // Selecting collection
        List<WebElement> collections = this.getElementsByXPath(SELECT_COLLECTION_DROPDOWN);

        // Loop through the options and click the collection
        for (WebElement option : collections) {
            if (collectionName.equals(option.getText())) {

                option.click();
                break;
            }
        }
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(2);

        // Selecting the asset from collection wrapper
        List<WebElement> assets = this.getElementsByXPath(ASSETS_IN_COLLECTION_WRAPPER);

        this.waitUntilDisappearByXPath(SPINNER);
        // Loop through the options and click the first option
        for (WebElement collectionasset : assets) {

            collectionasset.click();
            break;

        }

    }

    public void clickCancel() {

        // Click on slect button
        this.waitForByElement(getElementByXPath(CANCEL_BUTTON));
        this.getElementByXPath(CANCEL_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);

    }

    public void clickSave() {

        // Click on slect button
        this.waitForByElement(getElementByXPath(SELECT_BUTTON));
        this.getElementByXPath(SELECT_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);

    }

}
