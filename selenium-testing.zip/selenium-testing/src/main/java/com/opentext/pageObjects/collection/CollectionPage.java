/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.collection;

import static org.testng.AssertJUnit.assertTrue;

import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.advanceSearch.AdvanceSearchPage;
import com.opentext.pageObjects.collection.complements.ActionAreaPage;
import com.opentext.pageObjects.collectionInfo.CollectionInfoPage;
import com.opentext.pageObjects.collectionListArea.CollectionListAreaPage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.containerCollections.ContainerCollectionsPage;
import com.opentext.pageObjects.export.ExportPage;
import com.opentext.pageObjects.folders.folderAssets.FolderAssetsPage;
import com.opentext.pageObjects.footer.FooterPage;
import com.opentext.pageObjects.header.HeaderPage;
import com.opentext.pageObjects.saveInCollection.SaveInCollectionPage;
import com.opentext.pageObjects.search.SearchPage;
import com.opentext.pageObjects.sortBy.SortByPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.UserFactory;
import com.opentext.utils.UserTest;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * This PO contains the methods to interact with the general collection pages.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public abstract class CollectionPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(CollectionPage.class);

    /**
     * Components
     */
    private static HeaderPage header;
    private static AdvanceSearchPage advanceSearch;
    private static SortByPage sortBy;
    private static ActionAreaPage actionArea;
    private static ContainerAssetsPage containerAssets;
    private static FooterPage footer;
    private FolderAssetsPage folderAssetsPage;
    private CopyOnWriteArrayList<UserTest> owners;
    private CopyOnWriteArrayList<UserTest> shared;

    /**
     * Items keys selectors.
     */
    private static final String SEARCH_BAR = "searchBar";
    private static final String SEARCH_COUNTER = "searchCounter";
    private static final String SEARCH_BUTTON = "searchButton";
    private static final String HISTORY_OPTIONS = "historyOptions";

    private static final String THUMBSVIEW_BUTTON = "thumbsViewButton";
    private static final String LISTVIEW_BUTTON = "listViewButton";

    private static final String EXPORT_BUTTON = "exportButton";
    private static final String SHARE_BUTTON = "shareButton";

    private static final String BACK_BUTTON = "backButton";

    private static final String ICON = "icon";
    private static final String TITLE = "title";

    private static final String EDIT_BUTTON = "editButton";
    private static final String NO_RESULTS_TEXT = "noResultsText";

    private final static String SENDSHAREDCOLLECTION_EMAIL = "sendsharecollectionemail";

    private final static String CANCELSHAREDCOLLECTION_EMAIL = "cancelsharecollectionemail";

    private final static String EMAIL_FIELD = "emailfield";

    private final static String CUSTOM_MESSAGE = "custommessageforshareemail";

    private final static String ALERTMESSAGE_COLLECTIONSHARED = "alertmessageforsharedcollection";

    private final static String ALERTMESSAGE_BUTTON = "alertmessagebutton";
    private final static String TEXTAREA_DESCRIPTION = "textAreaDescriptor";

    private static final String COLLECTION_NAME = "collname";

    /**
     * Constructor method
     * 
     * @param driver
     *            selenium webdriver
     */
    public CollectionPage(EmergyaWebDriver driver) {
        super(driver);

        header = new HeaderPage(driver);
        advanceSearch = new AdvanceSearchPage(driver);
        sortBy = new SortByPage(driver);
        owners = null; // TODO: change
        shared = null; // TODO: change
        actionArea = new ActionAreaPage(driver);
        this.rechargeContainerAssets();
        footer = new FooterPage(driver);

        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 3; i++) {
            if (header.isReady() && advanceSearch.isReady() && sortBy.isReady() && containerAssets.isReady()
                    && footer.isReady() && actionArea.isReady() && this.isElementVisibleByXPath(SEARCH_BAR)
                    && this.isElementVisibleByXPath(SEARCH_COUNTER) && this.isElementVisibleByXPath(SEARCH_BUTTON)
                    && this.isElementVisibleByXPath(THUMBSVIEW_BUTTON) && this.isElementVisibleByXPath(LISTVIEW_BUTTON)
                    && this.isElementVisibleByXPath(EXPORT_BUTTON) && this.isElementVisibleByXPath(SHARE_BUTTON)
                    && this.isElementVisibleByXPath(BACK_BUTTON) && this.isElementVisibleByXPath(ICON)
                    && this.isElementVisibleByXPath(TITLE) && this.isElementVisibleByXPath(EDIT_BUTTON)) {
                isReady = true;
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        header.waitForReady();
        advanceSearch.waitForReady();
        sortBy.waitForReady();
        actionArea.waitForReady();
        containerAssets.waitForReady();
        footer.waitForReady();
        this.waitForByXPath(SEARCH_BAR);
        this.waitForByXPath(SEARCH_COUNTER);
        this.waitForByXPath(SEARCH_BUTTON);
        this.waitForByXPath(THUMBSVIEW_BUTTON);
        this.waitForByXPath(LISTVIEW_BUTTON);
        this.waitForByXPath(EXPORT_BUTTON);
        this.waitForByXPath(SHARE_BUTTON);
        this.waitForByXPath(BACK_BUTTON);
        this.waitForByXPath(ICON);
        this.waitForByXPath(TITLE);
        this.waitForByXPath(EDIT_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to re-charge the container of the assets.
     */
    public void rechargeContainerAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start rechargeContainerAssets method");

        this.waitUntilDisappearByXPath(SPINNER);
        containerAssets = new ContainerAssetsPage(driver, this.isThumbsViewActive(), this.getCounterAssets());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End rechargeContainerAssets method");
    }

    /**
     * @param isActionAreaOpen
     */
    public void setActionAreaOpen(boolean isActionAreaOpen) {
        actionArea.setActionAreaOpen(isActionAreaOpen);

    }

    /**
     * @return True if is ThumbsView active, false if is ListView active
     */
    public boolean isThumbsViewActive() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isThumbsViewActive method");

        this.waitForByXPath(THUMBSVIEW_BUTTON);
        String thumbButtonClass = null;
        boolean thumbsViewActive = false;

        for (int i = 0; i <= 3; i++) {
            if (this.retryAndGetElementByXPath(THUMBSVIEW_BUTTON)) {
                if (this.getElementByXPath(THUMBSVIEW_BUTTON).getAttribute("class") != null) {
                    this.expandSortOptionsInSearchPage();
                    thumbButtonClass = this.driver
                            .findElement(By
                                    .xpath("//div[@class='mbpc-switch_views_group pull-left']//label/i[@class='fa fa-th']//parent::*"))
                            .getAttribute("class");

                    thumbsViewActive = thumbButtonClass.contains("active");
                    break;
                }
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isThumbsViewActive method");

        return thumbsViewActive;
    }

    /**
     * @return number of assets given by search bar counter.
     */
    public int getCounterAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCounterAssets method");

        this.waitForByXPath(SEARCH_COUNTER);
        this.driver.sleep(1);
        int counterAssets = 0;
        String counterText = null;
        if (this.retryAndGetElementByXPath(SEARCH_COUNTER)) {
            counterText = this.getElementByXPath(SEARCH_COUNTER).getText().trim();
        }
        if (counterText.isEmpty()) {
            return counterAssets;
        } else {
            counterAssets = Integer.parseInt(counterText);

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCounterAssets method");

        return counterAssets;
    }

    /**
     * @return number of assets shown.
     */
    public int getNumberOfAssetsShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getNumberOfAssetsShown method");

        int counterAssetsShown = containerAssets.getNumberOfAssetsShown();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumberOfAssetsShown method");

        return counterAssetsShown;
    }

    /**
     * @return Header page.
     */
    public HeaderPage getHeader() {
        return header;
    }

    /**
     * @return ContainerAssets page.
     */
    public ContainerAssetsPage getContainerAssets() {
        return containerAssets;
    }

    /**
     * @return FolderAssets page.
     */
    public FolderAssetsPage getFolderContainerAssets() {
        folderAssetsPage = new FolderAssetsPage(driver, this.isThumbsViewActive());
        return folderAssetsPage;
    }

    /**
     * @return ActionArea page.
     */
    public ActionAreaPage getActionArea() {
        return actionArea;
    }

    /**
     * Method to change the view to Thumbs view.
     */
    public void changeToThumbsView() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start changeToThumbsView method");

        this.waitForByXPath(THUMBSVIEW_BUTTON);
        if (!this.isThumbsViewActive()) {
            if (!this.getElementByXPath(THUMBSVIEW_BUTTON).isDisplayed()) {
                this.scrollTop();
            }
            this.getElementByXPath(THUMBSVIEW_BUTTON).click();
            this.driver.sleep(1);
            this.rechargeContainerAssets();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End changeToThumbsView method");
    }

    /**
     * Method to change the view to List view.
     */
    public void changeToListView() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start changeToListView method");

        this.waitForByXPath(LISTVIEW_BUTTON);
        if (this.isThumbsViewActive()) {
            if (!this.getElementByXPath(LISTVIEW_BUTTON).isDisplayed()) {
                this.scrollTop();
                this.expandSortOptionsInSearchPage();

            }
            if (this.retryAndGetElementByXPath(LISTVIEW_BUTTON)) {
                this.getElementByXPath(LISTVIEW_BUTTON).click();
            } else {

                assertTrue("LISTVIEW_BUTTON is not ready", false);

            }
            this.driver.sleep(1);
            this.rechargeContainerAssets();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End changeToListView method");
    }

    /**
     * Method to navigate back to collection list area.
     * 
     * @return CollectionListAreaPage ready to work with.
     */
    public CollectionListAreaPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.getElementByXPath(BACK_BUTTON).click();
        this.driver.sleep(1);

        CollectionListAreaPage collectionListAreaPage = new CollectionListAreaPage(driver);
        collectionListAreaPage.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");

        return collectionListAreaPage;
    }

    /**
     * Method to charge more assets using Scroll.
     */
    public void scrollToChargeMoreAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start scrollToChargeMoreAssets method");

        containerAssets.scrollToChargeMoreAssets();
        this.rechargeContainerAssets();
        this.scrollTop();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End scrollToChargeMoreAssets method");
    }

    /**
     * Method to change the SortBy option used.
     * 
     * @param index
     *            of the SortBy option to select.
     */
    public void changeSortByOptionSelected(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start changeSortByOptionSelected method");

        sortBy.changeSortByOptionSelected(index);
        // move focus to the header
        header.getFocusOnLogo();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End changeSortByOptionSelected method");
    }

    /**
     * @return Number of options in SortBy component.
     */
    public int getNumberOfOptionsInSortBy() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getNumberOfOptionsInSortBy method");

        int numberOfOptionsInSortBy = sortBy.getNumberOfOptions();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumberOfOptionsInSortBy method");

        return numberOfOptionsInSortBy;
    }

    /**
     * Method to clean the Search input bar.
     */
    private void cleanSearchInput() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start cleanSearchInput method");

        while (!this.getElementByXPath(SEARCH_BAR).getAttribute("value").isEmpty()) {
            this.getElementByXPath(SEARCH_BAR).sendKeys(Keys.BACK_SPACE);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End cleanSearchInput method");
    }

    /**
     * Method to type a clean text in the search bar.
     * 
     * @param Text
     *            to type.
     */
    public void typeCleanSearchText(String textToSearch) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start typeCleanSearchText method");

        // Clean the Search input.
        this.cleanSearchInput();
        // Type the text to search for.
        this.getElementByXPath(SEARCH_BAR).sendKeys(textToSearch);
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End typeCleanSearchText method");
    }

    /**
     * Method to search assets.
     * 
     * @param Text
     *            to search.
     */
    public void search(String textToSearch) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start search method");

        // Type a clean text in the search bar.
        this.typeCleanSearchText(textToSearch);
        // Click on search button to start the search.
        // this.getElementByXPath(SEARCH_BUTTON).click();
        this.getElementByXPath(SEARCH_BAR).sendKeys(Keys.ENTER);
        this.driver.sleep(1);

        // Recharges the container of assets
        this.rechargeContainerAssets();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End search method");
    }

    /**
     * @return If the History is shown or not.
     */
    public boolean isHistoryShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isHistoryShown method");

        boolean isShown = false;
        if (this.isElementVisibleByXPath(HISTORY_OPTIONS)) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isHistoryShown method");

        return isShown;
    }

    /**
     * Method to select an history option.
     * 
     * @param index
     *            of the option.
     */
    public void selectAnHistoryOptionAndSearch(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAnHistoryOption method");

        if (this.isHistoryShown()) {
            if (index >= 0 && index < this.getElementsByXPath(HISTORY_OPTIONS).size()) {

                // Click on the option.
                this.getElementsByXPath(HISTORY_OPTIONS).get(index).click();
                this.driver.sleep(1);

                // Click on search button to start the search.
                this.getElementByXPath(SEARCH_BUTTON).click();
                this.driver.sleep(1);

                // Recharges the container of assets
                this.rechargeContainerAssets();
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAnHistoryOption method");
    }

    /**
     * Method to open the panel of the AdvanceSearch component.
     * 
     * @return AdvanceSearch ready to work with.
     */
    public AdvanceSearchPage openAdvanceSearch() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start openAdvanceSearch method");

        advanceSearch.open();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End openAdvanceSearch method");

        return advanceSearch;
    }

    /**
     * @return the title/name of this collection.
     */
    public String getTitle() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getTitle method");

        String title = this.getElementByXPath(TITLE).getText().trim();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getTitle method");

        return title;
    }

    /**
     * Method to navigate to the Export modal for all assets.
     * 
     * @return ExportPage ready to work with, or null if there was no selected
     *         assets.
     */
    public ExportPage goToExport() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToExport method");

        ExportPage exportModal = null;

        this.getElementByXPath(EXPORT_BUTTON).click();

        if (this.getCounterAssets() > 0) {
            exportModal = new ExportPage(driver);
            exportModal.waitForReady();
        } else {
            this.waitForByXPath(OK_MODAL_BUTTON);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToExport method");

        return exportModal;
    }

    /**
     * Method to click on Export button.
     */
    private void clickOnExportButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnExportButton method");

        this.getElementByXPath(EXPORT_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnExportButton method");

    }

    /**
     * Method to navigate to the Collection Info modal.
     * 
     * @return CollectionInfoPage ready to work with.
     */
    public CollectionInfoPage goToInfo() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToInfo method");

        this.getElementByXPath(EDIT_BUTTON).click();
        this.driver.sleep(1);

        CollectionInfoPage infoModal = new CollectionInfoPage(driver, this.getCounterAssets());
        infoModal.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToInfo method");

        return infoModal;
    }

    /**
     * Method for delete the selected assets from a generic collection.
     */
    public void deleteSelectedAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteSelectedAssets method");

        assertTrue("Selected assets needed.", containerAssets.getCountOfSelected() > 0);

        // Modified by Sowjanya Lankadasu <slankada@opentext.com>, 03/07/2017.
        actionArea.clickDeleteBtn();
        // actionArea.getDeleteBtn().click();
        this.waitForByXPath(OK_MODAL_BUTTON);

        // Check the confirmation modal is shown.
        assertTrue("Ok button of the modal is not ready.", this.isOkOfModalShown());
        this.clickOnOkOfModal();
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteSelectedAssets method");

    }

    /**
     * Method to click on Shared collection
     * 
     * @author Trinadh Kumar Nakka(tnakka@opentext.com)
     */
    public void clickOnShareButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnShareButton method");

        this.getElementByXPath(SHARE_BUTTON).click();
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnShareButton method");

    }

    /**
     * To Check SendEmail and Cancel buttons are visible
     * 
     * @return if the SendEmail and Cancel button is visible.
     * @author Trinadh Kumar Nakka(tnakka@opentext.com)
     */
    public boolean isSendEmailAndCancelButtonVisible() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isSendEmailAndCancelButtonVisible method");

        boolean isReady = false;
        for (int i = 0; i <= 5; i++) {
            if (this.isElementVisibleByXPath(SENDSHAREDCOLLECTION_EMAIL)
                    && this.isElementVisibleByXPath(CANCELSHAREDCOLLECTION_EMAIL)) {
                isReady = true;
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isSendEmailAndCancelButtonVisible method");

        return isReady;

    }

    /**
     * @return If the Sync icon is shown or not.
     */
    public abstract boolean isSyncIconShown();

    /**
     * Method to verify no results present in the collection page.
     * 
     * @return returns a boolean value based on the text present or not.
     * 
     */
    public boolean isNoResultsTextPresent() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isNoResultsTextPresent method");

        boolean textPresent = false;
        if (this.isElementVisibleByXPath(NO_RESULTS_TEXT)) {
            textPresent = true;
            this.driver.sleep(1);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isNoResultsTextPresent method");

        return textPresent;
    }

    /**
     * Method to fill on Sharedcollection email.
     * 
     * @param userDomain
     *            to perform the login.
     * @param usertype
     *            to perform the login.
     * @author Trinadh Kumar Nakka(tnakka@opentext.com)
     */
    public void fillShareCollectionEmail(UserDomain userDomain, UserType userType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillShareCollectionEmail method");

        UserTest user = UserFactory.getUser(userDomain, userType);

        this.getElementByXPath(EMAIL_FIELD).clear();
        this.getElementByXPath(EMAIL_FIELD).sendKeys(user.getUsername());
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillShareCollectionEmail method");
    }

    /**
     * Method to fill on Sharedcollection comment.
     * 
     * @param comment
     *            to filled in Custom message field.
     * @author Trinadh Kumar Nakka(tnakka@opentext.com)
     */
    public void fillShareCollectionComment(String comment) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillShareCollectionComment method");

        this.getElementByXPath(CUSTOM_MESSAGE).clear();
        this.getElementByXPath(CUSTOM_MESSAGE).sendKeys(comment);
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillShareCollectionComment method");

    }

    /**
     * Method to click on SendEmail.
     * 
     * @author Trinadh Kumar Nakka(tnakka@opentext.com)
     */
    public void clickOnSendEmail() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSendEmail method");

        this.getElementByXPath(SENDSHAREDCOLLECTION_EMAIL).click();
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSendEmail method");

    }

    /**
     * Method to click on Cancel share collection.
     * 
     * @author Trinadh Kumar Nakka(tnakka@opentext.com)
     */
    public void clickOnCancleShareCollection() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start clickOnCancleShareCollection method");

        this.getElementByXPath(CANCELSHAREDCOLLECTION_EMAIL).click();
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnCancleShareCollection method");

    }

    /**
     * Getting Message from Alert Pop-Up Window.
     * 
     * @return Alert Message from Pop-Up Window.
     * @author Trinadh Kumar Nakka(tnakka@opentext.com)
     */
    public String getMessagefromAlertWindow() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getMessagefromAlertWindow method");

        String alertmessagefromapp = this.getElementByXPath(ALERTMESSAGE_COLLECTIONSHARED).getText();
        this.getElementByXPath(ALERTMESSAGE_BUTTON).click();

        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getMessagefromAlertWindow method");

        return alertmessagefromapp;
    }

    /**
    * Method to validate Alert message when collection is shared to Valid Email
    * 
    * @return boolean about Alert message when it shared to valid emailID.
    * @author MavyaPapishetty(mpapishe@opentext.com), Sowjanya Lankadasu <slankada@opentext.com>
    */
    public boolean isSharedEmailMessageValid(UserDomain userDomain, UserType userType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isSharedEmailMessageValid method");

        boolean isCorrect = false;

        UserTest useremail = UserFactory.getUser(userDomain, userType);
        String expectedalertmessage = "Success:\n" + (useremail.getUsername());

        if (this.getMessagefromAlertWindow().contains(expectedalertmessage)) {
            isCorrect = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isSharedEmailMessageValid method");

        return isCorrect;

    }

    /**
     * Method to validate Alert message when collection is shared to Invalid Email
     * 
     * @return boolean about Alert message when it shared to invalid emailID.
     * @author MavyaPapishetty(mpapishe@opentext.com),Sowjanya Lankadasu <slankada@opentext.com>
     */
    public boolean isSharedEmailMessageInvalid(UserDomain userDomain, UserType userType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isSharedEmailMessageInvalid method");

        boolean isCorrect = false;

        UserTest useremail = UserFactory.getUser(userDomain, userType);
        String expectedalertmessage = "Failed:\n" + (useremail.getUsername());

        if (this.getMessagefromAlertWindow().contains(expectedalertmessage)) {
            isCorrect = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isSharedEmailMessageInvalid method");

        return isCorrect;

    }

    /**
    * Getting getEmailTextareaDescriptor for InvalidMessage.
    * 
    * @return Error Message when Invalid email is given.
    * @author MavyaPapishetty(mpapishe@opentext.com)
    */
    public String getEmailTextareaDescriptor() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getEmailTextareaDescriptor method");

        String wrongEmailTextAreaDescriptor = this.getElementByXPath(TEXTAREA_DESCRIPTION).getText();

        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getEmailTextareaDescriptor method");

        return wrongEmailTextAreaDescriptor;
    }

    /**
     * Method to validate Error message when collection is shared to Invalid
     * Email
     * 
     * @return boolean about error message when shared to invalid emailID.
     * @author MavyaPapishetty(mpapishe@opentext.com)
     */
    public boolean isErrorMessageForInavlidEmail() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isErrorMessageForInavlidEmail method");

        boolean isCorrect = false;

        String emailTextareaDescription = "The list of emails has a bad format";

        if (this.getEmailTextareaDescriptor().equalsIgnoreCase(emailTextareaDescription)) {

            isCorrect = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isErrorMessageForInavlidEmail method");

        return isCorrect;

    }

    /**
     * Method to verify the warning message for exporting without selecting any
     * assets.
     * 
     * @return returns a boolean value based on the message present or not.
     * 
     */
    public boolean isNoAssetsSelectedTextPresent() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isNoAssetsSelectedTextPresent method");

        Boolean messagePresent = false;
        String initialMessage = "You must select at least one asset to export.";

        if (this.getElementByXPath(OK_MODAL_TEXT).getText().contains(initialMessage)) {
            messagePresent = true;
            this.driver.sleep(1);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isNoAssetsSelectedTextPresent method");

        return messagePresent;
    }

    /**
     * Method to verify the warning message for exporting a collection without
     * assets.
     * 
     * @return returns a boolean value based on the message present or not.
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     * 
     */
    public boolean isNoAssetsInCollectionTextPresent() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isNoAssetsInCollectionTextPresent method");

        Boolean messagePresent = false;
        String initialMessage = "The collection has no assets to export.";

        if (this.getElementByXPath(OK_MODAL_TEXT).getText().contains(initialMessage)) {
            messagePresent = true;
            this.driver.sleep(1);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isNoAssetsInCollectionTextPresent method");

        return messagePresent;
    }

    /**
     * Method to verify the dialog for exporting without selecting any assets
     * and accepts it.
     * 
     * @return returns a boolean value based on the dialog present or not.
     * 
     */
    public boolean isExportErrorDialogPresent() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isErrorDialogPresent method");

        this.clickOnExportButton();
        boolean dialogPresent = false;
        this.waitForByXPath(OK_MODAL_BUTTON);
        if (this.isElementVisibleByXPath(OK_MODAL_BUTTON)
                && (this.isNoAssetsInCollectionTextPresent() || this.isNoAssetsInCollectionTextPresent())) {
            dialogPresent = true;
            this.driver.sleep(1);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isErrorDialogPresent method");

        return dialogPresent;
    }

    /**
     * Method to accept the dialog for exporting without selecting any assets
     * and accepts it.
     * 
     * 
     */
    public void clickOkbtnOnExportDialog() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOkbtnOnExportDialog method");

        if (this.isNoAssetsSelectedTextPresent() || this.isNoAssetsInCollectionTextPresent()) {
            this.getElementByXPath(OK_MODAL_BUTTON).click();
            this.driver.sleep(1);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOkbtnOnExportDialog method");

    }

    /**
     * Method to wait untill 28 assets are loaded so that Items left button is
     * loaded.
     * 
     * @param Collectinon
     *            name.
     * @return Returns a boolean value based on whether assets are loaded or
     *         not.
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     * 
     */
    public boolean waitUntil28AssetsLoad(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitUntil28AssetsLoad method");

        boolean loaded = false;
        int loop = 0;
        while (this.getCounterAssets() <= 27 && !loaded && loop < 4) {
            if (this.getCounterAssets() <= 27) {
                this.sleep20andRefresh();
                this.driver.sleep(1);

                // Navigate to the collection page
                ContainerCollectionsPage containerCollections = new ContainerCollectionsPage(driver,
                        this.getHeader().getCollectionCounter());
                containerCollections.navigateToCollection(name);
                assertTrue("Collection page is not ready while navigating to the created collection in wait method.", this
                        .isReady());
                loop++;
            } else {
                loaded = true;
                this.driver.sleep(1);
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitUntil28AssetsLoad method");

        return loaded;
    }

    /**
     * Method to get the collection name from collection page.
     * 
     * @return name of the collection.
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     */
    public String getCollectionName() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCollectionName method");

        this.waitUntilDisappearByXPath(SPINNER);
        this.waitForByXPath(COLLECTION_NAME);
        String collName = this.getElementByXPath(COLLECTION_NAME).getText().trim();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCollectionName method");

        return collName;
    }

    /**
     * To Check SendEmail and Cancel buttons are not visible
     * 
     * @return if the SendEmail and Cancel button are visible or not
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     */
    public boolean isSendEmailAndCancelButtonNotVisible() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isSendEmailAndCancelButtonNotVisible method");

        boolean isReady = false;
        if (this.isElementVisibleByName(SENDSHAREDCOLLECTION_EMAIL, 1)
                && this.isElementVisibleByName(CANCELSHAREDCOLLECTION_EMAIL, 1)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isSendEmailAndCancelButtonNotVisible");
        return isReady;

    }

    /**
     * Method to add assets to an existing collection.
     * 
     * @param collection name.
     * @author Sowjanya Lankadasu <slankada@opentext.com>.
     */
    public CollectionPage addAssetstoCreatedCollection(String name) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start addAssetstoCreatedCollection method");

        this.goBack();
        CollectionListAreaPage collectionListAreaPage = new CollectionListAreaPage(driver);
        SearchPage searchPage = collectionListAreaPage.goBackToSearch();

        // Search for a word with expected result.
        searchPage.search(SEARCH_WORD_2);
        assertTrue("Search page is not ready after performing a search.", searchPage.isReady());

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add to created collection.
        saveInCollection.addToExistingCollection(name);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        collectionListAreaPage.sleep20();

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        CollectionPage collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready while navigating to the created collection.", collectionPage
                .isReady());

        assertTrue("Atleast 2 assets should be present to performing selection of assets using Shift key", collectionPage
                .getCounterAssets() > 2);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End addAssetstoCreatedCollection");

        return collectionPage;
    }

}