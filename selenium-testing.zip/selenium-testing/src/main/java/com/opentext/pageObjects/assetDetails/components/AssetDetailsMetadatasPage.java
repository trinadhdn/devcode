/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.assetDetails.components;

import static org.testng.AssertJUnit.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Metadatas component of the AssetDetails modal.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class AssetDetailsMetadatasPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(AssetDetailsMetadatasPage.class);

    /**
     * Components
     */
    private volatile boolean isOpen;
    private volatile boolean isGroupOpen;

    /**
     * Items keys selectors.
     */
    private final static String EXPAND_BUTTON = "expandMetadataButton";

    private final static String SEARCH_INPUT = "searchInput";
    private final static String SEARCH_BUTTON = "searchButton";

    private final static String EXPAND_TABLE_BUTTON = "expandTableButton";
    private final static String ONLY_EXPAND_TABLE_BUTTON = "onlyExpandTableButton";
    private final static String METADATA_FIELDS = "metadataField";
    private final static String METADATA_VALUES = "metadataValue";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public AssetDetailsMetadatasPage(EmergyaWebDriver driver) {
        super(driver);
        this.isOpen = this.isAssetDetailsMetadataComponentOpen();
        if (this.isOpen) {
            this.isGroupOpen = this.isGroupOfMetadatasOpen();
        } else {
            this.isGroupOpen = false;
        }
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 5; i++) {
            if (this.isElementVisibleByXPath(EXPAND_BUTTON)) {
                isReady = true;
                if (this.isOpen) {// If is opened the elements should be shown.
                    if (this.isElementVisibleByXPath(SEARCH_INPUT) && this.isElementVisibleByXPath(SEARCH_BUTTON)
                            && this.isElementVisibleByXPath(EXPAND_TABLE_BUTTON)) {
                        isReady = true;
                        if (this.isGroupOpen) {
                            if (this.isElementVisibleByXPath(METADATA_FIELDS)
                                    && this.isElementVisibleByXPath(METADATA_VALUES)) {
                                isReady = true;
                            } else {
                                isReady = false;
                            }
                        }
                    } else {
                        isReady = false;
                    }
                }
            }
            if (isReady) {
                break;
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;

    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(EXPAND_BUTTON);
        if (this.isOpen) { // If is opened the elements should be waited.
            this.waitForByXPath(SEARCH_INPUT);
            this.waitForByXPath(SEARCH_BUTTON);
            this.waitForByXPath(EXPAND_TABLE_BUTTON);
            if (this.isGroupOpen) {
                this.waitForByXPath(METADATA_FIELDS);
                this.waitForByXPath(METADATA_VALUES);
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return true if the panel is open, false if it is collapsed.
     */
    public synchronized boolean isAssetDetailsMetadataComponentOpen() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isAssetDetailsMetadataComponentOpen method");

        boolean isOpen = false;
        try {
            // aria-expanded = true: this complement is expanded
            if (this.getElementByXPath(EXPAND_BUTTON, 5).getAttribute("aria-expanded").contains("true")) {
                isOpen = true;
            }
        } catch (Exception e) {
            isOpen = false;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isAssetDetailsMetadataComponentOpen method");

        return isOpen;
    }

    /**
     * @return true if the table of the group of metadatas is open, false if it is collapsed.
     */
    private synchronized boolean isGroupOfMetadatasOpen() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isGroupOfMetadatasOpen method");

        boolean isOpen = false;
        try {
            // aria-expanded = true: this group is expanded
            if (this.getElementByXPath(EXPAND_TABLE_BUTTON, 5).getAttribute("aria-expanded").contains("true")) {
                isOpen = true;
            }
        } catch (Exception e) {
            isOpen = false;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isGroupOfMetadatasOpen method");

        return isOpen;
    }

    /**
     * Method to open the panel of the Metadata component.
     */
    public synchronized void open() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start open method");

        if (!this.isOpen) {
            this.expandAssetActionsInMobileView();
            this.getElementByXPath(EXPAND_BUTTON).click();
            this.isOpen = true;
            this.waitForByXPath(EXPAND_TABLE_BUTTON);
        }
        assertTrue("Metadata component is not open.", this.isAssetDetailsMetadataComponentOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End open method");
    }

    /**
     * Method to close the panel of the Metadata component.
     */
    public synchronized void close() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start close method");

        if (this.isOpen) {
            this.expandAssetActionsInMobileView();

            this.getElementByXPath(EXPAND_BUTTON).click();
            this.isOpen = false;
            this.waitUntilDisappearByXPath(EXPAND_TABLE_BUTTON);
        }
        assertTrue("Metadata component is not collapsed.", !this.isAssetDetailsMetadataComponentOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End close method");
    }

    /**
     * Method to open the group of metadatas and see the table.
     */
    public void openGroup() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start openGroup method");

        if (!this.isOpen) {
            this.open();
        }
        if (!this.isGroupOpen) {
            this.waitForByXPath(EXPAND_TABLE_BUTTON);
            // this.waitUntilElementVisibileByXPath(EXPAND_TABLE_BUTTON);
            this.waitUntilElementClickableByXPath(EXPAND_TABLE_BUTTON);
            this.search("name");
            this.cleanSearchInput();
            // this.getElementByXPath(EXPAND_TABLE_BUTTON).click();
            this.isGroupOpen = true;
            this.waitForByXPath(METADATA_FIELDS);
        }
        // assertTrue("Metadata component is not open.", this.isGroupOfMetadatasOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End openGroup method");
    }

    /**
     * Method to close the group of metadatas and see the table.
     */
    public synchronized void closeGroup() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start closeGroup method");

        if (this.isOpen && this.isGroupOpen) {

            List<WebElement> links = this.getElementsByXPath(ONLY_EXPAND_TABLE_BUTTON);
            for (WebElement link : links) {
                link.click();
                this.isGroupOpen = false;
                this.waitUntilDisappearByXPath(METADATA_FIELDS);
            }

            /*            this.waitForByXPath(EXPAND_TABLE_BUTTON);
            this.getElementByXPath(EXPAND_TABLE_BUTTON).click();
            this.isGroupOpen = false;
            this.waitUntilDisappearByXPath(METADATA_FIELDS);
            */
        }
        assertTrue("Metadata component is not collapsed.", !this.isGroupOfMetadatasOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End closeGroup method");
    }

    /**
     * @return the quantity of metadatas values shown.
     */
    public synchronized int numberOfMetadatasValuesShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start numberOfMetadatasValuesShown method");

        int counter = 0;
        if (this.isOpen && this.isGroupOpen) {
            counter = this.getElementsByXPath(METADATA_VALUES).size();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End numberOfMetadatasValuesShown method");

        return counter;
    }

    /**
     * Method to clean the search input bar.
     */
    public synchronized void cleanSearchInput() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start cleanSearchInput method");

        while (!this.getElementByXPath(SEARCH_INPUT).getAttribute("value").isEmpty()) {
            this.getElementByXPath(SEARCH_INPUT).sendKeys(Keys.BACK_SPACE);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End cleanSearchInput method");
    }

    /**
     * Method to type a clean text in the search bar.
     * @param Text to type.
     */
    private synchronized void typeCleanSearchText(String textToSearch) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start typeCleanSearchText method");

        // Clean the Search input.
        this.cleanSearchInput();
        // Type the text to search for.
        this.getElementByXPath(SEARCH_INPUT).sendKeys(textToSearch);
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End typeCleanSearchText method");
    }

    /**
     * Method to search assets.
     * @param Text to search.
     */
    public synchronized void search(String textToSearch) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start search method");

        if (this.isOpen) {
            // Type a clean text in the search input.
            this.typeCleanSearchText(textToSearch);
            // Click on search button to start the search (not really necessary here).
            this.getElementByXPath(SEARCH_BUTTON).click();
            this.driver.sleep(1);
            this.waitUntilDisappearByXPath(SPINNER);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End search method");
    }

    /**
     * Method to check if the text given is contained in every value shown.
     * @param Text to search in the metadatas values.
     * @return if the text given is contained in every value shown.
     */
    public synchronized boolean isContainedInEveryValueShown(String textToSearch) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isContainedInEveryValueShown method");

        if (!this.isOpen || !this.isGroupOpen) { // To ensure we can see metadatas.
            this.openGroup();
        }

        boolean isFound = true;
        if (this.numberOfMetadatasValuesShown() > 0) {
            List<WebElement> values = this.getElementsByXPath(METADATA_VALUES);
            List<WebElement> fields = this.getElementsByXPath(METADATA_FIELDS);

            // Loop checking for every value
            if (values.size() == fields.size()) {
                for (int i = 0; i < values.size(); i++) {
                    // if not contains -> isFound = false
                    if (!(values.get(i).getText().toLowerCase().contains(textToSearch.toLowerCase())
                            || (fields.get(i).getText().toLowerCase().contains(textToSearch.toLowerCase())))) {
                        isFound = false;
                    }
                }
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isContainedInEveryValueShown method");

        return isFound;
    }

}
