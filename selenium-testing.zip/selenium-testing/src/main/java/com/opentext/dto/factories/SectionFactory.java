/**
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.dto.factories;

import com.opentext.dto.Section;
import com.opentext.dto.Subsection;
import com.opentext.utils.SectionType;

/**
 * Factory that builds the @see Section and add its @see Subsection.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public abstract class SectionFactory {

    /**
     * It retrieves a {@link Section} instance depending on the provided pc-id.
     * @param pc-id to be used as identifier.
     * @return a {@link Section}.
     */
    public static Section buildSection(String pcid) {
        Section section = new Section(pcid);
        section.setType(getSectionTypeFromId(pcid));
        return section;
    }

    /**
     * Method to add, to a {@link Section}, one {@link Subsection}
     * @param section to be added.
     * @param subsection to be added.
     * @return a {@link Section}.
     */
    public static Section addSubsection(Section section, Subsection subsection) {
        section.addSubsection(subsection);
        return section;
    }

    /**
     * Method to compare and get the proper type using the pc-id.
     * @param pc-id of the Section.
     * @return {@link SectionType}
     */
    private static SectionType getSectionTypeFromId(String id) {
        SectionType type = null;
        for (SectionType typeValue : SectionType.values()) {
            if (id.trim().equalsIgnoreCase(typeValue.getType().trim())) {
                type = typeValue;
            }
        }
        return type;
    }

}
