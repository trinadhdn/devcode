package com.opentext.selenium.drivers;

public class DriverManager {
    private static final ThreadLocal<EmergyaWebDriver> threadLocal = new ThreadLocal<EmergyaWebDriver>();

    public static EmergyaWebDriver getDriver() {
        return threadLocal.get();
    }

    public static void setWebDriver(EmergyaWebDriver driver) {
        threadLocal.set(driver);

    }

    public static void closeDriver(EmergyaWebDriver driver) {

        if (driver != null) {
            try {
                driver.manage().deleteAllCookies();
                driver.quit();
            } catch (Exception e) {

                e.printStackTrace();
            }

        }
        threadLocal.remove();

    }
}