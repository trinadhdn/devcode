package com.opentext.selenium.utils;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;

import com.opentext.selenium.drivers.DriverManager;
import com.opentext.selenium.drivers.EmergyaWebDriver;

public class OTWebDriverListener implements IInvokedMethodListener {

    public EmergyaWebDriver driver;
    public Initialization config = Initialization.getInstance();

    @Override
    public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
        if (method.isTestMethod()) {
            // EmergyaWebDriver driver = config.initialize();
            DriverManager driverManager = new DriverManager();
            driverManager.setWebDriver(driver);
        }
    }

    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
        if (method.isTestMethod()) {
            EmergyaWebDriver driver = DriverManager.getDriver();
            if (driver != null) {
                driver.manage().deleteAllCookies();
                driver.quit();
            }

        } else

            driver.quit();
    }
}